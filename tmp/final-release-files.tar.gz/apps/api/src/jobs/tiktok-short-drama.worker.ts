import { PrismaClient, type UploadJob } from '@prisma/client';
import { loadEnv } from '../config/env';
import { configuredMiniAppKeys, miniAppEnvironment } from '../config/mini-apps';
import { runtimeDatabaseUrl } from '../config/database-pool';
import {
  ProviderNotConfiguredError,
  UnconfiguredTikTokShortDramaService,
  type TikTokShortDramaService,
  type UploadStatusResult
} from '../services/tiktok-short-drama.service';
import { BytePlusVodService } from '../services/byteplus-vod.service';
import { processLocalUploadJobs } from '../services/local-upload.service';
import { TikTokShortDramaApiService } from '../services/tiktok-short-drama-api.service';
import { enqueueDueReviewReconciliations, enqueueVideoSync, processPlatformSyncJobs } from '../services/platform-sync.service';
import { enqueueDueSharedReconciliations, processSharedPlatformOperations } from '../services/shared-platform.service';
import { refreshAnalyticsDailySummaries, refreshOverviewSnapshot } from '../services/analytics-summary.service';

const defaultIntervalMs = 30_000;
const defaultMaxRetries = 5;

type WorkerOptions = {
  maxRetries?: number;
  now?: () => Date;
  log?: (message: string, details?: Record<string, unknown>) => void;
};

type JobWithEpisode = UploadJob & {
  episode: {
    title: string;
    status: string;
    coverAsset: { publicUrl: string; status: string } | null;
  };
};

function retryDelayMs(retryCount: number) {
  return Math.min(30 * 60_000, 30_000 * (2 ** Math.max(0, retryCount - 1)));
}

function safeErrorMessage(error: unknown) {
  if (error instanceof ProviderNotConfiguredError) return error.message;
  if (error instanceof Error && error.message.length <= 240) return error.message;
  return 'Provider request failed.';
}

function isRetryable(error: unknown) {
  return error instanceof ProviderNotConfiguredError || Boolean((error as { retryable?: boolean }).retryable);
}

async function markFailure(
  prisma: PrismaClient,
  job: UploadJob,
  message: string,
  retryable: boolean,
  options: Required<Pick<WorkerOptions, 'maxRetries' | 'now'>> & Pick<WorkerOptions, 'log'>
) {
  const retryCount = job.retryCount + 1;
  const shouldRetry = retryable && retryCount <= options.maxRetries;
  if (shouldRetry) {
    const nextAttemptAt = new Date(options.now().getTime() + retryDelayMs(retryCount));
    await prisma.uploadJob.update({
      where: { id: job.id },
      data: {
        status: job.providerJobId ? 'PROCESSING' : 'PENDING',
        retryCount,
        errorMessage: message,
        nextAttemptAt
      }
    });
    options.log?.('Upload job scheduled for retry.', {
      jobId: job.id,
      retryCount,
      nextAttemptAt: nextAttemptAt.toISOString()
    });
    return;
  }

  await prisma.$transaction([
    prisma.uploadJob.update({
      where: { id: job.id },
      data: {
        status: 'FAILED',
        retryCount,
        errorMessage: message,
        nextAttemptAt: null,
        completedAt: options.now()
      }
    }),
    prisma.episode.update({
      where: { id: job.episodeId },
        data: { status: 'ERROR', byteplusUploadStatus: 'FAILED' }
    })
  ]);
  options.log?.('Upload job permanently failed.', { jobId: job.id, retryCount });
}

async function processJob(
  prisma: PrismaClient,
  job: JobWithEpisode,
  service: TikTokShortDramaService,
  env: ReturnType<typeof loadEnv>,
  options: Required<Pick<WorkerOptions, 'maxRetries' | 'now'>> & Pick<WorkerOptions, 'log'>
) {
  if (job.status === 'PENDING') {
    if (job.sourceExpiresAt && job.sourceExpiresAt <= options.now()) {
      await markFailure(prisma, job, 'Upload source URL has expired.', false, options);
      return;
    }
    try {
      const result = await service.createVideoUpload({
        sourceUrl: job.sourceUrl,
        title: job.episode.title,
        spaceName: env.BYTEPLUS_SPACE_NAME,
        byteplusAccountId: env.BYTEPLUS_ACCOUNT_ID
      });
      await prisma.$transaction([
        prisma.uploadJob.update({
          where: { id: job.id },
          data: {
            providerJobId: result.providerJobId,
            status: 'PROCESSING',
            startedAt: options.now(),
            nextAttemptAt: null,
            errorMessage: null
          }
        }),
        prisma.episode.update({
          where: { id: job.episodeId },
          data: { status: 'UPLOADING', byteplusUploadStatus: 'UPLOADING' }
        })
      ]);
    } catch (error) {
      await markFailure(prisma, job, safeErrorMessage(error), isRetryable(error), options);
    }
    return;
  }

  if (!job.providerJobId) {
    await markFailure(prisma, job, 'Provider job id is missing.', false, options);
    return;
  }

  let result: UploadStatusResult;
  try {
    result = await service.getVideoUploadStatus({
      providerJobId: job.providerJobId,
      byteplusAccountId: env.BYTEPLUS_ACCOUNT_ID
    });
  } catch (error) {
    await markFailure(prisma, job, safeErrorMessage(error), isRetryable(error), options);
    return;
  }

  if (result.status === 'PROCESSING') {
    await prisma.uploadJob.update({
      where: { id: job.id },
      data: {
        status: 'PROCESSING',
        startedAt: job.startedAt ?? options.now(),
        nextAttemptAt: new Date(options.now().getTime() + 30_000),
        errorMessage: null
      }
    });
    return;
  }

  if (result.status === 'FAILED') {
    await markFailure(prisma, job, result.errorMessage ?? 'Provider rejected the upload.', result.retryable ?? false, options);
    return;
  }

  if (!result.byteplusVid) {
    await markFailure(prisma, job, 'Provider completed without a video id.', false, options);
    return;
  }

  await prisma.$transaction([
    prisma.uploadJob.update({
      where: { id: job.id },
      data: {
        status: 'SUCCEEDED',
        completedAt: options.now(),
        nextAttemptAt: null,
        errorMessage: null
      }
    }),
    prisma.episode.update({
      where: { id: job.episodeId },
      data: {
        status: 'READY',
        byteplusUploadStatus: 'READY',
        byteplusVid: result.byteplusVid,
        byteplusCoverUrl: result.coverUrl,
        coverUrl: job.episode.coverAsset?.status === 'READY' ? job.episode.coverAsset.publicUrl : result.coverUrl,
        durationMs: result.durationMs
      }
    })
  ]);
  if (env.TIKTOK_CLIENT_KEY && env.TIKTOK_CLIENT_SECRET) {
    await enqueueVideoSync(prisma as any, job.episodeId).catch((error) => {
      options.log?.('Could not enqueue TikTok video registration.', { jobId: job.id, error: safeErrorMessage(error) });
    });
  }
  options.log?.('Upload job completed.', { jobId: job.id, episodeId: job.episodeId });
}

export async function processJobs(
  prisma: PrismaClient,
  service: TikTokShortDramaService,
  workerOptions: WorkerOptions = {},
  env = loadEnv()
) {
  const now = workerOptions.now ?? (() => new Date());
  const maxRetries = workerOptions.maxRetries ?? defaultMaxRetries;
  const currentTime = now();
  const jobs = await prisma.uploadJob.findMany({
    where: {
      sourceType: 'URL',
      status: { in: ['PENDING', 'PROCESSING'] },
      retryCount: { lte: maxRetries },
      OR: [{ nextAttemptAt: null }, { nextAttemptAt: { lte: currentTime } }]
    },
    take: 20,
    orderBy: { createdAt: 'asc' },
    include: { episode: { select: { title: true, status: true, coverAsset: { select: { publicUrl: true, status: true } } } } }
  });
  for (const job of jobs) {
    await processJob(prisma, job, service, env, { maxRetries, now, log: workerOptions.log });
  }
  return jobs.length;
}

export async function startUploadWorker() {
  const env = { ...loadEnv(), MINI_APP_KEY: 'main' as const };
  const environments = configuredMiniAppKeys(env).map((key) => miniAppEnvironment(env, key)).filter((item): item is typeof env => item !== null);
  const contexts = environments.map((contextEnv) => ({
    env: contextEnv,
    prisma: new PrismaClient({ datasources: { db: { url: runtimeDatabaseUrl(contextEnv.DATABASE_URL, env.DATABASE_POOLER_HOST, env.DATABASE_POOLER_PORT) } } }),
    service: contextEnv.BYTEPLUS_ACCESS_KEY && contextEnv.BYTEPLUS_SECRET_KEY
      ? new BytePlusVodService(contextEnv)
      : new UnconfiguredTikTokShortDramaService(),
    platformApi: new TikTokShortDramaApiService(contextEnv)
  }));
  const sharedDatabaseUrl = env.SHARED_PLATFORM_DATABASE_URL ?? env.DATABASE_URL;
  const sharedPrisma = sharedDatabaseUrl === env.DATABASE_URL
    ? contexts.find((context) => context.env.MINI_APP_KEY === 'main')?.prisma
    : new PrismaClient({ datasources: { db: { url: runtimeDatabaseUrl(sharedDatabaseUrl, env.DATABASE_POOLER_HOST, env.DATABASE_POOLER_PORT) } } });
  if (!sharedPrisma) throw new Error('Main Prisma context is required for shared platform operations.');

  const run = async () => {
    for (const context of contexts) {
      try {
        if (context.service instanceof BytePlusVodService) await processLocalUploadJobs(context.prisma, sharedPrisma, context.service, context.env, {
          concurrency: 2,
          log: (message, details) => console.info(context.env.MINI_APP_KEY, message, details)
        });
        await processJobs(context.prisma, context.service, {
          maxRetries: context.env.UPLOAD_MAX_RETRIES,
          log: (message, details) => console.info(context.env.MINI_APP_KEY, message, details)
        }, context.env);
        if (context.platformApi.isConfigured()) {
          await enqueueDueReviewReconciliations(context.prisma as any, new Date(), (albumId, error) => console.error(context.env.MINI_APP_KEY, 'Could not queue review reconciliation.', albumId, error));
          await processPlatformSyncJobs(context.prisma as any, context.platformApi, {
            maxRetries: context.env.UPLOAD_MAX_RETRIES,
            log: (message, details) => console.info(context.env.MINI_APP_KEY, message, details)
          });
        }
      } catch (error) {
        console.error(`${context.env.MINI_APP_KEY} worker cycle failed.`, error);
      }

    }
    const apiByApp = Object.fromEntries(contexts.map((context) => [context.env.MINI_APP_KEY, context.platformApi]));
    const localPrismaByApp = Object.fromEntries(contexts.map((context) => [context.env.MINI_APP_KEY, context.prisma]));
    await enqueueDueSharedReconciliations(sharedPrisma as any);
    await processSharedPlatformOperations(sharedPrisma as any, {
      env,
      maxRetries: env.UPLOAD_MAX_RETRIES,
      localPrismaByApp,
      apiByApp,
      log: (message, details) => console.info('shared-platform', message, details)
    });
  };

  let analyticsRunning = false;
  const refreshAnalytics = async () => {
    if (analyticsRunning) return;
    analyticsRunning = true;
    try {
      for (const context of contexts) {
        try {
          await refreshAnalyticsDailySummaries(context.prisma, { days: 2 });
          await refreshOverviewSnapshot(context.prisma);
          await context.prisma.miniAppRuntimeError.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - 30 * 86_400_000) } } });
        } catch (error) { console.error(`${context.env.MINI_APP_KEY} analytics summary refresh failed.`, error); }
      }
    } finally { analyticsRunning = false; }
  };
  void refreshAnalytics();
  const analyticsTimer = setInterval(() => { void refreshAnalytics(); }, 5 * 60_000);
  await run().catch((error) => console.error('Upload worker cycle failed.', error));
  let running = false;
  const timer = setInterval(() => {
    if (running) return;
    running = true;
    void run().catch((error) => console.error('Upload worker cycle failed.', error)).finally(() => { running = false; });
  }, env.UPLOAD_WORKER_INTERVAL_MS || defaultIntervalMs);
  const shutdown = async () => {
    clearInterval(timer);
    clearInterval(analyticsTimer);
    await Promise.all([
      ...contexts.map((context) => context.prisma.$disconnect()),
      ...(sharedPrisma !== contexts.find((context) => context.env.MINI_APP_KEY === 'main')?.prisma ? [sharedPrisma.$disconnect()] : [])
    ]);
  };
  process.once('SIGINT', () => void shutdown());
  process.once('SIGTERM', () => void shutdown());
}

if (/tiktok-short-drama\.worker\.(?:ts|js)$/.test(process.argv[1] ?? '')) {
  void startUploadWorker();
}
