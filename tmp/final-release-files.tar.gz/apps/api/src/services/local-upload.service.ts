import { createHash, randomUUID } from 'node:crypto';
import { stat, unlink } from 'node:fs/promises';
import { resolve, relative, isAbsolute } from 'node:path';
import type { PrismaClient } from '@prisma/client';
import type { Env } from '../config/env';
import { BytePlusVodError, BytePlusVodService, episodeMediaTitle, isBytePlusTransferFailure, type BytePlusMedia } from './byteplus-vod.service';
import { enqueueVideoSync } from './platform-sync.service';
import { getOrCreateSharedMediaAsset } from './shared-platform.service';

type Db = PrismaClient;
const leaseMs = 2 * 60_000;
const recoveryDelayMs = 60_000;
const recoveryWindowMs = 10 * 60_000;

function conflict(message: string) { return Object.assign(new Error(message), { statusCode: 409 }); }

export function localUploadDirectory(env: Env) {
  return resolve(env.LOCAL_UPLOAD_STORAGE_DIR ?? resolve(env.COVER_ASSET_STORAGE_DIR, '..', 'video-uploads'));
}

export function uploadScope(env: Env) {
  const identity = [env.MINI_APP_KEY, env.TIKTOK_CLIENT_KEY ?? '', env.BYTEPLUS_ACCOUNT_ID, env.BYTEPLUS_SPACE_NAME, env.BYTEPLUS_REGION];
  return createHash('sha256').update(JSON.stringify(identity)).digest('hex');
}

export function uploadTags(scope: string, jobId: string) {
  return [`s${scope.slice(0, 16)}`, `u${createHash('sha256').update(jobId).digest('hex').slice(0, 16)}`];
}

function legacyUploadTags(scope: string, jobId: string) {
  return [`qr-scope-${scope}`, `qr-upload-${jobId}`];
}

export function matchesUploadTags(tags: string[] | undefined, scope: string, jobId: string) {
  return [uploadTags(scope, jobId), legacyUploadTags(scope, jobId)]
    .some((expected) => expected.every((tag) => tags?.includes(tag)));
}

export async function assertMediaScope(sharedPrisma: Db, env: Env, media: BytePlusMedia) {
  const scopes = (media.tags ?? []).filter((tag) => tag.startsWith('qr-scope-') || /^s[0-9a-f]{16}$/.test(tag));
  const allowed = [uploadTags(uploadScope(env), '')[0], legacyUploadTags(uploadScope(env), '')[0]];
  if (scopes.some((tag) => !allowed.includes(tag))) {
    throw Object.assign(new Error('此 VID 由其他小程序或旧 Client Key 上传，不能绑定到当前小程序，请在当前小程序重新上传。'), { statusCode: 409 });
  }
  const owner = await sharedPrisma.sharedMediaAsset.findUnique({ where: { byteplusVid: media.vid } });
  if (owner && (owner.firstUploadedByApp !== env.MINI_APP_KEY || owner.byteplusAccountId !== env.BYTEPLUS_ACCOUNT_ID || owner.byteplusSpaceName !== env.BYTEPLUS_SPACE_NAME || owner.byteplusRegion !== env.BYTEPLUS_REGION)) {
    throw Object.assign(new Error('此 VID 已属于其他小程序的媒资，不能在当前小程序重新登记，请重新上传或使用剧目授权。'), { statusCode: 409 });
  }
  if (!scopes.length && !owner) throw conflict('此 VID 缺少可验证的小程序归属，请在当前小程序重新上传。');
}

export async function findUploadMedia(service: BytePlusVodService, env: Env, job: { id: string; uploadScope: string | null; providerJobId: string | null }) {
  if (job.uploadScope && job.uploadScope !== uploadScope(env)) throw conflict('上传任务的小程序或 Client Key 已改变，不能自动关联旧作用域的媒资。');
  if (job.providerJobId) {
    const [media] = await service.getMediaInfos({ vids: [job.providerJobId] });
    if (!media) return null;
    if (media.spaceName !== env.BYTEPLUS_SPACE_NAME) throw conflict('上传结果不属于当前 BytePlus 空间。');
    if (job.uploadScope && !matchesUploadTags(media.tags, job.uploadScope, job.id)) {
      const scopeTags = (media.tags ?? []).filter((tag) => tag.startsWith('qr-scope-') || /^s[0-9a-f]{16}$/.test(tag));
      const allowed = [uploadTags(job.uploadScope, job.id)[0], legacyUploadTags(job.uploadScope, job.id)[0]];
      if (scopeTags.some((tag) => !allowed.includes(tag))) throw conflict('VID 属于其他小程序，不能自动绑定。');
      return null;
    }
    return media;
  }
  if (!job.uploadScope) return null;
  const matches: BytePlusMedia[] = [];
  const taskTag = uploadTags(job.uploadScope, job.id)[1];
  for (let offset = 0; ; offset += 100) {
    const page = await service.listMedia({ offset, pageSize: 100, tags: taskTag });
    matches.push(...page.items.filter((media) => media.spaceName === env.BYTEPLUS_SPACE_NAME && matchesUploadTags(media.tags, job.uploadScope!, job.id)));
    if (page.items.length < 100 || offset + page.items.length >= page.total) break;
    if (offset >= 9_900) throw new Error('VOD 查询结果超过上限，无法确认完整结果，请检查媒资标签。');
  }
  const unique = [...new Map(matches.map((media) => [media.vid, media])).values()];
  if (unique.length > 1) throw conflict('同一上传任务出现多个 VID，已暂停自动绑定，请核查 BytePlus 媒资。');
  return unique[0] ?? null;
}

export async function processLocalUploadJobs(prisma: Db, sharedPrisma: Db, service: BytePlusVodService, env: Env, options: { jobId?: string; concurrency?: 1 | 2; now?: () => Date; maxRetries?: number; log?: (message: string, details?: Record<string, unknown>) => void } = {}) {
  const now = options.now ?? (() => new Date());
  const jobs = await prisma.uploadJob.findMany({
    where: { ...(options.jobId ? { id: options.jobId } : {}), sourceType: 'FILE', status: { in: ['PENDING', 'PROCESSING'] },
      AND: [
        { OR: [{ nextAttemptAt: null }, { nextAttemptAt: { lte: now() } }] },
        { OR: [{ leaseExpiresAt: { lte: now() } }, { leaseExpiresAt: null, status: 'PENDING' },
          { leaseExpiresAt: null, status: 'PROCESSING', nextAttemptAt: { not: null } },
          { leaseExpiresAt: null, status: 'PROCESSING', startedAt: { lte: new Date(now().getTime() - 10 * 60_000) } }] }
      ] },
    orderBy: { createdAt: 'asc' }, take: 5,
    include: { episode: { include: { album: true, coverAsset: true } } }
  });
  const processJob = async (job: typeof jobs[number]) => {
    const leaseToken = randomUUID();
    const remoteStartedAt = !job.providerJobId && isBytePlusTransferFailure(job.errorMessage ?? '') ? null : job.remoteStartedAt;
    const claimed = await prisma.uploadJob.updateMany({ where: { id: job.id, status: job.status, leaseToken: job.leaseToken, leaseExpiresAt: job.leaseExpiresAt }, data: { status: 'PROCESSING', leaseToken, leaseExpiresAt: new Date(now().getTime() + leaseMs), startedAt: job.startedAt ?? now(), remoteStartedAt } });
    if (!claimed.count) return;
    let lostLease = false;
    let attemptedUpload = false;
    const renew = setInterval(() => {
      const next = new Date(now().getTime() + leaseMs);
      void prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: { leaseExpiresAt: next } })
        .then((result) => { if (!result.count) lostLease = true; })
        .catch(() => { lostLease = true; });
    }, 30_000);
    const fail = async (message: string, definite = false) => prisma.$transaction(async (tx) => {
      const changed = await tx.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: { status: 'FAILED', errorMessage: message, ...(definite ? { remoteStartedAt: null } : {}), leaseToken: null, leaseExpiresAt: null, nextAttemptAt: null, completedAt: now() } });
      if (changed.count) await tx.episode.updateMany({ where: { id: job.episodeId, byteplusVid: null, uploadJobs: { none: { status: { in: ['PENDING', 'PROCESSING'] } } } }, data: { status: 'ERROR', byteplusUploadStatus: 'FAILED' } });
    });
    try {
      if (job.uploadScope && job.uploadScope !== uploadScope(env)) throw conflict('上传任务的小程序或 Client Key 已改变，不能继续上传。');
      let media: BytePlusMedia | null = null;
      if (job.providerJobId || remoteStartedAt) {
        try {
          media = await findUploadMedia(service, env, job);
        } catch (error) {
          if ((error as { statusCode?: number }).statusCode) throw error;
          const message = error instanceof Error ? error.message.slice(0, 400) : 'VOD 查询失败。';
          await prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: {
            leaseToken: null, leaseExpiresAt: null, nextAttemptAt: new Date(now().getTime() + recoveryDelayMs),
            errorMessage: `上传结果待确认，VOD 查询暂不可用，稍后自动重试：${message}`
          } });
          return;
        }
      }
      if (!media && remoteStartedAt && now().getTime() - remoteStartedAt.getTime() < recoveryWindowMs) {
        await prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: { leaseToken: null, leaseExpiresAt: null, nextAttemptAt: new Date(now().getTime() + recoveryDelayMs), errorMessage: `BytePlus 上传结果待确认，正在核查任务 VID。${job.errorMessage ? `上次错误：${job.errorMessage}` : ''}`.slice(0, 500) } });
        return;
      }
      if (!media && remoteStartedAt && /InvalidParameter\.InvalidParamErro/i.test(job.errorMessage ?? '')) {
        await fail('BytePlus 已拒绝上次上传请求（InvalidParameter.InvalidParamError）。旧版错误详情已截断；请检查上传参数后重试保留的文件。', true);
        return;
      }
      if (!media) {
        if (!job.localFilePath || !job.uploadScope) {
          await fail('上传已中断，未找到可确认归属的 VID，原临时文件已丢失。任务已解除占用，请在当前小程序重新选择文件上传。');
          return;
        }
        if (job.providerJobId) { await fail('已记录的 VID 在 BytePlus 中不存在，请重新上传。'); return; }
        if (job.episode.byteplusVid) { await fail('分集已绑定其他视频，已停止旧上传任务。'); return; }
        if (job.retryCount >= (options.maxRetries ?? env.UPLOAD_MAX_RETRIES)) { await fail(job.errorMessage ?? '自动上传重试次数已耗尽，请重试原任务或重新选择文件上传。'); return; }
        const directory = localUploadDirectory(env);
        const path = relative(directory, resolve(job.localFilePath));
        if (!path || path.startsWith('..') || isAbsolute(path)) throw conflict('上传文件不在配置的持久化目录中。');
        await stat(job.localFilePath);
        const started = await prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: { remoteStartedAt: now(), retryCount: { increment: 1 }, errorMessage: null, nextAttemptAt: null } });
        if (!started.count || lostLease) return;
        attemptedUpload = true;
        const result = await service.uploadLocalVideo({ filePath: job.localFilePath, fileName: job.sourceName ?? 'episode.mp4',
          title: episodeMediaTitle(job.episode.album.title, job.episode.episodeNo),
          spaceName: env.BYTEPLUS_SPACE_NAME, byteplusAccountId: env.BYTEPLUS_ACCOUNT_ID, tags: uploadTags(job.uploadScope, job.id) });
        // Persist the VID before binding so a database failure never starts another upload.
        const recorded = await prisma.uploadJob.updateMany({ where: { id: job.id, leaseToken, status: 'PROCESSING' }, data: { providerJobId: result.byteplusVid } });
        if (!recorded.count || lostLease) throw new BytePlusVodError('上传已完成，任务占用发生变化，正在自动查询 VOD 确认结果。', true, true);
        // The upload response alone does not prove that VOD stored the expected scope tags.
        const [confirmed] = await service.getMediaInfos({ vids: [result.byteplusVid] });
        if (!confirmed) {
          await prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: {
            leaseToken: null, leaseExpiresAt: null, nextAttemptAt: new Date(now().getTime() + recoveryDelayMs),
            errorMessage: 'BytePlus 已返回 VID，正在等待媒资可查询后确认归属。'
          } });
          return;
        }
        if (confirmed.vid !== result.byteplusVid || confirmed.spaceName !== env.BYTEPLUS_SPACE_NAME ||
            !matchesUploadTags(confirmed.tags, job.uploadScope, job.id)) {
          throw conflict('BytePlus 返回的媒资缺少当前上传任务的归属标签，已停止自动绑定。');
        }
        media = confirmed;
      }
      if (lostLease) return;
      await assertMediaScope(sharedPrisma, env, media);
      await getOrCreateSharedMediaAsset(sharedPrisma as any, { byteplusVid: media.vid, byteplusAccountId: env.BYTEPLUS_ACCOUNT_ID,
        byteplusSpaceName: env.BYTEPLUS_SPACE_NAME, byteplusRegion: env.BYTEPLUS_REGION, miniAppKey: env.MINI_APP_KEY,
        title: media.title, coverUrl: media.coverUrl, durationMs: media.durationMs, firstUploadJobId: job.id, sourceFileName: job.sourceName ?? undefined });
      await prisma.$transaction(async (tx) => {
        const changed = await tx.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: { status: 'SUCCEEDED', providerJobId: media!.vid, completedAt: now(), errorMessage: null, leaseToken: null, leaseExpiresAt: null, nextAttemptAt: null, localFilePath: null } });
        if (!changed.count) throw new Error('上传任务已由其他操作接管。');
        const bound = await tx.episode.updateMany({ where: { id: job.episodeId, OR: [{ byteplusVid: null }, { byteplusVid: media!.vid }] }, data: { status: 'READY', byteplusUploadStatus: 'READY', byteplusVid: media!.vid, byteplusCoverUrl: media!.coverUrl,
          coverUrl: job.episode.coverAsset?.status === 'READY' ? job.episode.coverAsset.publicUrl : media!.coverUrl, durationMs: media!.durationMs,
          tiktokVideoStatus: 'NOT_STARTED', tiktokVideoJobId: null, tiktokVideoError: null } });
        if (!bound.count) throw new Error('分集已绑定其他 VID，无法覆盖。');
      });
      if (job.localFilePath) await unlink(job.localFilePath).catch(() => undefined);
      if (env.TIKTOK_CLIENT_KEY && env.TIKTOK_CLIENT_SECRET) await enqueueVideoSync(prisma as any, job.episodeId).catch((error) => options.log?.('Could not enqueue video sync.', { jobId: job.id, error: String(error) }));
    } catch (error) {
      const message = error instanceof Error ? error.message.slice(0, 500) : '视频上传失败。';
      const retryable = error instanceof BytePlusVodError ? error.retryable : (error as NodeJS.ErrnoException).code !== 'ENOENT' && !(error as { statusCode?: number }).statusCode;
      const uncertain = error instanceof BytePlusVodError && error.uncertain;
      const attempts = job.retryCount + (attemptedUpload ? 1 : 0);
      if (retryable && attempts < (options.maxRetries ?? env.UPLOAD_MAX_RETRIES)) {
        await prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken }, data: { ...(!attemptedUpload ? { retryCount: { increment: 1 } } : {}), ...(!uncertain && !job.providerJobId ? { remoteStartedAt: null } : {}), leaseToken: null, leaseExpiresAt: null, nextAttemptAt: new Date(now().getTime() + recoveryDelayMs), errorMessage: `${uncertain ? '上传结果待确认' : '上传失败，稍后重试'}：${message}` } });
      } else await fail(message, error instanceof BytePlusVodError && !error.retryable && !error.uncertain);
      options.log?.('Local upload recovery.', { jobId: job.id, error: message });
    } finally { clearInterval(renew); }
  };
  let nextJob = 0;
  const workers = Array.from({ length: Math.min(options.jobId ? 1 : options.concurrency ?? 1, jobs.length) }, async () => {
    while (nextJob < jobs.length) await processJob(jobs[nextJob++]);
  });
  const results = await Promise.allSettled(workers);
  const failed = results.find((result): result is PromiseRejectedResult => result.status === 'rejected');
  if (failed) throw failed.reason;
  return jobs.length;
}
