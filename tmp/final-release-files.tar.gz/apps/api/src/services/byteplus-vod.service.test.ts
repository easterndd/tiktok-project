import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import type { Env } from '../config/env';
import { BytePlusVodService } from './byteplus-vod.service';

const env: Env = {
  NODE_ENV: 'test',
  PORT: 3000,
  HOST: '127.0.0.1',
  DATABASE_URL: 'postgresql://test:test@localhost:5432/test',
  MINI_APP_KEY: 'main',
  API_CORS_ORIGIN: 'http://localhost:5173',
  TRUST_GEO_COUNTRY_HEADER: false,
  TRUSTED_PROXY_CIDRS: '',
  JWT_SECRET: 'test-secret-that-is-longer-than-32-characters',
  USER_JWT_EXPIRES_IN: 3_600,
  ADMIN_JWT_EXPIRES_IN: 28_800,
  ADMIN_BOOTSTRAP_EMAIL: undefined,
  ADMIN_BOOTSTRAP_PASSWORD: undefined,
  BYTEPLUS_ACCOUNT_ID: 'test-account',
  BYTEPLUS_SPACE_NAME: 'test-space',
  BYTEPLUS_REGION: 'ap-southeast-1',
  BYTEPLUS_ACCESS_KEY: 'test-access-key',
  BYTEPLUS_SECRET_KEY: 'test-secret-key',
  BYTEPLUS_VOD_ENDPOINT: 'https://vod.byteplusapi.com',
  TIKTOK_CLIENT_KEY: undefined,
  TIKTOK_CLIENT_SECRET: undefined,
  TIKTOK_APP_ID: undefined,
  TALETV_TIKTOK_CLIENT_KEY: undefined,
  TALETV_TIKTOK_CLIENT_SECRET: undefined,
  TALETV_TIKTOK_APP_ID: undefined,
  REWARDED_PLACEMENT_ID: 'ad7686459794040702993',
  TALETV_REWARDED_PLACEMENT_ID: 'ad7688599028879722512',
  APP_ENTRY_PLACEMENT_ID: 'ad7686459458972829697',
  TALETV_APP_ENTRY_PLACEMENT_ID: '',
  TIKTOK_SHORT_DRAMA_API_BASE: 'https://open.tiktokapis.com',
  API_PUBLIC_BASE_URL: undefined,
  COVER_ASSET_STORAGE_DIR: 'tmp/cover-assets-test',
  COVER_ASSET_PUBLIC_BASE_URL: undefined,
  LOCAL_PLAYBACK_ENABLED: false,
  UPLOAD_WORKER_INTERVAL_MS: 30_000,
  UPLOAD_MAX_RETRIES: 5
};

function okJson(body: unknown) {
  return new Response(JSON.stringify(body), {
    status: 200,
    headers: { 'content-type': 'application/json' }
  });
}

describe('BytePlusVodService', () => {
  it('requests HTTPS playback URLs in the signed play auth token', async () => {
    let signed: { query: unknown; expires?: number } | undefined;
    const service = new BytePlusVodService(env, {
      vodService: {
        GetPlayAuthToken: (query: unknown, expires: number) => {
          signed = { query, expires };
          return 'signed-token';
        }
      } as never
    });

    assert.equal(await service.getPlayAuthToken({ vid: 'vid-1' }), 'signed-token');
    assert.deepEqual(signed, { query: { Vid: 'vid-1', Ssl: '1' }, expires: 900 });

    const realSdkToken = await new BytePlusVodService(env).getPlayAuthToken({ vid: 'vid-1' });
    const decoded = JSON.parse(Buffer.from(realSdkToken, 'base64').toString('utf8')) as { GetPlayInfoToken: string };
    assert.match(decoded.GetPlayInfoToken, /(?:^|&)Ssl=1(?:&|$)/);
  });

  it('uses HTTPS transfer even when the SDK exposes its unbounded HTTP uploader', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-sdk-upload-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      let request: Record<string, unknown> | undefined;
      const service = new BytePlusVodService(env, {
        vodService: {
          UploadMedia: async () => { throw new Error('Must not use unbounded HTTP upload'); },
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'video.mp4', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async (input: Record<string, unknown>) => {
            request = input;
            return { Result: { Data: { Vid: 'vid-sdk', PosterUri: 'cover', SourceInfo: { Duration: 12 } } } };
          }
        } as never,
        uploadFetch: async (url, init) => {
          assert.equal(new URL(String(url)).protocol, 'https:');
          assert.ok(init?.signal);
          assert.equal(Buffer.from(init?.body as Uint8Array).toString(), 'video-data');
          return new Response('', { status: 200 });
        }
      });
      const result = await service.uploadLocalVideo({ filePath, fileName: '第1集.mp4', title: 'TaleTV - 第1集', spaceName: 'space', byteplusAccountId: 'account', tags: ['qr-scope-test', 'qr-upload-job'] });
      assert.equal(result.byteplusVid, 'vid-sdk');
      assert.equal(request?.SpaceName, 'space');
      assert.equal(request?.SessionKey, 'session');
      assert.equal(JSON.parse(String(request?.Functions))[1].Input.Title, 'TaleTV - 第1集');
      assert.equal(JSON.parse(String(request?.Functions))[1].Input.Tags, 'qr-scope-test,qr-upload-job');
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('rejects tags longer than the BytePlus limit before uploading', async () => {
    let uploads = 0;
    const service = new BytePlusVodService(env, { vodService: {
      UploadMedia: async () => { uploads++; return { Result: { Data: { Vid: 'unexpected' } } }; }
    } as never });
    await assert.rejects(() => service.uploadLocalVideo({ filePath: 'unused.mp4', fileName: 'episode.mp4',
      title: 'Episode 1', spaceName: 'space', byteplusAccountId: 'account', tags: ['a'.repeat(37)] }), /36 字节/);
    assert.equal(uploads, 0);
  });

  it('uploads a local file with a unique object name and a visible media title', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-upload-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      const requests: Array<{ url: URL; init: RequestInit }> = [];
      let appliedName = '';
      let appliedSize = 0;
      let committedFunctions = '';
      const vodService = {
        ApplyUploadInfo: async (input: { FileName: string; FileExtension?: string; FileSize?: number }) => {
          appliedName = input.FileName;
          appliedSize = input.FileSize ?? 0;
          assert.equal(input.FileExtension, undefined);
          return { Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'objects/video.mp4', Auth: 'secret' }], UploadHosts: ['upload.example.com'], UploadHeader: [{ Key: 'X-Upload-Token', Value: 'upload-token' }] } } } };
        },
        CommitUploadInfo: async (input: { Functions: string }) => {
          committedFunctions = input.Functions;
          return { Result: { Data: { Vid: 'vid-1', PosterUri: 'cover', SourceInfo: { Duration: 42 } } } };
        }
      };
      const service = new BytePlusVodService(env, {
        vodService: vodService as never,
        uploadFetch: async (url, init) => {
          requests.push({ url: new URL(String(url)), init: init ?? {} });
          return new Response('', { status: 200 });
        }
      });
      const result = await service.uploadLocalVideo({ filePath, fileName: '第1集.mp4', title: 'TaleTV - 第1集', spaceName: 'space', byteplusAccountId: 'account' });
      assert.equal(result.byteplusVid, 'vid-1');
      assert.equal(appliedSize, Buffer.byteLength('video-data'));
      assert.match(appliedName, /^1-[a-f0-9-]+\.mp4$/);
      assert.equal(JSON.parse(committedFunctions)[1].Input.Title, 'TaleTV - 第1集');
      assert.equal(requests.length, 1);
      const headers = new Headers(requests[0].init.headers);
      assert.equal(headers.get('X-Upload-Token'), 'upload-token');
      assert.equal(headers.get('Content-CRC32')?.length, 8);
      assert.equal(headers.get('Content-Type'), null);
      assert.equal(headers.get('Accept'), null);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('uses BytePlus merge checksum positions for a multipart upload', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-parts-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.alloc(20 * 1024 * 1024 + 1, 1));
      const requests: Array<{ query: string; body?: BodyInit | null; headers: Headers }> = [];
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => ({ Result: { Data: { Vid: 'vid-2' } } })
        } as never,
        uploadFetch: async (url, init) => {
          const query = new URL(String(url)).search;
          requests.push({ query, body: init?.body, headers: new Headers(init?.headers) });
          return query === '?uploads' ? Response.json({ payload: { uploadID: 'upload-1' } }) : new Response('', { status: 200 });
        }
      });
      await service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: '第2集', spaceName: 'space', byteplusAccountId: 'account' });
      assert.equal(requests.length, 5);
      for (const request of requests) {
        assert.equal(request.headers.get('Content-Type'), null);
        assert.equal(request.headers.get('Accept'), null);
      }
      assert.equal(requests[0].headers.get('X-Storage-Mode'), 'gateway');
      assert.deepEqual(requests.slice(1, -1).map((request) => new URLSearchParams(request.query).get('partNumber')).sort(), ['1', '2', '3']);
      assert.match(String(requests.at(-1)?.body), /^0:[a-f0-9]{8},1:[a-f0-9]{8},2:[a-f0-9]{8}$/);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('retries a failed HTTPS part without restarting successful parts or committing early', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-part-retry-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.alloc(20 * 1024 * 1024 + 1, 1));
      const parts: string[] = [];
      let merged = false;
      let commits = 0;
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => {
            assert.equal(merged, true);
            commits++;
            return { Result: { Data: { Vid: 'vid-retried' } } };
          }
        } as never,
        uploadFetch: async (url, init) => {
          const target = new URL(String(url));
          assert.equal(target.protocol, 'https:');
          assert.ok(init?.signal);
          if (target.search === '?uploads') return Response.json({ payload: { uploadID: 'upload-1' } });
          const part = target.searchParams.get('partNumber');
          if (part) {
            parts.push(part);
            if (part === '1' && parts.filter((item) => item === '1').length === 1) return new Response('temporarily unavailable', { status: 503 });
          } else merged = true;
          return new Response('', { status: 200 });
        }
      });
      assert.equal((await service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: 'Episode', spaceName: 'space', byteplusAccountId: 'account' })).byteplusVid, 'vid-retried');
      assert.deepEqual(parts.sort(), ['1', '1', '2', '3']);
      assert.equal(commits, 1);
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it('limits multipart transfers to two in flight and merges in part-number order', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-two-parts-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.alloc(20 * 1024 * 1024 + 1, 1));
      const releases = new Map<string, () => void>();
      const started: string[] = [];
      let peak = 0;
      let active = 0;
      let merged = false;
      let firstTwo!: () => void;
      let third!: () => void;
      const firstTwoStarted = new Promise<void>((resolve) => { firstTwo = resolve; });
      const thirdStarted = new Promise<void>((resolve) => { third = resolve; });
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => {
            assert.equal(merged, true);
            return { Result: { Data: { Vid: 'vid-parallel' } } };
          }
        } as never,
        uploadFetch: async (url, init) => {
          const query = new URL(String(url)).searchParams;
          if (query.has('uploads')) return Response.json({ payload: { uploadID: 'upload-1' } });
          const part = query.get('partNumber');
          if (!part) {
            assert.equal(active, 0);
            assert.match(String(init?.body), /^0:([a-f0-9]{8}),1:\1,2:[a-f0-9]{8}$/);
            merged = true;
            return new Response('', { status: 200 });
          }
          started.push(part);
          peak = Math.max(peak, ++active);
          if (started.length === 2) firstTwo();
          if (started.length === 3) third();
          await new Promise<void>((resolve) => { releases.set(part, resolve); });
          active--;
          return new Response('', { status: 200 });
        }
      });
      const upload = service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: 'Episode', spaceName: 'space', byteplusAccountId: 'account' });
      await firstTwoStarted;
      assert.deepEqual(started, ['1', '2']);
      assert.equal(peak, 2);
      releases.get('2')!();
      await thirdStarted;
      assert.deepEqual(started, ['1', '2', '3']);
      assert.equal(peak, 2);
      releases.get('1')!();
      releases.get('3')!();
      assert.equal((await upload).byteplusVid, 'vid-parallel');
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it('does not retry a permanent upload host rejection or commit an incomplete file', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-reject-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      let uploads = 0;
      let commits = 0;
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => { commits++; return { Result: { Data: { Vid: 'unexpected' } } }; }
        } as never,
        uploadFetch: async () => {
          uploads++;
          return Response.json({ code: 'InvalidPart', message: 'Invalid part size Authorization=private-value' }, { status: 400 });
        }
      });
      await assert.rejects(
        () => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: '第3集', spaceName: 'space', byteplusAccountId: 'account' }),
        (error: unknown) => {
          assert.ok(error instanceof Error);
          assert.match(error.message, /直传失败.*HTTP 400 \(InvalidPart\).*Invalid part size/);
          assert.doesNotMatch(error.message, /private-value/);
          return true;
        }
      );
      assert.equal(uploads, 1);
      assert.equal(commits, 0);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('marks commit transport failures as uncertain so the caller reconciles instead of re-uploading', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-uncertain-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => { throw new Error('socket closed after provider accepted commit'); }
        } as never,
        uploadFetch: async () => new Response('', { status: 200 })
      });
      await assert.rejects(
        () => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: 'TaleTV - 第1集', spaceName: 'space', byteplusAccountId: 'account' }),
        (error: unknown) => {
          assert.equal((error as { uncertain?: boolean }).uncertain, true);
          assert.equal((error as { retryable?: boolean }).retryable, true);
          return true;
        }
      );
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('preserves a rejected commit error and does not treat it as an uncertain upload', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-invalid-commit-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      const response = { ResponseMetadata: { RequestId: '202610120818195FA476160CF69C4B0CE4', Action: 'CommitUploadInfo',
        Error: { Code: 'InvalidParameter.InvalidParamError', Message: 'InvalidParameter.InvalidParamError: invalid Functions.Tags Authorization=private-value' } } };
      const service = new BytePlusVodService(env, { vodService: {
        ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'video.mp4', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
        CommitUploadInfo: async () => { throw new Error(JSON.stringify(response)); }
      } as never, uploadFetch: async () => new Response('', { status: 200 }) });
      await assert.rejects(
        () => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: 'Episode 1', spaceName: 'space', byteplusAccountId: 'account' }),
        (error: unknown) => {
          assert.equal((error as { retryable?: boolean }).retryable, false);
          assert.equal((error as { uncertain?: boolean }).uncertain, false);
          assert.match((error as Error).message, /InvalidParameter\.InvalidParamError: invalid Functions\.Tags/);
          assert.doesNotMatch((error as Error).message, /Error: InvalidParameter\.InvalidParamError/);
          assert.match((error as Error).message, /202610120818195FA476160CF69C4B0CE4/);
          assert.doesNotMatch((error as Error).message, /private-value/);
          return true;
        }
      );
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it('distinguishes legacy SDK transfer failures from an unknown commit outcome', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-sdk-failure-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, 'video-data');
      for (const [message, retryable, uncertain] of [
        ['init upload error:AxiosError: socket hang up', true, false],
        ['upload part error:AxiosError: Request failed with status code 503', true, false],
        ['upload merge part error:AxiosError: Request failed with status code 500', true, false],
        ['upload part error:AxiosError: Request failed with status code 400', false, false],
        ['AxiosError: Request failed with status code 503', true, true]
      ] as const) {
        const service = new BytePlusVodService(env, { vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'video.mp4', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => { throw new Error(`Upload Media Error: Error: ${message}`); }
        } as never, uploadFetch: async () => new Response('', { status: 200 }) });
        await assert.rejects(() => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4',
          title: 'Episode 1', spaceName: 'space', byteplusAccountId: 'account' }), (error: unknown) => {
          assert.equal((error as { retryable: boolean }).retryable, retryable, message);
          assert.equal((error as { uncertain: boolean }).uncertain, uncertain, message);
          return true;
        });
      }
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it('keeps a transient commit rejection in reconciliation', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-transient-commit-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      const response = { ResponseMetadata: { Action: 'CommitUploadInfo',
        Error: { Code: 'ServiceUnavailable', Message: 'Try again later' } } };
      const service = new BytePlusVodService(env, { vodService: {
        ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'video.mp4', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
        CommitUploadInfo: async () => response
      } as never, uploadFetch: async () => new Response('', { status: 200 }) });
      await assert.rejects(
        () => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: 'Episode 1', spaceName: 'space', byteplusAccountId: 'account' }),
        (error: unknown) => {
          assert.equal((error as { retryable?: boolean }).retryable, true);
          assert.equal((error as { uncertain?: boolean }).uncertain, true);
          return true;
        }
      );
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it('identifies multipart initialization errors from the upload host', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-init-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.alloc(20 * 1024 * 1024 + 1, 1));
      let commits = 0;
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => { commits++; return { Result: { Data: { Vid: 'unexpected' } } }; }
        } as never,
        uploadFetch: async () => new Response('<Error><Code>InvalidArgument</Code><Message>Missing storage mode</Message></Error>', { status: 400 })
      });
      await assert.rejects(
        () => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: '第1集', spaceName: 'space', byteplusAccountId: 'account' }),
        /分片初始化失败.*HTTP 400 \(InvalidArgument\).*Missing storage mode/
      );
      assert.equal(commits, 0);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('reports an empty multipart initialization response with status and content type', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-empty-init-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.alloc(20 * 1024 * 1024 + 1, 1));
      let requests = 0;
      let commits = 0;
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => { commits++; return { Result: { Data: { Vid: 'unexpected' } } }; }
        } as never,
        uploadFetch: async () => { requests++; return new Response('', { status: 200, headers: { 'content-type': 'text/plain' } }); }
      });
      await assert.rejects(
        () => service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: '第1集', spaceName: 'space', byteplusAccountId: 'account' }),
        /分片初始化返回空响应：主机 upload\.example\.com，HTTP 200，Content-Type text\/plain/
      );
      assert.equal(requests, 3);
      assert.equal(commits, 0);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('retries an empty initialization response before uploading file parts', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-empty-retry-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.alloc(20 * 1024 * 1024 + 1, 1));
      let initializations = 0;
      let commits = 0;
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['upload.example.com'] } } } }),
          CommitUploadInfo: async () => { commits++; return { Result: { Data: { Vid: 'vid-recovered' } } }; }
        } as never,
        uploadFetch: async (url) => {
          if (new URL(String(url)).search === '?uploads') {
            initializations++;
            return initializations === 1 ? new Response('', { status: 200 })
              : Response.json({ payload: { uploadID: 'upload-1' } });
          }
          return new Response('', { status: 200 });
        }
      });
      const result = await service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: '第1集', spaceName: 'space', byteplusAccountId: 'account' });
      assert.equal(initializations, 2);
      assert.equal(commits, 1);
      assert.equal(result.byteplusVid, 'vid-recovered');
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('falls back to the next upload host when the first host is unavailable', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'byteplus-fallback-'));
    try {
      const filePath = join(directory, 'episode.mp4');
      await writeFile(filePath, Buffer.from('video-data'));
      const hosts: string[] = [];
      const service = new BytePlusVodService(env, {
        vodService: {
          ApplyUploadInfo: async () => ({ Result: { Data: { UploadAddress: { SessionKey: 'session', StoreInfos: [{ StoreUri: 'object', Auth: 'secret' }], UploadHosts: ['first.example.com', 'second.example.com'] } } } }),
          CommitUploadInfo: async () => ({ Result: { Data: { Vid: 'vid-fallback' } } })
        } as never,
        uploadFetch: async (url) => {
          const host = new URL(String(url)).hostname;
          hosts.push(host);
          return new Response('', { status: host === 'first.example.com' ? 503 : 200 });
        }
      });
      const result = await service.uploadLocalVideo({ filePath, fileName: 'episode.mp4', title: '第4集', spaceName: 'space', byteplusAccountId: 'account' });
      assert.equal(result.byteplusVid, 'vid-fallback');
      assert.deepEqual(hosts, ['first.example.com', 'first.example.com', 'first.example.com', 'second.example.com']);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  });

  it('creates a signed UploadMediaByUrl request and returns the provider JobId', async () => {
    let requestedUrl = '';
    let authorization = '';
    const service = new BytePlusVodService(env, {
      now: () => new Date('2026-09-10T00:00:00.000Z'),
      fetch: async (input, init) => {
        requestedUrl = String(input);
        authorization = String(init?.headers && (init.headers as Record<string, string>).Authorization);
        return okJson({ Result: { Data: [{ SourceUrl: 'https://cdn.example.com/ep1.mp4', JobId: 'job-1' }] } });
      }
    });

    const result = await service.createVideoUpload({
      sourceUrl: 'https://cdn.example.com/ep1.mp4',
      title: 'Episode 1',
      spaceName: 'test-space',
      byteplusAccountId: 'test-account'
    });

    assert.equal(result.providerJobId, 'job-1');
    const requestUrl = new URL(requestedUrl);
    assert.equal(requestUrl.searchParams.get('Action'), 'UploadMediaByUrl');
    assert.equal(requestUrl.searchParams.get('Version'), '2023-01-01');
    assert.equal(requestUrl.searchParams.get('SpaceName'), 'test-space');
    assert.match(authorization, /^HMAC-SHA256 Credential=test-access-key\/20260910\/ap-southeast-1\/vod\/request,/);
    const urlSets = JSON.parse(requestUrl.searchParams.get('URLSets') ?? '[]') as Array<Record<string, unknown>>;
    assert.equal(urlSets[0].SourceUrl, 'https://cdn.example.com/ep1.mp4');
    assert.equal(urlSets[0].FileName, 'Episode-1-1788998400000.mp4');
  });

  it('maps QueryUploadTaskInfo success to the worker upload status shape', async () => {
    const service = new BytePlusVodService(env, {
      now: () => new Date('2026-09-10T00:00:00.000Z'),
      fetch: async () => okJson({
        Result: {
          Data: {
            MediaInfoList: [{
              JobId: 'job-1',
              State: 'success',
              Vid: 'vid-1',
              AccountId: 'test-account',
              SourceInfo: { Duration: 12.345 }
            }]
          }
        }
      })
    });

    const status = await service.getVideoUploadStatus({
      providerJobId: 'job-1',
      byteplusAccountId: 'test-account'
    });

    assert.equal(status.status, 'SUCCEEDED');
    assert.equal(status.byteplusVid, 'vid-1');
    assert.equal(status.durationMs, 12_345);
  });
});
