import { combinePlaybackSummaries } from '../../services/analytics-playback-summary';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import { createHash, randomUUID } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import { mkdir, readFile, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pipeline } from 'node:stream/promises';
import { Prisma, type AnalyticsDailySummary } from '@prisma/client';
import { z } from 'zod';
import { requireAdmin, requirePermission } from '../../plugins/auth';
import { hashPassword, verifyPassword } from '../../services/password';
import { accessConfigSchema, readMiniAppAccessConfig } from '../../lib/content-access';
import { publicLocaleSchema } from '../../lib/locales';
import { BytePlusVodService } from '../../services/byteplus-vod.service';
import { assertMediaScope, localUploadDirectory, matchesUploadTags, processLocalUploadJobs, uploadScope, uploadTags } from '../../services/local-upload.service';
import { LocalObjectStorageService } from '../../services/object-storage.service';
import { defaultUiComponents } from '../ui/routes';
import { readAppEntryAdPolicy } from '../app-entry-ads/routes';
import {
  enqueueAlbumAction,
  enqueueAlbumVersionSync,
  enqueueCoverSync,
  enqueueVideoSync
} from '../../services/platform-sync.service';
import {
  bindEpisodeToSharedMedia,
  enqueueSharedAlbumReconcile,
  getOrCreateSharedMediaAsset,
  listSharedMediaAssets,
} from '../../services/shared-platform.service';
import { authorizeSharedPlayback, sharedPlaybackStatus } from '../../services/shared-playback.service';
import { assertSameMiniAppOrganization, miniAppAdConfig, miniAppKeys, sameMiniAppOrganization, type MiniAppKey } from '../../config/mini-apps';
import { assertDisplayMetadataOwner, carryBaseTextChanges, displayMetadataInput, findDisplayMetadataAlbum, readDisplayMetadata, retryDisplayMetadata, saveLocalDisplayMetadata, saveSharedDisplayMetadata } from '../../services/display-metadata.service';

const albumParams = z.object({ albumId: z.string().min(1).max(128) });

type AnalyticsCacheEntry = { expiresAt: number; value: unknown };
const analyticsCaches = new WeakMap<FastifyInstance, Map<string, AnalyticsCacheEntry>>();
const ANALYTICS_CACHE_TTL_MS = 15_000;
async function cachedAnalytics<T>(app: FastifyInstance, key: string, load: () => Promise<T>): Promise<T> {
  const analyticsCache = analyticsCaches.get(app) ?? new Map<string, AnalyticsCacheEntry>();
  analyticsCaches.set(app, analyticsCache);
  const now = Date.now();
  const cached = analyticsCache.get(key);
  if (cached && cached.expiresAt > now) return cached.value as T;
  const value = await load();
  analyticsCache.set(key, { expiresAt: now + ANALYTICS_CACHE_TTL_MS, value });
  if (analyticsCache.size > 100) {
    for (const [entryKey, entry] of analyticsCache) if (entry.expiresAt <= now) analyticsCache.delete(entryKey);
  }
  return value;
}
async function checkDisplayMetadataOwner(app: FastifyInstance, request: FastifyRequest, shared: any) {
  const operator = await app.prisma.adminUser.findUniqueOrThrow({ where: { id: request.user.sub } });
  const sourceIds = await playbackAdminIds(app, request, [shared.ownerMiniAppKey as MiniAppKey]);
  await assertDisplayMetadataOwner(shared, app.miniAppPrisma as any, app.config.MINI_APP_KEY, request.user.role, operator.email, sourceIds[shared.ownerMiniAppKey as MiniAppKey]);
  return `${app.config.MINI_APP_KEY}:${operator.id}`;
}
async function saveAlbumTranslationCover(app: FastifyInstance, albumId: string, locale: string, coverUrl: string | null | undefined) {
  const existing = await app.prisma.albumTranslation.findUnique({ where: { albumId_locale: { albumId, locale } } });
  if (existing) return app.prisma.albumTranslation.update({ where: { id: existing.id }, data: { coverUrl } });
  const view = await readDisplayMetadata(app.sharedPrisma as any, app.miniAppPrisma as any, app.config.MINI_APP_KEY, albumId);
  const text = view.translations.find((item) => item.locale === locale) ?? { title: view.title, description: view.description };
  // The text worker may not have created a new locale yet. Never use client text in this path.
  return app.prisma.albumTranslation.upsert({ where: { albumId_locale: { albumId, locale } },
    create: { albumId, locale, title: text.title, description: text.description, coverUrl }, update: { coverUrl } });
}
async function assertPlatformOwner(app: FastifyInstance, albumId: string) {
  const shared = await app.sharedPrisma.miniAppAlbumAuthorization.findFirst({ where: {
    miniAppKey: app.config.MINI_APP_KEY, targetLocalAlbumId: albumId,
    album: { ownerMiniAppKey: { not: app.config.MINI_APP_KEY } }
  } });
  if (shared) throw Object.assign(new Error('此剧目是授权播放副本，平台版本、审核和上下架由主小程序管理；请使用授权对账。'), { statusCode: 409 });
}
const episodeParams = z.object({ episodeId: z.string().min(1).max(128) });
const albumInput = z.object({
  title: z.string().trim().min(1).max(160),
  description: z.string().trim().max(20_000).default(''),
  coverUrl: z.string().url().optional(),
  coverAssetId: z.string().min(1).max(128).optional().nullable(),
  language: z.string().min(2).max(10).default('en'),
  releaseYear: z.number().int().min(1900).max(2100).optional().nullable(),
  dramaType: z.number().int().positive().optional().nullable(),
  tagList: z.array(z.number().int().positive()).min(1).max(3).optional().nullable(),
  regions: z.array(z.string().min(2).max(32)).optional(),
  accessConfig: accessConfigSchema.optional()
});
const albumPatch = albumInput.partial().extend({
  description: albumInput.shape.description.removeDefault().optional(),
  language: albumInput.shape.language.removeDefault().optional()
});
const episodeInput = z.object({
  albumId: z.string().min(1).max(128),
  episodeNo: z.number().int().positive(),
  title: z.string().trim().min(1).max(160),
  description: z.string().trim().max(20_000).optional(),
  coverUrl: z.string().url().optional(),
  coverAssetId: z.string().min(1).max(128).optional().nullable(),
  durationMs: z.number().int().positive().optional(),
  isFree: z.boolean().default(false),
  sortOrder: z.number().int().positive().optional()
});
const episodePatch = episodeInput.omit({ albumId: true, episodeNo: true }).partial().extend({
  isFree: episodeInput.shape.isFree.removeDefault().optional()
});
const mediaBindingInput = z.object({
  byteplusVid: z.string().trim().min(1).max(256),
  coverAssetId: z.string().min(1).max(128).nullable().optional(),
  byteplusCoverUrl: z.string().url().optional().nullable(),
  durationMs: z.number().int().positive().optional().nullable()
});
const sharedMediaBindingInput = z.object({
  sharedMediaAssetId: z.string().trim().min(1).max(128)
});
const playbackTargetsInput = z.array(z.enum(miniAppKeys)).min(1).max(miniAppKeys.length - 1);
const sharedPlaybackInput = z.object({
  targetApps: playbackTargetsInput,
  action: z.enum(['AUTHORIZE', 'RECONCILE'])
}).strict();

async function playbackAdminIds(app: FastifyInstance, request: FastifyRequest, targets: MiniAppKey[]) {
  const ids: Partial<Record<MiniAppKey, string>> = { [app.config.MINI_APP_KEY]: request.user.sub };
  const header = request.headers['x-multi-app-tokens'];
  if (typeof header !== 'string') return ids;
  if (header.length > 16_000) throw Object.assign(new Error('目标小程序授权信息过长。'), { statusCode: 400 });
  let tokens: Record<string, unknown>;
  try {
    const parsed = JSON.parse(header) as unknown;
    tokens = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed as Record<string, unknown> : {};
  } catch {
    throw Object.assign(new Error('目标小程序授权信息格式错误。'), { statusCode: 400 });
  }
  for (const target of targets) {
    if (target === app.config.MINI_APP_KEY || typeof tokens[target] !== 'string') continue;
    let payload: { sub?: string; kind?: string; appKey?: string; tokenVersion?: number };
    try { payload = app.jwt.verify(tokens[target] as string) as typeof payload; } catch { continue; }
    if (payload?.kind !== 'admin' || payload.appKey !== target || payload.tokenVersion === undefined || !payload.sub) continue;
    const admin = await app.miniAppPrisma[target]?.adminUser.findUnique({ where: { id: payload.sub }, select: { role: true, status: true, tokenVersion: true } });
    if (admin?.role === 'OWNER' && admin.status === 'ACTIVE' && admin.tokenVersion === payload.tokenVersion) ids[target] = payload.sub;
  }
  return ids;
}
const uploadInput = z.object({
  episodeId: z.string().min(1).max(128),
  sourceUrl: z.string().url().refine((value) => ['http:', 'https:'].includes(new URL(value).protocol), '来源地址必须使用 HTTP 或 HTTPS。'),
  sourceExpiresAt: z.string().datetime().optional()
});
const dramaInput = z.object({
  title: z.string().trim().min(1).max(160),
  description: z.string().trim().max(20_000).default(''),
  coverAssetId: z.string().min(1).max(128),
  language: z.string().min(2).max(10).default('en'),
  releaseYear: z.number().int().min(1900).max(2100),
  dramaType: z.number().int().positive(),
  tagList: z.array(z.number().int().positive()).min(1).max(3),
  regions: z.array(z.string().min(2).max(32)).optional(),
  accessConfig: accessConfigSchema.optional(),
  episodes: z.array(z.object({
    episodeNo: z.number().int().positive(),
    title: z.string().trim().min(1).max(160),
    description: z.string().trim().max(20_000).optional(),
    sortOrder: z.number().int().positive().optional(),
    isFree: z.boolean().default(false),
    coverAssetId: z.string().min(1).max(128).optional().nullable(),
    byteplusVid: z.string().trim().min(1).max(256).optional()
  })).min(1).max(500)
});
const appendEpisodesInput = z.object({ episodes: dramaInput.shape.episodes });
const jobParams = z.object({ jobId: z.string().min(1).max(128) });
const blockParams = z.object({ blockId: z.string().min(1).max(128) });
const blockItemParams = z.object({ blockId: z.string().min(1).max(128), itemId: z.string().min(1).max(128) });
const componentParams = z.object({ key: z.enum(['APP_TOPBAR', 'APP_BOTTOM_NAV', 'HOME_INTRO', 'HOME_FEED', 'ALBUM_DESCRIPTION', 'PROFILE_HISTORY', 'PROFILE_FAVORITES']) });
const uiComponentPageInput = z.enum(['APP', 'HOME', 'ALBUM', 'PROFILE']);
const uiComponentConfigInput = z.record(z.string(), z.unknown()).nullable().optional();
const uiComponentSnapshotInput = z.array(z.object({
  key: componentParams.shape.key,
  page: uiComponentPageInput,
  enabled: z.boolean(),
  config: uiComponentConfigInput
})).min(1).max(20);
const adminRoleInput = z.enum(['OWNER', 'EDITOR', 'ANALYST', 'SUPPORT']);
const adminStatusInput = z.enum(['ACTIVE', 'DISABLED']);
const adminCreateInput = z.object({
  email: z.string().trim().email().max(320),
  password: z.string().min(12).max(256),
  role: adminRoleInput.default('EDITOR'),
  status: adminStatusInput.default('ACTIVE')
});
const adminPatchInput = z.object({
  email: z.string().trim().email().max(320).optional(),
  password: z.string().min(12).max(256).optional(),
  role: adminRoleInput.optional(),
  status: adminStatusInput.optional()
}).refine((value) => Object.keys(value).length > 0, 'At least one field is required.');
const passwordChangeInput = z.object({
  currentPassword: z.string().min(1).max(256),
  newPassword: z.string().min(12).max(256)
});
const dateKeySchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const analyticsQuery = z.object({
  from: dateKeySchema.optional(),
  to: dateKeySchema.optional(),
  timezone: z.string().trim().min(1).max(64).default('Asia/Shanghai'),
  days: z.coerce.number().int().min(1).max(90).optional()
}).refine((value) => Boolean(value.from) === Boolean(value.to), { message: '开始日期和结束日期必须同时填写。' });
const appEntryAdPolicyInput = z.object({
  releaseId: z.string().trim().min(1).max(64).regex(/^[A-Za-z0-9._-]+$/).default('default'),
  enabled: z.boolean(),
  mode: z.enum(['INTERSTITIAL', 'REWARDED_GATED']),
  placementId: z.string().trim().max(128),
  requiredCount: z.number().int().min(1),
  countMode: z.enum(['COMPLETED', 'SHOWN']).default('COMPLETED'),
  onUnavailable: z.enum(['ALLOW', 'BLOCK'])
}).refine((value) => !value.enabled || value.placementId.length > 0, { path: ['placementId'], message: '启用进入广告时必须填写广告位 ID。' });
const codeReleaseParams = z.object({ releaseId: z.string().trim().min(1).max(64).regex(/^[A-Za-z0-9._-]+$/) });
const codeReleaseInput = z.object({
  portalVersion: z.string().trim().max(32).nullable(),
  portalStatus: z.enum(['UNKNOWN', 'PREVIEW', 'IN_REVIEW', 'READY', 'RELEASED'])
});

const componentLabels: Record<z.infer<typeof componentParams>['key'], string> = {
  APP_TOPBAR: '顶部导航',
  APP_BOTTOM_NAV: '底部导航',
  HOME_INTRO: '首页介绍区',
  HOME_FEED: '首页内容流',
  ALBUM_DESCRIPTION: '剧集简介',
  PROFILE_HISTORY: '观看历史',
  PROFILE_FAVORITES: '收藏列表'
};

function dateKey(value: Date, timezone: string) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(value);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function addDateKeyDays(value: string, days: number) {
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));
  return date.toISOString().slice(0, 10);
}

function zonedMidnight(value: string, timezone: string) {
  const [year, month, day] = value.split('-').map(Number);
  const target = Date.UTC(year, month - 1, day);
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
  });
  let candidate = target;
  for (let iteration = 0; iteration < 2; iteration += 1) {
    const parts = Object.fromEntries(formatter.formatToParts(new Date(candidate)).map((part) => [part.type, part.value]));
    const represented = Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), Number(parts.hour), Number(parts.minute), Number(parts.second));
    candidate += target - represented;
  }
  return new Date(candidate);
}

function resolveAnalyticsRange(input: z.infer<typeof analyticsQuery>) {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: input.timezone }).format();
  } catch {
    throw Object.assign(new Error('统计时区不正确。'), { statusCode: 400 });
  }
  const to = input.to ?? dateKey(new Date(), input.timezone);
  const from = input.from ?? addDateKeyDays(to, -(input.days ?? 30) + 1);
  if (from > to) throw Object.assign(new Error('统计开始日期不能晚于结束日期。'), { statusCode: 400 });
  const periodDays = Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000) + 1;
  if (periodDays > 366) throw Object.assign(new Error('统计日期范围不能超过 366 天。'), { statusCode: 400 });
  return {
    from,
    to,
    timezone: input.timezone,
    periodDays,
    start: zonedMidnight(from, input.timezone),
    end: zonedMidnight(addDateKeyDays(to, 1), input.timezone)
  };
}

function completeDailySeries(from: string, periodDays: number, values: Array<{ date: string; count: number }>) {
  const counts = new Map(values.map((value) => [value.date, Number(value.count)]));
  return Array.from({ length: periodDays }, (_, index) => {
    const date = addDateKeyDays(from, index);
    return { date, count: counts.get(date) ?? 0 };
  });
}

async function readDailySummary(app: FastifyInstance, range: ReturnType<typeof resolveAnalyticsRange>) {
  const model = app.prisma.analyticsDailySummary;
  if (!model?.findMany) return null;
  try {
    const rows = await model.findMany({
      where: {
        timezone: range.timezone,
        day: { gte: new Date(`${range.from}T00:00:00.000Z`), lt: new Date(`${addDateKeyDays(range.to, 1)}T00:00:00.000Z`) }
      }, orderBy: { day: 'asc' }
    });
    if (rows.length < range.periodDays) return null;
    const totals = rows.reduce((result, row: AnalyticsDailySummary) => {
      for (const key of ['newUsers', 'watchSessions', 'completedEpisodes', 'favorites', 'shares', 'searches', 'playbackEvents', 'playbackErrors', 'adRequested', 'adShown', 'adFailed'] as const) result[key] += Number(row[key] ?? 0);
      return result;
    }, { newUsers: 0, watchSessions: 0, completedEpisodes: 0, favorites: 0, shares: 0, searches: 0, playbackEvents: 0, playbackErrors: 0, adRequested: 0, adShown: 0, adFailed: 0 });
    const updatedAt = rows.reduce((latest, row) => Math.max(latest, new Date(row.sourceWindowEnd).getTime()), 0);
    return {
      totals,
      playback: combinePlaybackSummaries(rows.map((row) => row.playbackSummary)),
      updatedAt: updatedAt ? new Date(updatedAt).toISOString() : null,
      dailyNewUsers: rows.map((row) => ({ date: new Date(row.day).toISOString().slice(0, 10), count: Number(row.newUsers ?? 0) })),
      dailyActiveUsers: rows.map((row) => ({ date: new Date(row.day).toISOString().slice(0, 10), count: Number(row.activeUsers ?? 0) }))
    };
  } catch {
    return null;
  }
}

function extensionMime(extension: string) {
  if (['.jpg', '.jpeg'].includes(extension)) return 'image/jpeg';
  if (extension === '.png') return 'image/png';
  if (extension === '.webp') return 'image/webp';
  return null;
}

function detectImage(buffer: Buffer): { mimeType: string; width?: number; height?: number } | null {
  if (buffer.length >= 24 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return { mimeType: 'image/png', width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
  }
  if (buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') {
    return { mimeType: 'image/webp' };
  }
  if (buffer.length >= 4 && buffer[0] === 0xff && buffer[1] === 0xd8) {
    let offset = 2;
    while (offset + 9 < buffer.length) {
      if (buffer[offset] !== 0xff) return null;
      const marker = buffer[offset + 1];
      const length = buffer.readUInt16BE(offset + 2);
      if (length < 2) return null;
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) {
        return { mimeType: 'image/jpeg', height: buffer.readUInt16BE(offset + 5), width: buffer.readUInt16BE(offset + 7) };
      }
      offset += 2 + length;
    }
    return { mimeType: 'image/jpeg' };
  }
  return null;
}

async function validateReadyCover(app: FastifyInstance, coverAssetId?: string | null) {
  if (!coverAssetId) return null;
  const asset = await app.prisma.coverAsset.findUnique({ where: { id: coverAssetId } });
  if (!asset || asset.status !== 'READY') throw Object.assign(new Error('封面资源尚未准备就绪。'), { statusCode: 400 });
  return asset;
}

function ensureTikTokPlatformConfigured(app: FastifyInstance) {
  if (app.config.TIKTOK_CLIENT_KEY && app.config.TIKTOK_CLIENT_SECRET) return;
  throw Object.assign(new Error('TikTok Short Drama OpenAPI 尚未配置。请设置 TIKTOK_CLIENT_KEY 和 TIKTOK_CLIENT_SECRET。'), { statusCode: 503 });
}

function albumDataWithAccess<T extends { accessConfig?: unknown; tagList?: unknown }>(app: FastifyInstance, input: T) {
  return {
    ...input,
    accessConfig: input.accessConfig === undefined
      ? undefined
      : readMiniAppAccessConfig(input.accessConfig, app.config) as unknown as Prisma.InputJsonValue,
    tagList: input.tagList === undefined ? undefined : input.tagList === null ? Prisma.JsonNull : input.tagList as Prisma.InputJsonValue
  };
}

async function audit(app: FastifyInstance, adminUserId: string, action: string, resource: string, resourceId?: string, metadata?: unknown) {
  await app.prisma.auditLog.create({ data: { adminUserId, action, resource, resourceId, metadata: metadata as never } });
}

type UiComponentSnapshot = z.infer<typeof uiComponentSnapshotInput>;

function mergeUiComponents(items: UiComponentSnapshot): UiComponentSnapshot {
  const byKey = new Map(items.map((item) => [item.key, item]));
  return defaultUiComponents.map((component) => {
    const stored = byKey.get(component.key);
    return {
      key: component.key,
      page: stored?.page ?? component.page,
      enabled: stored?.enabled ?? component.enabled,
      config: stored?.config ?? null
    };
  });
}

function normalizeUiComponentSnapshot(content: unknown) {
  const parsed = uiComponentSnapshotInput.safeParse(content);
  if (parsed.success) return { items: mergeUiComponents(parsed.data), repaired: false };

  const legacyItems = Array.isArray(content) ? content : [];
  const repairedItems: UiComponentSnapshot = [];
  for (const value of legacyItems) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
    const candidate = value as Record<string, unknown>;
    const key = componentParams.shape.key.safeParse(candidate.key);
    if (!key.success) continue;
    const fallback = defaultUiComponents.find((component) => component.key === key.data)!;
    const page = uiComponentPageInput.safeParse(candidate.page);
    const config = uiComponentConfigInput.safeParse(candidate.config);
    repairedItems.push({
      key: key.data,
      page: page.success ? page.data : fallback.page,
      enabled: typeof candidate.enabled === 'boolean' ? candidate.enabled : fallback.enabled,
      config: config.success ? config.data ?? null : null
    });
  }
  return { items: mergeUiComponents(repairedItems), repaired: true };
}

async function uiSnapshotFromRows(app: FastifyInstance): Promise<UiComponentSnapshot> {
  const stored = await app.prisma.uiComponent.findMany({ orderBy: [{ page: 'asc' }, { key: 'asc' }] });
  return normalizeUiComponentSnapshot(stored.map((component) => ({
    key: component.key as UiComponentSnapshot[number]['key'],
    page: component.page as UiComponentSnapshot[number]['page'],
    enabled: component.enabled,
    config: component.config as Record<string, unknown> | null
  }))).items;
}

async function currentUiDraft(app: FastifyInstance) {
  const draft = await app.prisma.uiConfigVersion.findFirst({ where: { status: 'DRAFT' }, orderBy: { version: 'desc' } });
  if (draft) {
    const snapshot = normalizeUiComponentSnapshot(draft.content);
    return { version: draft.version, ...snapshot };
  }
  return { version: null, items: await uiSnapshotFromRows(app), repaired: false };
}

async function verifiedImportedMedia(app: FastifyInstance, vids: string[]) {
  if (!vids.length) return new Map<string, Awaited<ReturnType<BytePlusVodService['getMediaInfos']>>[number]>();
  if (new Set(vids).size !== vids.length) throw Object.assign(new Error('同一剧目不能重复绑定相同的 BytePlus VID。'), { statusCode: 400 });
  const service = new BytePlusVodService(app.config);
  const media = [];
  for (let index = 0; index < vids.length; index += 20) {
    media.push(...await service.getMediaInfos({ vids: vids.slice(index, index + 20) }));
  }
  const byVid = new Map(media.map((item) => [item.vid, item]));
  for (const vid of vids) {
    const item = byVid.get(vid);
    if (!item) throw Object.assign(new Error(`BytePlus VID ${vid} 不存在。`), { statusCode: 404 });
    if (item.spaceName !== app.config.BYTEPLUS_SPACE_NAME) throw Object.assign(new Error(`BytePlus VID ${vid} 不属于当前空间。`), { statusCode: 409 });
    await assertMediaScope(app.sharedPrisma, app.config, item);
  }
  return byVid;
}

async function syncUiComponentRows(tx: Prisma.TransactionClient, items: UiComponentSnapshot) {
  await Promise.all(items.map((item) => tx.uiComponent.upsert({
    where: { key: item.key },
    create: { key: item.key, page: item.page, enabled: item.enabled, config: item.config === null ? Prisma.JsonNull : item.config as Prisma.InputJsonValue | undefined },
    update: { page: item.page, enabled: item.enabled, config: item.config === null ? Prisma.JsonNull : item.config as Prisma.InputJsonValue | undefined }
  })));
}

export async function registerAdminRoutes(app: FastifyInstance) {
  app.post('/admin/auth/login', {
    config: { rateLimit: { max: 10, timeWindow: '15 minutes' } }
  }, async (request, reply) => {
    const input = z.object({
      email: z.string().trim().email().max(320),
      password: z.string().min(1).max(256)
    }).parse(request.body);
    const admin = await app.prisma.adminUser.findUnique({ where: { email: input.email.toLowerCase() } });
    if (!admin || admin.status !== 'ACTIVE' || !(await verifyPassword(input.password, admin.passwordHash))) {
      return reply.code(401).send({
        error: { code: 'UNAUTHORIZED', message: 'Invalid administrator credentials.', requestId: request.id }
      });
    }
    await app.prisma.adminUser.update({ where: { id: admin.id }, data: { lastLoginAt: new Date() } });
    const accessToken = await app.jwt.sign(
      { sub: admin.id, kind: 'admin', appKey: app.config.MINI_APP_KEY, role: admin.role, tokenVersion: admin.tokenVersion },
      { expiresIn: app.config.ADMIN_JWT_EXPIRES_IN }
    );
    return { accessToken, expiresIn: app.config.ADMIN_JWT_EXPIRES_IN, admin: { id: admin.id, email: admin.email, role: admin.role } };
  });

  app.get('/admin/me', { preHandler: requireAdmin }, async (request) => {
    const admin = await app.prisma.adminUser.findUniqueOrThrow({
      where: { id: request.user.sub },
      select: { id: true, email: true, role: true, status: true, lastLoginAt: true, passwordChangedAt: true, createdAt: true }
    });
    return { admin };
  });

  app.put('/admin/me/password', { preHandler: requireAdmin }, async (request) => {
    const input = passwordChangeInput.parse(request.body);
    const admin = await app.prisma.adminUser.findUniqueOrThrow({ where: { id: request.user.sub } });
    if (!(await verifyPassword(input.currentPassword, admin.passwordHash))) {
      throw Object.assign(new Error('当前密码不正确。'), { statusCode: 400 });
    }
    const updated = await app.prisma.adminUser.update({
      where: { id: admin.id },
      data: { passwordHash: await hashPassword(input.newPassword), passwordChangedAt: new Date(), tokenVersion: { increment: 1 } },
      select: { id: true, email: true, role: true }
    });
    await audit(app, request.user.sub, 'CHANGE_PASSWORD', 'AdminUser', updated.id);
    return { admin: updated };
  });

  app.get('/admin/admin-users', { preHandler: requireAdmin }, async () => {
    const items = await app.prisma.adminUser.findMany({
      orderBy: { createdAt: 'asc' },
      select: { id: true, email: true, role: true, status: true, lastLoginAt: true, passwordChangedAt: true, createdAt: true, updatedAt: true }
    });
    return { items };
  });

  app.post('/admin/admin-users', { preHandler: requireAdmin }, async (request) => {
    const input = adminCreateInput.parse(request.body);
    const admin = await app.prisma.adminUser.create({
      data: { email: input.email.toLowerCase(), passwordHash: await hashPassword(input.password), role: input.role, status: input.status, passwordChangedAt: new Date() },
      select: { id: true, email: true, role: true, status: true, createdAt: true }
    });
    await audit(app, request.user.sub, 'CREATE', 'AdminUser', admin.id, { email: admin.email, role: admin.role, status: admin.status });
    return { admin };
  });

  app.patch('/admin/admin-users/:adminUserId', { preHandler: requireAdmin }, async (request) => {
    const { adminUserId } = z.object({ adminUserId: z.string().min(1).max(128) }).parse(request.params);
    const input = adminPatchInput.parse(request.body);
    if (adminUserId === request.user.sub && input.status === 'DISABLED') {
      throw Object.assign(new Error('不能禁用当前管理员账号。'), { statusCode: 400 });
    }
    const data: Prisma.AdminUserUpdateInput = {
      email: input.email?.toLowerCase(),
      role: input.role,
      status: input.status,
      passwordHash: input.password ? await hashPassword(input.password) : undefined,
      passwordChangedAt: input.password ? new Date() : undefined,
      tokenVersion: input.password || input.role || input.status ? { increment: 1 } : undefined
    };
    const admin = await app.prisma.adminUser.update({
      where: { id: adminUserId },
      data,
      select: { id: true, email: true, role: true, status: true, lastLoginAt: true, passwordChangedAt: true, createdAt: true, updatedAt: true }
    });
    await audit(app, request.user.sub, 'UPDATE', 'AdminUser', admin.id, { email: input.email, role: input.role, status: input.status, passwordChanged: Boolean(input.password) });
    return { admin };
  });

  app.get('/admin/audit-logs', { preHandler: requireAdmin }, async (request) => {
    const query = z.object({ cursor: z.string().min(1).optional(), limit: z.coerce.number().int().min(1).max(100).default(50) }).parse(request.query);
    const items = await app.prisma.auditLog.findMany({
      take: query.limit + 1,
      ...(query.cursor ? { cursor: { id: query.cursor }, skip: 1 } : {}),
      orderBy: { createdAt: 'desc' },
      include: { adminUser: { select: { id: true, email: true, role: true } } }
    });
    const hasMore = items.length > query.limit;
    const visible = hasMore ? items.slice(0, query.limit) : items;
    return { items: visible, nextCursor: hasMore ? visible.at(-1)?.id ?? null : null };
  });

  app.get('/admin/app-entry-ad-policy', { preHandler: requireAdmin }, async (request) => {
    const { releaseId } = z.object({ releaseId: z.string().trim().min(1).max(64).regex(/^[A-Za-z0-9._-]+$/).default('default') }).parse(request.query);
    return readAppEntryAdPolicy(app, releaseId);
  });
  app.get('/admin/app-entry-ad-policies', { preHandler: requireAdmin }, async () => {
    const policies = await app.prisma.appEntryAdPolicy.findMany({
      orderBy: { updatedAt: 'desc' },
      select: { releaseId: true, enabled: true, mode: true, placementId: true, requiredCount: true, countMode: true, onUnavailable: true, version: true, updatedAt: true, firstSeenAt: true }
    });
    const releases = await app.sharedPrisma.miniAppCodeRelease.findMany({
      where: { miniAppKey: app.config.MINI_APP_KEY },
      select: { releaseId: true, portalVersion: true, portalStatus: true }
    });
    const releaseById = new Map(releases.map((item) => [item.releaseId, item]));
    const placements = miniAppAdConfig(app.config);
    const items = policies.some((item) => item.releaseId === 'default') ? policies : [...policies, {
      releaseId: 'default', enabled: false, mode: placements.appEntryPlacementId ? 'INTERSTITIAL' as const : 'REWARDED_GATED' as const,
      placementId: placements.appEntryPlacementId || placements.rewardedPlacementId, requiredCount: 1,
      countMode: 'COMPLETED' as const, onUnavailable: 'ALLOW' as const, version: 1, updatedAt: new Date(0), firstSeenAt: null
    }];
    return {
      items: items.map((item) => ({ ...item, portalVersion: releaseById.get(item.releaseId)?.portalVersion ?? null, portalStatus: releaseById.get(item.releaseId)?.portalStatus ?? 'UNKNOWN' })),
      placementDefaults: { INTERSTITIAL: placements.appEntryPlacementId, REWARDED_GATED: placements.rewardedPlacementId }
    };
  });
  app.patch('/admin/app-entry-ad-releases/:releaseId', { preHandler: requireAdmin }, async (request) => {
    const { releaseId } = codeReleaseParams.parse(request.params);
    const input = codeReleaseInput.parse(request.body);
    if (releaseId !== 'default' && !await app.prisma.appEntryAdPolicy.findUnique({ where: { releaseId }, select: { id: true } })) {
      throw Object.assign(new Error('该代码版本尚未登记。'), { statusCode: 404 });
    }
    const release = await app.sharedPrisma.miniAppCodeRelease.upsert({
      where: { miniAppKey_releaseId: { miniAppKey: app.config.MINI_APP_KEY, releaseId } },
      create: { miniAppKey: app.config.MINI_APP_KEY, releaseId, ...input, updatedBy: request.user.sub },
      update: { ...input, updatedBy: request.user.sub }
    });
    await audit(app, request.user.sub, 'UPDATE', 'MiniAppCodeRelease', `${app.config.MINI_APP_KEY}:${releaseId}`, input);
    return release;
  });
  app.put('/admin/app-entry-ad-policy', { preHandler: requireAdmin }, async (request) => {
    const input = appEntryAdPolicyInput.parse(request.body);
    const current = await readAppEntryAdPolicy(app, input.releaseId);
    const policy = await app.prisma.appEntryAdPolicy.upsert({
      where: { releaseId: input.releaseId },
      create: { id: input.releaseId === 'default' ? 'default' : `release:${input.releaseId}`, ...input, version: 1, updatedBy: request.user.sub },
      update: { ...input, version: current.version + 1, updatedBy: request.user.sub }
    });
    await audit(app, request.user.sub, 'UPDATE', 'AppEntryAdPolicy', policy.id, input);
    return policy;
  });

  app.get('/admin/albums', { preHandler: requireAdmin }, async () => {
    const albums = await app.prisma.album.findMany({
      orderBy: { updatedAt: 'desc' },
      select: {
        id: true, title: true, status: true, coverUrl: true, coverAssetId: true,
        tiktokAlbumId: true, tiktokVersion: true, onlineVersion: true,
        platformPublishedVersion: true, reviewStatus: true, publishStatus: true,
        accessConfig: true, updatedAt: true, _count: { select: { episodes: true } }
      }
    });
    const shared = await app.sharedPrisma.miniAppAlbumAuthorization.findMany({ where: { miniAppKey: app.config.MINI_APP_KEY, targetLocalAlbumId: { not: null }, album: { ownerMiniAppKey: { not: app.config.MINI_APP_KEY } } }, select: { targetLocalAlbumId: true } });
    const sharedIds = new Set(shared.map((item) => item.targetLocalAlbumId));
    return { items: albums.map((album) => ({ ...album, sharedPlayback: sharedIds.has(album.id), episodeCount: album._count.episodes, _count: undefined })) };
  });

  app.get('/admin/episodes', { preHandler: requireAdmin }, async () => {
    const episodes = await app.prisma.episode.findMany({
      orderBy: [{ album: { title: 'asc' } }, { sortOrder: 'asc' }],
      select: { id: true, albumId: true, episodeNo: true, title: true, sortOrder: true, status: true, byteplusVid: true, byteplusCoverUrl: true, coverUrl: true, durationMs: true, tiktokEpisodeId: true, album: { select: { title: true, status: true, tiktokAlbumId: true } } }
    });
    return { items: episodes };
  });

  app.get('/admin/albums/:albumId', { preHandler: requireAdmin }, async (request, reply) => {
    const { albumId } = albumParams.parse(request.params);
    const album = await app.prisma.album.findUnique({
      where: { id: albumId },
      include: { episodes: { orderBy: { sortOrder: 'asc' }, include: { translations: true } }, translations: true, genres: { include: { genre: true } } }
    });
    if (!album) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: '剧集不存在。', requestId: request.id } });
    return album;
  });

  app.post('/admin/cover-assets', { preHandler: requireAdmin }, async (request, reply) => {
    const upload = await request.file();
    if (!upload) return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: '请选择一张封面图片上传。', requestId: request.id } });
    const fileName = upload.filename.trim();
    const extension = fileName.includes('.') ? fileName.slice(fileName.lastIndexOf('.')).toLowerCase() : '';
    const expectedMime = extensionMime(extension);
    if (!expectedMime) return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: '支持 JPEG、PNG 和 WebP 封面格式。', requestId: request.id } });

    const tempDirectory = join(tmpdir(), 'quickreels-covers');
    const tempPath = join(tempDirectory, `${Date.now()}-${Math.random().toString(36).slice(2)}${extension}`);
    await mkdir(tempDirectory, { recursive: true });
    try {
      await pipeline(upload.file, createWriteStream(tempPath));
      if (upload.file.truncated) throw Object.assign(new Error('所选图片超过 10 MB 大小限制。'), { statusCode: 413 });
      const buffer = await readFile(tempPath);
      if (!buffer.length || buffer.length > 10 * 1024 * 1024) {
        return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: '封面图片大小必须在 1 字节至 10 MB 之间。', requestId: request.id } });
      }
      const image = detectImage(buffer);
      if (!image || image.mimeType !== expectedMime || (upload.mimetype && upload.mimetype !== expectedMime)) {
        return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: '封面文件扩展名与图片类型不匹配。', requestId: request.id } });
      }
      if (image.width && image.height) {
        const pixels = image.width * image.height;
        const ratio = image.width / image.height;
        if (pixels > 24_000_000 || ratio < 0.4 || ratio > 2.5) {
          return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: '封面尺寸超出允许范围。', requestId: request.id } });
        }
      }
      const sha256 = createHash('sha256').update(buffer).digest('hex');
      const existing = await app.prisma.coverAsset.findUnique({ where: { sha256 } });
      if (existing?.status === 'READY') {
        const syncJob = app.config.TIKTOK_CLIENT_KEY && app.config.TIKTOK_CLIENT_SECRET
          ? await enqueueCoverSync(app.prisma as any, existing.id, request.user.sub)
          : null;
        return { ...existing, platformSyncJob: syncJob };
      }

      const storage = await new LocalObjectStorageService(app.config).putObject({
        key: `${sha256}${extension === '.jpeg' ? '.jpg' : extension}`,
        filePath: tempPath,
        contentType: expectedMime
      });
      const asset = await app.prisma.coverAsset.upsert({
        where: { sha256 },
        create: {
          storageKey: storage.storageKey,
          publicUrl: storage.publicUrl,
          mimeType: expectedMime,
          fileSize: buffer.length,
          width: image.width,
          height: image.height,
          sha256,
          status: 'READY'
        },
        update: {
          storageKey: storage.storageKey,
          publicUrl: storage.publicUrl,
          mimeType: expectedMime,
          fileSize: buffer.length,
          width: image.width,
          height: image.height,
          status: 'READY'
        }
      });
      await audit(app, request.user.sub, 'UPLOAD', 'CoverAsset', asset.id, { fileName, fileSize: buffer.length });
      const syncJob = app.config.TIKTOK_CLIENT_KEY && app.config.TIKTOK_CLIENT_SECRET
        ? await enqueueCoverSync(app.prisma as any, asset.id, request.user.sub)
        : null;
      return { ...asset, platformSyncJob: syncJob };
    } finally {
      await unlink(tempPath).catch(() => undefined);
    }
  });

  app.post('/admin/dramas', { preHandler: requirePermission('content.write') }, async (request) => {
    const input = dramaInput.parse(request.body);
    if (new Set(input.episodes.map((episode) => episode.episodeNo)).size !== input.episodes.length) {
      throw Object.assign(new Error('分集集号不能重复。'), { statusCode: 400 });
    }
    const importedMedia = await verifiedImportedMedia(app, input.episodes.flatMap((episode) => episode.byteplusVid ? [episode.byteplusVid] : []));
    const albumCover = await validateReadyCover(app, input.coverAssetId);
    const episodeCoverIds = Array.from(new Set(input.episodes.flatMap((episode) => episode.coverAssetId ? [episode.coverAssetId] : [])));
    const episodeCovers = episodeCoverIds.length ? await app.prisma.coverAsset.findMany({ where: { id: { in: episodeCoverIds }, status: 'READY' } }) : [];
    if (episodeCovers.length !== episodeCoverIds.length) throw Object.assign(new Error('一个或多个分集封面资源尚未准备就绪。'), { statusCode: 400 });
    const coverById = new Map(episodeCovers.map((cover) => [cover.id, cover]));

    const result = await app.prisma.$transaction(async (tx) => {
      const album = await tx.album.create({
        data: {
          title: input.title,
          description: input.description,
          coverAssetId: albumCover!.id,
          coverUrl: albumCover!.publicUrl,
          language: input.language,
          releaseYear: input.releaseYear,
          dramaType: input.dramaType,
          tagList: input.tagList as Prisma.InputJsonValue,
          regions: input.regions,
          accessConfig: input.accessConfig === undefined
            ? undefined
            : readMiniAppAccessConfig(input.accessConfig, app.config) as unknown as Prisma.InputJsonValue,
          status: 'DRAFT'
        }
      });
      const episodes = await Promise.all(input.episodes.map((episode) => {
        const cover = episode.coverAssetId ? coverById.get(episode.coverAssetId) : null;
        const media = episode.byteplusVid ? importedMedia.get(episode.byteplusVid) : null;
        return tx.episode.create({
          data: {
            albumId: album.id,
            episodeNo: episode.episodeNo,
            title: episode.title,
            description: episode.description,
            sortOrder: episode.sortOrder ?? episode.episodeNo,
            isFree: episode.isFree,
            coverAssetId: cover?.id,
            coverUrl: cover?.publicUrl ?? media?.coverUrl,
            byteplusVid: media?.vid,
            byteplusCoverUrl: media?.coverUrl,
            durationMs: media?.durationMs,
            byteplusUploadStatus: media ? 'READY' : 'PENDING',
            status: media ? 'READY' : 'DRAFT'
          }
        });
      }));
      await tx.auditLog.create({ data: { adminUserId: request.user.sub, action: 'CREATE', resource: 'Drama', resourceId: album.id, metadata: { episodeCount: episodes.length } as never } });
      return { album, episodes };
    });
    return result;
  });

  app.post('/admin/albums/:albumId/episodes/batch', { preHandler: requirePermission('content.write') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    const { episodes: inputEpisodes } = appendEpisodesInput.parse(request.body);
    const numbers = inputEpisodes.map((episode) => episode.episodeNo);
    if (new Set(numbers).size !== numbers.length) throw Object.assign(new Error('新增分集集号不能重复。'), { statusCode: 400 });
    const importedMedia = await verifiedImportedMedia(app, inputEpisodes.flatMap((episode) => episode.byteplusVid ? [episode.byteplusVid] : []));
    const coverIds = [...new Set(inputEpisodes.flatMap((episode) => episode.coverAssetId ? [episode.coverAssetId] : []))];
    const covers = coverIds.length ? await app.prisma.coverAsset.findMany({ where: { id: { in: coverIds }, status: 'READY' } }) : [];
    if (covers.length !== coverIds.length) throw Object.assign(new Error('一个或多个分集封面尚未准备就绪。'), { statusCode: 400 });
    const coverById = new Map(covers.map((cover) => [cover.id, cover]));
    try {
      const result = await app.prisma.$transaction(async (tx) => {
        const album = await tx.album.findUnique({ where: { id: albumId }, select: { id: true, title: true, status: true, tiktokAlbumId: true, reviewStatus: true, accessConfig: true, _count: { select: { episodes: true } } } });
        if (!album) throw Object.assign(new Error('目标剧集不存在。'), { statusCode: 404 });
        if (album.status === 'OFFLINE') throw Object.assign(new Error('下线剧集不能追加分集。'), { statusCode: 409 });
        if (album.reviewStatus === 'REVIEWING' || album.reviewStatus === '1') throw Object.assign(new Error('剧集正在审核中，审核结束后才能追加分集。'), { statusCode: 409 });
        if (album._count.episodes + inputEpisodes.length > 500) throw Object.assign(new Error('单部剧集最多 500 集。'), { statusCode: 400 });
        const existing = await tx.episode.findMany({ where: { albumId, episodeNo: { in: numbers } }, select: { episodeNo: true } });
        if (existing.length) throw Object.assign(new Error(`集号已存在：${existing.map((episode) => episode.episodeNo).join('、')}。`), { statusCode: 409 });
        const episodes = [];
        for (const input of inputEpisodes) {
          const cover = input.coverAssetId ? coverById.get(input.coverAssetId) : null;
          const media = input.byteplusVid ? importedMedia.get(input.byteplusVid) : null;
          episodes.push(await tx.episode.create({ data: {
            albumId,
            episodeNo: input.episodeNo,
            title: input.title,
            description: input.description,
            sortOrder: input.sortOrder ?? input.episodeNo,
            isFree: input.isFree,
            coverAssetId: cover?.id,
            coverUrl: cover?.publicUrl ?? media?.coverUrl,
            byteplusVid: media?.vid,
            byteplusCoverUrl: media?.coverUrl,
            durationMs: media?.durationMs,
            byteplusUploadStatus: media ? 'READY' : 'PENDING',
            status: media ? 'READY' : 'DRAFT'
          } }));
        }
        await tx.auditLog.create({ data: { adminUserId: request.user.sub, action: 'APPEND', resource: 'Album', resourceId: albumId, metadata: { episodeNos: numbers } as never } });
        return { album: { id: album.id, title: album.title, accessConfig: album.accessConfig }, episodes };
      });
      return result;
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw Object.assign(new Error('集号已被其他操作占用，请刷新分集列表后重试。'), { statusCode: 409 });
      }
      throw error;
    }
  });

  app.post('/admin/albums', { preHandler: requireAdmin }, async (request) => {
    const input = albumInput.parse(request.body);
    const cover = await validateReadyCover(app, input.coverAssetId);
    if (!cover && !input.coverUrl) throw Object.assign(new Error('必须提供封面地址或封面资源 ID。'), { statusCode: 400 });
    const album = await app.prisma.album.create({ data: { ...albumDataWithAccess(app, input), coverUrl: cover?.publicUrl ?? input.coverUrl!, coverAssetId: cover?.id ?? input.coverAssetId, regions: input.regions } });
    await audit(app, request.user.sub, 'CREATE', 'Album', album.id);
    return album;
  });

  app.get('/admin/albums/:albumId/display-metadata', { preHandler: requireAdmin }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    const { sharedAlbum, ...view } = await readDisplayMetadata(app.sharedPrisma as any, app.miniAppPrisma as any, app.config.MINI_APP_KEY, albumId);
    let canEdit = true;
    if (sharedAlbum) {
      try { await checkDisplayMetadataOwner(app, request, sharedAlbum); } catch (error) {
        if ((error as { statusCode?: number }).statusCode !== 403) throw error;
        canEdit = false;
      }
    } else canEdit = ['OWNER', 'EDITOR'].includes(request.user.role ?? '');
    return { ...view, canEdit };
  });

  app.patch('/admin/albums/:albumId/display-metadata', { preHandler: requirePermission('content.write') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    const input = displayMetadataInput.extend({ expectedVersion: z.number().int().nonnegative() }).parse(request.body);
    const previous = await readDisplayMetadata(app.sharedPrisma as any, app.miniAppPrisma as any, app.config.MINI_APP_KEY, albumId);
    const metadata = carryBaseTextChanges(displayMetadataInput.parse(input), previous);
    const shared = previous.sharedAlbum;
    if (shared) {
      const operator = await checkDisplayMetadataOwner(app, request, shared);
      await saveSharedDisplayMetadata(app.sharedPrisma as any, shared, metadata, input.expectedVersion, operator);
    } else await saveLocalDisplayMetadata(app.prisma as any, albumId, metadata);
    await audit(app, request.user.sub, 'UPDATE_DISPLAY_METADATA', 'Album', albumId, { ...input, sharedAlbumId: shared?.id });
    const { sharedAlbum, ...view } = await readDisplayMetadata(app.sharedPrisma as any, app.miniAppPrisma as any, app.config.MINI_APP_KEY, albumId);
    return { ...view, canEdit: true };
  });

  app.post('/admin/albums/:albumId/display-metadata/retry', { preHandler: requirePermission('content.write') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    const { miniAppKey } = z.object({ miniAppKey: z.enum(miniAppKeys) }).parse(request.body);
    const shared = await findDisplayMetadataAlbum(app.sharedPrisma as any, app.config.MINI_APP_KEY, albumId);
    if (!shared) throw Object.assign(new Error('剧目没有共享资料。'), { statusCode: 409 });
    await checkDisplayMetadataOwner(app, request, shared);
    await retryDisplayMetadata(app.sharedPrisma as any, shared, miniAppKey);
    await audit(app, request.user.sub, 'RETRY_DISPLAY_METADATA', 'Album', albumId, { miniAppKey, version: shared.displayMetadataVersion });
    return { accepted: true };
  });

  app.patch('/admin/albums/:albumId', { preHandler: requireAdmin }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    const input = albumPatch.parse(request.body);
    const cover = await validateReadyCover(app, input.coverAssetId);
    let metadataSync: { shared: boolean; version: number } | undefined;
    const shared = (input.title !== undefined || input.description !== undefined)
      ? await findDisplayMetadataAlbum(app.sharedPrisma as any, app.config.MINI_APP_KEY, albumId) : null;
    if (shared) {
      const current = await app.prisma.album.findUniqueOrThrow({ where: { id: albumId } });
      if ((input.title !== undefined && input.title !== current.title) || (input.description !== undefined && input.description !== current.description)) {
        const operator = await checkDisplayMetadataOwner(app, request, shared);
        const view = await readDisplayMetadata(app.sharedPrisma as any, app.miniAppPrisma as any, app.config.MINI_APP_KEY, albumId);
        const latest = await saveSharedDisplayMetadata(app.sharedPrisma as any, shared, carryBaseTextChanges(displayMetadataInput.parse({ ...view,
          title: input.title ?? view.title, description: input.description ?? view.description }), view), view.version, operator);
        metadataSync = { shared: true, version: latest.displayMetadataVersion };
      }
    }
    const album = await app.prisma.album.update({ where: { id: albumId }, data: { ...albumDataWithAccess(app, input),
      ...(shared ? { title: undefined, description: undefined } : input.title !== undefined || input.description !== undefined ? { displayMetadataVersion: { increment: 1 } } : {}), coverUrl: cover?.publicUrl ?? input.coverUrl, coverAssetId: input.coverAssetId === undefined ? undefined : cover?.id ?? null } });
    await audit(app, request.user.sub, 'UPDATE', 'Album', album.id, input);
    return { ...album, ...(metadataSync ? { title: input.title ?? album.title, description: input.description ?? album.description, metadataSync } : {}) };
  });

  app.delete('/admin/albums/:albumId', { preHandler: requirePermission('content.write') }, async (request, reply) => {
    const { albumId } = albumParams.parse(request.params);
    const authorization = await (app.sharedPrisma as any).miniAppAlbumAuthorization.findFirst({
      where: { miniAppKey: app.config.MINI_APP_KEY, targetLocalAlbumId: albumId },
      include: { album: { select: { ownerMiniAppKey: true } } }
    });
    const album = await app.prisma.album.findUnique({
      where: { id: albumId },
      select: { id: true, title: true, status: true, tiktokAlbumId: true }
    });
    if (!album && authorization?.errorCode === 'LOCAL_COPY_REMOVED') {
      await (app.sharedPrisma as any).miniAppAlbumAuthorization.update({ where: { id: authorization.id }, data: { targetLocalAlbumId: null } });
      return reply.code(204).send();
    }
    if (!album) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: '剧集不存在。', requestId: request.id } });
    const sharedCopy = authorization && authorization.album.ownerMiniAppKey !== app.config.MINI_APP_KEY;
    if (sharedCopy) {
      const ownerMiniAppKey = authorization.album.ownerMiniAppKey as MiniAppKey;
      const crossesOrganization = !sameMiniAppOrganization(ownerMiniAppKey, app.config.MINI_APP_KEY as MiniAppKey);
      if (album.status === 'ONLINE' && !crossesOrganization) return reply.code(409).send({ error: { code: 'CONFLICT', message: '请先关闭当前小程序的共享剧目，再删除本地副本。', requestId: request.id } });
      const [localTask, uploadTask, sharedTask] = await Promise.all([
        app.prisma.platformSyncJob.findFirst({ where: { albumId, status: { in: ['PENDING', 'PROCESSING'] } } }),
        app.prisma.uploadJob.findFirst({ where: { episode: { albumId }, status: { in: ['PENDING', 'PROCESSING'] } } }),
        (app.sharedPrisma as any).sharedPlatformOperation.findFirst({ where: { sharedAlbumId: authorization.sharedAlbumId, status: { in: ['PENDING', 'PROCESSING'] } } })
      ]);
      if (localTask || uploadTask || sharedTask) return reply.code(409).send({ error: { code: 'CONFLICT', message: '该共享副本仍有处理中任务，请完成后刷新再删除。', requestId: request.id } });
      if (crossesOrganization && album.status === 'ONLINE') {
        await app.prisma.album.update({ where: { id: album.id }, data: { status: 'OFFLINE', platformPublishedVersion: null, platformPublishedAt: null } });
        await app.prisma.episode.updateMany({ where: { albumId: album.id }, data: { status: 'OFFLINE' } });
      }
      await (app.sharedPrisma as any).miniAppAlbumAuthorization.update({ where: { id: authorization.id }, data: {
        status: 'FAILED', errorCode: 'LOCAL_COPY_REMOVED', errorMessage: '当前小程序的本地共享副本已删除；TikTok 平台授权仍保留。', providerResponse: Prisma.JsonNull
      } });
      await app.prisma.album.delete({ where: { id: album.id } });
      await (app.sharedPrisma as any).miniAppAlbumAuthorization.update({ where: { id: authorization.id }, data: { targetLocalAlbumId: null } });
      await audit(app, request.user.sub, 'DELETE_SHARED_PLAYBACK_COPY', 'Album', album.id, { title: album.title, sharedAlbumId: authorization.sharedAlbumId, ownerMiniAppKey: authorization.album.ownerMiniAppKey });
      return reply.code(204).send();
    }
    if (album.status !== 'DRAFT' || album.tiktokAlbumId) {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '仅未同步至 TikTok 的草稿剧集可以删除。请先下架并保留已同步内容的审计记录。', requestId: request.id } });
    }
    await app.prisma.album.delete({ where: { id: album.id } });
    await audit(app, request.user.sub, 'DELETE', 'Album', album.id, { title: album.title });
    return reply.code(204).send();
  });

  app.post('/admin/episodes', { preHandler: requireAdmin }, async (request) => {
    const input = episodeInput.parse(request.body);
    const cover = await validateReadyCover(app, input.coverAssetId);
    const episode = await app.prisma.episode.create({ data: { ...input, coverUrl: cover?.publicUrl ?? input.coverUrl, coverAssetId: cover?.id ?? input.coverAssetId, sortOrder: input.sortOrder ?? input.episodeNo } });
    await audit(app, request.user.sub, 'CREATE', 'Episode', episode.id);
    return episode;
  });

  app.patch('/admin/episodes/:episodeId', { preHandler: requireAdmin }, async (request) => {
    const { episodeId } = episodeParams.parse(request.params);
    const input = episodePatch.parse(request.body);
    const cover = await validateReadyCover(app, input.coverAssetId);
    const current = input.coverAssetId === null && input.coverUrl === undefined
      ? await app.prisma.episode.findUnique({ where: { id: episodeId }, select: { byteplusCoverUrl: true } })
      : null;
    const episode = await app.prisma.episode.update({ where: { id: episodeId }, data: { ...input, coverUrl: cover?.publicUrl ?? input.coverUrl ?? (input.coverAssetId === null ? current?.byteplusCoverUrl ?? null : undefined), coverAssetId: input.coverAssetId === undefined ? undefined : cover?.id ?? null } });
    await audit(app, request.user.sub, 'UPDATE', 'Episode', episode.id, input);
    return episode;
  });

  app.post('/admin/episodes/:episodeId/reset-byteplus', { preHandler: requirePermission('content.write') }, async (request) => {
    const { episodeId } = episodeParams.parse(request.params);
    z.object({ confirmation: z.literal('RESET_VIDEO_BINDING') }).parse(request.body);
    const episode = await app.prisma.episode.findUniqueOrThrow({ where: { id: episodeId }, include: { album: true, coverAsset: true } });
    await assertPlatformOwner(app, episode.albumId);
    const updated = await app.prisma.$transaction(async (tx) => {
      const active = await tx.platformSyncJob.findFirst({ where: { OR: [{ episodeId }, { albumId: episode.albumId }], status: { in: ['PENDING', 'PROCESSING', 'CONFLICT'] } } });
      const uploading = await tx.uploadJob.findFirst({
        where: { episodeId, status: { in: ['PENDING', 'PROCESSING'] } },
        select: { id: true }
      });
      if (active || uploading || episode.tiktokEpisodeId || episode.tiktokVideoStatus === 'PROCESSING' || episode.status === 'ONLINE' || ['REVIEWING', '1'].includes(episode.album.reviewStatus ?? '')) {
        throw Object.assign(new Error('该集已有平台分集、平台任务、审核或线上状态，不能解除绑定；请先完成平台对账。'), { statusCode: 409 });
      }
      const changed = await tx.episode.updateMany({ where: { id: episodeId, byteplusVid: episode.byteplusVid, byteplusUploadStatus: episode.byteplusUploadStatus, tiktokEpisodeId: null, status: { not: 'ONLINE' } }, data: {
        byteplusVid: null, byteplusCoverUrl: null, coverUrl: episode.coverAsset?.status === 'READY' ? episode.coverAsset.publicUrl : null,
        durationMs: null, status: 'DRAFT', byteplusUploadStatus: 'PENDING', tiktokVideoStatus: 'NOT_STARTED', tiktokVideoJobId: null, tiktokVideoError: null
      } });
      if (changed.count !== 1) throw Object.assign(new Error('分集状态已变化，请刷新后重试。'), { statusCode: 409 });
      await tx.auditLog.create({ data: { adminUserId: request.user.sub, action: 'RESET_BYTEPLUS_BINDING', resource: 'Episode', resourceId: episodeId,
        metadata: { previousByteplusVid: episode.byteplusVid, previousTikTokError: episode.tiktokVideoError } } });
      return tx.episode.findUniqueOrThrow({ where: { id: episodeId } });
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    return updated;
  });

  app.post('/admin/episodes/:episodeId/bind-byteplus', { preHandler: requirePermission('content.write') }, async (request, reply) => {
    const { episodeId } = episodeParams.parse(request.params);
    const ownerEpisode = await app.prisma.episode.findUnique({ where: { id: episodeId }, include: { album: true, coverAsset: true } });
    if (!ownerEpisode) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: '分集不存在。', requestId: request.id } });
    await assertPlatformOwner(app, ownerEpisode.albumId);
    const input = mediaBindingInput.parse(request.body);
    if (input.byteplusVid !== ownerEpisode.byteplusVid) {
      const active = await app.prisma.platformSyncJob.findFirst({ where: {
        status: { in: ['PENDING', 'PROCESSING'] },
        OR: [{ episodeId }, { albumId: ownerEpisode.albumId }]
      } });
      if (ownerEpisode.byteplusUploadStatus === 'UPLOADING' || ownerEpisode.tiktokVideoStatus === 'PROCESSING' || ['REVIEWING', '1'].includes(ownerEpisode.album.reviewStatus ?? '') || active) {
        throw Object.assign(new Error('当前剧目仍有上传、审核或待对账的平台任务，请处理完成后再替换视频。'), { statusCode: 409 });
      }
    }
    const cover = input.coverAssetId === undefined ? ownerEpisode.coverAsset : await validateReadyCover(app, input.coverAssetId);
    const media = (await verifiedImportedMedia(app, [input.byteplusVid])).get(input.byteplusVid)!;
    const sharedMedia = await getOrCreateSharedMediaAsset(app.sharedPrisma as any, {
      byteplusVid: media.vid,
      byteplusAccountId: app.config.BYTEPLUS_ACCOUNT_ID,
      byteplusSpaceName: app.config.BYTEPLUS_SPACE_NAME,
      byteplusRegion: app.config.BYTEPLUS_REGION,
      miniAppKey: app.config.MINI_APP_KEY,
      title: media.title,
      coverUrl: input.byteplusCoverUrl ?? media.coverUrl,
      durationMs: input.durationMs ?? media.durationMs
    });
    const providerCoverUrl = input.byteplusCoverUrl ?? media.coverUrl;
    const episode = await app.prisma.episode.update({
      where: { id: episodeId },
      data: {
        byteplusVid: media.vid,
        byteplusCoverUrl: providerCoverUrl,
        coverAssetId: input.coverAssetId === undefined ? undefined : cover?.id ?? null,
        coverUrl: cover?.status === 'READY' ? cover.publicUrl : providerCoverUrl,
        durationMs: input.durationMs ?? media.durationMs,
        status: 'READY',
        byteplusUploadStatus: 'READY',
        tiktokVideoStatus: 'NOT_STARTED',
        tiktokVideoJobId: null,
        tiktokVideoError: null
      }
    });
    await audit(app, request.user.sub, 'BIND_BYTEPLUS_MEDIA', 'Episode', episode.id, {
      byteplusVid: media.vid,
      previousByteplusVid: ownerEpisode.byteplusVid,
      coverAssetId: input.coverAssetId,
      sharedMediaAssetId: sharedMedia.id
    });
    const syncJob = app.config.TIKTOK_CLIENT_KEY && app.config.TIKTOK_CLIENT_SECRET
      ? await enqueueVideoSync(app.prisma as any, episode.id, request.user.sub)
      : null;
    return { ...episode, sharedMediaAsset: sharedMedia, platformSyncJob: syncJob };
  });

  app.post('/admin/episodes/:episodeId/bind-shared-media', { preHandler: requirePermission('content.write') }, async (request) => {
    const { episodeId } = episodeParams.parse(request.params);
    const ownerEpisode = await app.prisma.episode.findUnique({ where: { id: episodeId }, select: { albumId: true } });
    if (ownerEpisode) await assertPlatformOwner(app, ownerEpisode.albumId);
    const input = sharedMediaBindingInput.parse(request.body);
    const result = await bindEpisodeToSharedMedia(app.sharedPrisma as any, app.prisma as any, app.config, app.config.MINI_APP_KEY, episodeId, input.sharedMediaAssetId);
    await audit(app, request.user.sub, 'BIND_SHARED_MEDIA', 'Episode', episodeId, {
      sharedMediaAssetId: input.sharedMediaAssetId,
      byteplusVid: result.media.byteplusVid
    });
    const syncJob = app.config.TIKTOK_CLIENT_KEY && app.config.TIKTOK_CLIENT_SECRET
      ? await enqueueVideoSync(app.prisma as any, episodeId, request.user.sub)
      : null;
    return { ...result.episode, sharedMediaAsset: result.media, platformSyncJob: syncJob };
  });

  app.patch('/admin/episodes/:episodeId/access', { preHandler: requireAdmin }, async (request) => {
    const { episodeId } = episodeParams.parse(request.params);
    const input = z.object({ isFree: z.boolean() }).parse(request.body);
    const episode = await app.prisma.episode.update({ where: { id: episodeId }, data: { isFree: input.isFree } });
    await audit(app, request.user.sub, 'UPDATE_ACCESS', 'Episode', episode.id, input);
    return { id: episode.id, isFree: episode.isFree };
  });

  app.get('/admin/ui-components', { preHandler: requireAdmin }, async () => {
    const [draft, published] = await Promise.all([
      currentUiDraft(app),
      app.prisma.uiConfigVersion.findFirst({ where: { status: 'PUBLISHED' }, orderBy: { version: 'desc' } })
    ]);
    return {
      items: draft.items.map((component) => ({ ...component, label: componentLabels[component.key] })),
      draftVersion: draft.version,
      publishedVersion: published?.version ?? 0,
      publishedAt: published?.publishedAt ?? null
    };
  });
  app.patch('/admin/ui-components/:key', { preHandler: requireAdmin }, async (request) => {
    const { key } = componentParams.parse(request.params);
    const input = z.object({ page: uiComponentPageInput.optional(), enabled: z.boolean().optional(), config: uiComponentConfigInput }).parse(request.body);
    const draft = await currentUiDraft(app);
    const items = draft.items.map((component) => component.key === key ? { ...component, ...input, config: input.config === undefined ? component.config ?? null : input.config } : component);
    const saved = draft.version
      ? await app.prisma.uiConfigVersion.update({ where: { version: draft.version }, data: { content: items as unknown as Prisma.InputJsonValue } })
      : await app.prisma.uiConfigVersion.create({ data: { content: items as unknown as Prisma.InputJsonValue, createdById: request.user.sub } });
    await audit(app, request.user.sub, 'SAVE_DRAFT', 'UiConfigVersion', String(saved.version), { key, ...input });
    return { items, draftVersion: saved.version, status: saved.status };
  });

  app.put('/admin/ui-components/draft', { preHandler: requireAdmin }, async (request) => {
    const input = z.object({ items: uiComponentSnapshotInput }).parse(request.body);
    const draft = await currentUiDraft(app);
    const items = mergeUiComponents(input.items);
    const saved = draft.version
      ? await app.prisma.uiConfigVersion.update({ where: { version: draft.version }, data: { content: items as unknown as Prisma.InputJsonValue } })
      : await app.prisma.uiConfigVersion.create({ data: { content: items as unknown as Prisma.InputJsonValue, createdById: request.user.sub } });
    await audit(app, request.user.sub, 'SAVE_DRAFT', 'UiConfigVersion', String(saved.version), { componentCount: items.length });
    return { items, draftVersion: saved.version, status: saved.status };
  });

  app.post('/admin/ui-components/publish', { preHandler: requireAdmin }, async (request) => {
    const draft = await app.prisma.uiConfigVersion.findFirst({ where: { status: 'DRAFT' }, orderBy: { version: 'desc' } });
    if (!draft) throw Object.assign(new Error('没有可发布的页面组件草稿。'), { statusCode: 409 });
    const { items, repaired } = normalizeUiComponentSnapshot(draft.content);
    const published = await app.prisma.$transaction(async (tx) => {
      await tx.uiConfigVersion.updateMany({ where: { status: 'PUBLISHED' }, data: { status: 'SUPERSEDED' } });
      const result = await tx.uiConfigVersion.update({
        where: { version: draft.version },
        data: { status: 'PUBLISHED', content: items as unknown as Prisma.InputJsonValue, publishedById: request.user.sub, publishedAt: new Date() }
      });
      await syncUiComponentRows(tx, items);
      return result;
    });
    await audit(app, request.user.sub, 'PUBLISH', 'UiConfigVersion', String(published.version), { componentCount: items.length, repairedLegacyContent: repaired });
    return { items, version: published.version, publishedAt: published.publishedAt, repairedLegacyContent: repaired };
  });

  app.post('/admin/ui-components/rollback', { preHandler: requireAdmin }, async (request) => {
    const { version } = z.object({ version: z.number().int().positive() }).parse(request.body);
    const target = await app.prisma.uiConfigVersion.findUnique({ where: { version } });
    if (!target) throw Object.assign(new Error('找不到页面配置版本。'), { statusCode: 404 });
    const { items, repaired } = normalizeUiComponentSnapshot(target.content);
    const restored = await app.prisma.$transaction(async (tx) => {
      await tx.uiConfigVersion.updateMany({ where: { status: 'PUBLISHED' }, data: { status: 'SUPERSEDED' } });
      const result = await tx.uiConfigVersion.create({
        data: { status: 'PUBLISHED', content: items as unknown as Prisma.InputJsonValue, createdById: request.user.sub, publishedById: request.user.sub, publishedAt: new Date() }
      });
      await syncUiComponentRows(tx, items);
      return result;
    });
    await audit(app, request.user.sub, 'ROLLBACK', 'UiConfigVersion', String(restored.version), { sourceVersion: version, repairedLegacyContent: repaired });
    return { items, version: restored.version, publishedAt: restored.publishedAt, repairedLegacyContent: repaired };
  });

  app.get('/admin/upload-jobs', { preHandler: requireAdmin }, async (request) => {
    const { albumId, limit } = z.object({ albumId: z.string().trim().min(1).optional(), limit: z.coerce.number().int().min(1).max(200).optional() }).parse(request.query);
    const jobs = await app.prisma.uploadJob.findMany({
      where: albumId ? { episode: { albumId } } : undefined,
      orderBy: { createdAt: 'desc' }, take: limit ?? (albumId ? 200 : 100), include: { episode: true }
    });
    return { items: jobs };
  });

  app.post('/admin/upload-jobs', { preHandler: requireAdmin }, async (request) => {
    const input = uploadInput.parse(request.body);
    const episode = await app.prisma.episode.findFirst({ where: { id: input.episodeId }, select: { id: true, album: { select: { status: true } } } });
    if (!episode) throw Object.assign(new Error('分集不存在。'), { statusCode: 404 });
    if (episode.album.status === 'OFFLINE') throw Object.assign(new Error('下线剧集的分集不能上传。'), { statusCode: 409 });
    if (input.sourceExpiresAt && new Date(input.sourceExpiresAt) <= new Date()) {
      throw Object.assign(new Error('来源过期时间必须晚于当前时间。'), { statusCode: 400 });
    }
    const job = await app.prisma.$transaction(async (tx) => {
      const claimed = await tx.episode.updateMany({
        where: { id: input.episodeId, byteplusVid: null, byteplusUploadStatus: { in: ['PENDING', 'FAILED'] }, uploadJobs: { none: { status: { in: ['PENDING', 'PROCESSING'] } } } },
        data: { status: 'UPLOADING', byteplusUploadStatus: 'UPLOADING' }
      });
      if (claimed.count !== 1) throw Object.assign(new Error('该分集已有视频或正在上传，请先处理现有任务。'), { statusCode: 409 });
      return tx.uploadJob.create({ data: { episodeId: input.episodeId, sourceUrl: input.sourceUrl, sourceExpiresAt: input.sourceExpiresAt ? new Date(input.sourceExpiresAt) : undefined } });
    });
    await audit(app, request.user.sub, 'CREATE', 'UploadJob', job.id, { episodeId: input.episodeId });
    return job;
  });

  app.get('/admin/byteplus/media', { preHandler: requireAdmin }, async (request) => {
    const query = z.object({
      offset: z.coerce.number().int().min(0).default(0),
      pageSize: z.coerce.number().int().min(1).max(100).default(50),
      status: z.string().trim().min(1).optional()
    }).parse(request.query);
    return new BytePlusVodService(app.config).listMedia({ ...query, tags: uploadTags(uploadScope(app.config), '')[0] });
  });

  app.post('/admin/upload-jobs/local', { preHandler: requireAdmin }, async (request, reply) => {
    const upload = await request.file();
    if (!upload) return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: '请选择视频文件上传。', requestId: request.id } });
    const episodeField = upload.fields.episodeId;
    const episodeId = episodeField && !Array.isArray(episodeField) && 'value' in episodeField && typeof episodeField.value === 'string' ? episodeField.value.trim() : '';
    if (!episodeId) return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: 'episodeId is required.', requestId: request.id } });
    const fileName = upload.filename.trim();
    const extension = fileName.includes('.') ? fileName.slice(fileName.lastIndexOf('.')).toLowerCase() : '';
    if (!['.mp4', '.mov', '.m4v'].includes(extension)) {
      return reply.code(400).send({ error: { code: 'VALIDATION_ERROR', message: 'TikTok 短剧仅接受兼容的 MP4、MOV 或 M4V 视频格式。', requestId: request.id } });
    }
    const episode = await app.prisma.episode.findUnique({ where: { id: episodeId }, select: { id: true, albumId: true, title: true, episodeNo: true, byteplusVid: true, byteplusUploadStatus: true, coverAsset: { select: { publicUrl: true, status: true } }, album: { select: { title: true, status: true, tiktokAlbumId: true, tiktokVersion: true, onlineVersion: true } } } });
    if (!episode) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: '分集不存在。', requestId: request.id } });
    await assertPlatformOwner(app, episode.albumId);
    if (episode.album.status === 'OFFLINE') return reply.code(409).send({ error: { code: 'CONFLICT', message: '下线剧集的分集不能上传。', requestId: request.id } });
    if (episode.byteplusVid) return reply.code(409).send({ error: { code: 'CONFLICT', message: '该分集已绑定 BytePlus VID，请勿重复上传。', requestId: request.id } });
    if (episode.byteplusUploadStatus === 'UPLOADING') return reply.code(409).send({ error: { code: 'CONFLICT', message: '该分集正在上传，请等待当前任务结束后再操作。', requestId: request.id } });

    const tempDirectory = localUploadDirectory(app.config);
    const tempPath = join(tempDirectory, `${randomUUID()}${extension}`);
    await mkdir(tempDirectory, { recursive: true });
    let queued = false;
    try {
      await pipeline(upload.file, (await import('node:fs')).createWriteStream(tempPath));
      if (upload.file.truncated) throw Object.assign(new Error('所选文件超过 2 GB 大小限制。'), { statusCode: 413 });
      const [job] = await app.prisma.$transaction(async (tx) => {
        const claimed = await tx.episode.updateMany({
          where: { id: episodeId, byteplusVid: null, byteplusUploadStatus: { in: ['PENDING', 'FAILED'] }, uploadJobs: { none: { status: { in: ['PENDING', 'PROCESSING'] } } } },
          data: { status: 'UPLOADING', byteplusUploadStatus: 'UPLOADING' }
        });
        if (claimed.count !== 1) throw Object.assign(new Error('该分集已被其他上传任务占用，请刷新后重试。'), { statusCode: 409 });
        const created = await tx.uploadJob.create({
          data: { episodeId, sourceUrl: `local://${fileName}`, sourceType: 'FILE', sourceName: fileName, status: 'PENDING', localFilePath: tempPath, uploadScope: uploadScope(app.config), nextAttemptAt: new Date() }
        });
        return [created];
      }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
      queued = true;
      await audit(app, request.user.sub, 'QUEUE_LOCAL_UPLOAD', 'UploadJob', job.id, { episodeId, fileName });
      return reply.code(202).send({ job, platformSyncJob: null, episode: { id: episodeId, status: 'UPLOADING', byteplusVid: null } });
    } finally {
      if (!queued) await unlink(tempPath).catch(() => undefined);
    }
  });

  app.post('/admin/upload-jobs/:jobId/reconcile', { preHandler: requireAdmin }, async (request, reply) => {
    const { jobId } = jobParams.parse(request.params);
    const input = z.object({ byteplusVid: z.string().trim().min(1).max(256).optional() }).parse(request.body ?? {});
    const job = await app.prisma.uploadJob.findUnique({
      where: { id: jobId },
      include: { episode: { include: { coverAsset: true, album: true } } }
    });
    if (!job) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Upload job not found.', requestId: request.id } });
    if (job.sourceType !== 'FILE' || job.status !== 'PROCESSING') {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '只有待对账的本地上传任务可以对账。', requestId: request.id } });
    }
    if (!input.byteplusVid) {
      const now = new Date();
      if (job.leaseExpiresAt && job.leaseExpiresAt > now) {
        return { job, recovering: true, processing: 'ACTIVE', message: '该任务正在上传或确认 BytePlus VID，请等待处理完成。' };
      }
      const scheduled = await app.prisma.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', leaseToken: job.leaseToken, leaseExpiresAt: job.leaseExpiresAt }, data: { nextAttemptAt: now } });
      if (!scheduled.count) throw Object.assign(new Error('任务状态已变化，请刷新后查看。'), { statusCode: 409 });
      // Run only this task so a manual resume does not wait behind the worker's
      // current batch. The same database lease prevents duplicate transfers.
      setImmediate(() => {
        void processLocalUploadJobs(app.prisma, app.sharedPrisma, new BytePlusVodService(app.config), app.config, {
          jobId: job.id,
          log: (message, details) => app.log.warn({ ...details, miniAppKey: app.config.MINI_APP_KEY }, message)
        }).catch((error) => app.log.error({ err: error, jobId: job.id }, 'Manual upload recovery failed.'));
      });
      return { job: { ...job, nextAttemptAt: now }, recovering: true, processing: 'QUEUED', message: '已触发该任务继续处理，后台将立即尝试上传或确认 BytePlus VID。' };
    }
    if (job.leaseExpiresAt && job.leaseExpiresAt > new Date()) throw Object.assign(new Error('上传任务正在处理，请等待自动确认。'), { statusCode: 409 });
    if (job.providerJobId && job.providerJobId !== input.byteplusVid) {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '该任务已记录另一个 BytePlus VID，请先确认后再操作。', requestId: request.id } });
    }
    const mediaService = new BytePlusVodService(app.config);
    const [media] = await mediaService.getMediaInfos({ vids: [input.byteplusVid] });
    if (!media) return reply.code(404).send({ error: { code: 'BYTEPLUS_MEDIA_NOT_FOUND', message: '在配置的媒体空间中找不到这个 BytePlus VID。', requestId: request.id } });
    if (media.spaceName !== app.config.BYTEPLUS_SPACE_NAME) {
      return reply.code(409).send({ error: { code: 'BYTEPLUS_SPACE_MISMATCH', message: '无法确认该视频属于当前 BytePlus 空间，不能绑定到当前小程序。', requestId: request.id } });
    }
    await assertMediaScope(app.sharedPrisma, app.config, media);
    if (!job.uploadScope || !matchesUploadTags(media.tags, job.uploadScope, job.id)) throw Object.assign(new Error('此 VID 无法证明属于原上传任务，请使用自动恢复或重新上传。'), { statusCode: 409 });
    if (job.episode.byteplusVid && job.episode.byteplusVid !== media.vid) {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '该分集已经绑定了另一个 BytePlus VID。', requestId: request.id } });
    }
    const sharedMedia = await getOrCreateSharedMediaAsset(app.sharedPrisma as any, {
      byteplusVid: media.vid,
      byteplusAccountId: app.config.BYTEPLUS_ACCOUNT_ID,
      byteplusSpaceName: app.config.BYTEPLUS_SPACE_NAME,
      byteplusRegion: app.config.BYTEPLUS_REGION,
      miniAppKey: app.config.MINI_APP_KEY,
      title: media.title,
      coverUrl: media.coverUrl,
      durationMs: media.durationMs
    });
    const episode = await app.prisma.$transaction(async (tx) => {
      const updatedJob = await tx.uploadJob.updateMany({
        where: { id: job.id, status: 'PROCESSING', leaseToken: job.leaseToken, leaseExpiresAt: job.leaseExpiresAt },
        data: { status: 'SUCCEEDED', providerJobId: media.vid, errorMessage: null, completedAt: new Date(), leaseToken: null, leaseExpiresAt: null, localFilePath: null }
      });
      if (updatedJob.count !== 1) throw Object.assign(new Error('该对账任务已被其他操作处理，请刷新后查看。'), { statusCode: 409 });
      const bound = await tx.episode.updateMany({
        where: { id: job.episodeId, byteplusVid: null, byteplusUploadStatus: 'UPLOADING' },
        data: {
          byteplusVid: media.vid,
          byteplusCoverUrl: media.coverUrl,
          coverUrl: job.episode.coverAsset?.status === 'READY' ? job.episode.coverAsset.publicUrl : media.coverUrl,
          durationMs: media.durationMs,
          status: 'READY',
          byteplusUploadStatus: 'READY',
          tiktokVideoStatus: 'NOT_STARTED',
          tiktokVideoJobId: null,
          tiktokVideoError: null
        }
      });
      if (bound.count !== 1) throw Object.assign(new Error('分集状态已变化，请刷新后检查 VID。'), { statusCode: 409 });
      return tx.episode.findUniqueOrThrow({ where: { id: job.episodeId } });
    });
    if (job.localFilePath) await unlink(job.localFilePath).catch(() => undefined);
    await audit(app, request.user.sub, 'RECONCILE_LOCAL_UPLOAD', 'UploadJob', job.id, { episodeId: job.episodeId, byteplusVid: media.vid });
    const syncJob = app.config.TIKTOK_CLIENT_KEY && app.config.TIKTOK_CLIENT_SECRET
      ? await enqueueVideoSync(app.prisma as any, job.episodeId, request.user.sub)
      : null;
    return { job: { ...job, status: 'SUCCEEDED', providerJobId: media.vid, errorMessage: null, completedAt: new Date() }, episode, sharedMediaAsset: sharedMedia, platformSyncJob: syncJob };
  });

  app.post('/admin/upload-jobs/:jobId/release', { preHandler: requireAdmin }, async (request, reply) => {
    const { jobId } = jobParams.parse(request.params);
    z.object({ confirmation: z.literal('NO_BYTEPLUS_MEDIA') }).parse(request.body);
    const job = await app.prisma.uploadJob.findUnique({ where: { id: jobId } });
    if (!job) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Upload job not found.', requestId: request.id } });
    if (job.sourceType !== 'FILE' || job.status !== 'PROCESSING' || job.providerJobId || job.uploadScope || !job.startedAt || Date.now() - job.startedAt.getTime() < 2 * 60 * 60_000) {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '只能释放已超过两小时、未记录 VID 的本地待对账任务。', requestId: request.id } });
    }
    await app.prisma.$transaction(async (tx) => {
      const changed = await tx.uploadJob.updateMany({ where: { id: job.id, status: 'PROCESSING', providerJobId: null, leaseToken: job.leaseToken, leaseExpiresAt: job.leaseExpiresAt }, data: { status: 'FAILED', leaseToken: null, leaseExpiresAt: null, errorMessage: '管理员确认 BytePlus 无对应媒资后释放任务；请重新选择文件上传。', completedAt: new Date() } });
      if (changed.count !== 1) throw Object.assign(new Error('任务状态已变化，请刷新后重试。'), { statusCode: 409 });
      await tx.episode.updateMany({ where: { id: job.episodeId, byteplusVid: null, byteplusUploadStatus: 'UPLOADING' }, data: { status: 'ERROR', byteplusUploadStatus: 'FAILED' } });
    });
    await audit(app, request.user.sub, 'RELEASE_LOCAL_UPLOAD', 'UploadJob', job.id, { episodeId: job.episodeId });
    return { released: true };
  });

  app.get('/admin/upload-jobs/:jobId', { preHandler: requireAdmin }, async (request, reply) => {
    const { jobId } = jobParams.parse(request.params);
    const job = await app.prisma.uploadJob.findUnique({ where: { id: jobId }, include: { episode: true } });
    if (!job) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Upload job not found.', requestId: request.id } });
    return job;
  });

  app.post('/admin/upload-jobs/:jobId/retry', { preHandler: requireAdmin }, async (request, reply) => {
    const { jobId } = jobParams.parse(request.params);
    const job = await app.prisma.uploadJob.findUnique({ where: { id: jobId } });
    if (!job) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Upload job not found.', requestId: request.id } });
    if (job.sourceType === 'FILE' && (!job.localFilePath || job.uploadScope !== uploadScope(app.config))) {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '本地上传任务需要重新选择视频文件后再试。', requestId: request.id } });
    }
    if (job.status !== 'FAILED') {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: 'Only failed upload jobs can be retried.', requestId: request.id } });
    }
    if (job.sourceExpiresAt && job.sourceExpiresAt <= new Date()) {
      return reply.code(409).send({ error: { code: 'CONFLICT', message: '上传来源地址已过期，无法重试。', requestId: request.id } });
    }
    const retriedJob = await app.prisma.$transaction(async (tx) => {
      if (job.sourceType === 'FILE') {
        const claimed = await tx.episode.updateMany({ where: { id: job.episodeId, byteplusVid: null, uploadJobs: { none: { status: { in: ['PENDING', 'PROCESSING'] } } } }, data: { status: 'UPLOADING', byteplusUploadStatus: 'UPLOADING' } });
        if (claimed.count !== 1) throw Object.assign(new Error('分集已有视频或上传任务，请刷新。'), { statusCode: 409 });
        const changed = await tx.uploadJob.updateMany({ where: { id: job.id, status: 'FAILED' }, data: { status: 'PENDING', retryCount: 0, leaseToken: null, leaseExpiresAt: null, errorMessage: null, completedAt: null, nextAttemptAt: new Date() } });
        if (changed.count !== 1) throw Object.assign(new Error('任务状态已变化，请刷新。'), { statusCode: 409 });
        return tx.uploadJob.findUniqueOrThrow({ where: { id: job.id } });
      }
      const next = await tx.uploadJob.update({
        where: { id: job.id },
        data: {
          status: 'PENDING',
          providerJobId: null,
          retryCount: 0,
          errorMessage: null,
          startedAt: null,
          completedAt: null,
          nextAttemptAt: new Date()
        }
      });
      await tx.episode.update({ where: { id: job.episodeId }, data: { status: 'DRAFT' } });
      return next;
    });
    await audit(app, request.user.sub, 'RETRY', 'UploadJob', retriedJob.id, { episodeId: retriedJob.episodeId });
    return retriedJob;
  });

  app.get('/admin/platform-sync-jobs', { preHandler: requirePermission('content.read') }, async (request) => {
    const query = z.object({ albumId: z.string().min(1).max(128).optional(), episodeId: z.string().min(1).max(128).optional(), limit: z.coerce.number().int().min(1).max(100).default(50) }).parse(request.query);
    const items = await (app.prisma as any).platformSyncJob.findMany({
      where: { ...(query.albumId ? { albumId: query.albumId } : {}), ...(query.episodeId ? { episodeId: query.episodeId } : {}) },
      orderBy: { createdAt: 'desc' },
      take: query.limit,
      include: { album: { select: { id: true, title: true } }, episode: { select: { id: true, episodeNo: true, title: true } }, coverAsset: { select: { id: true, publicUrl: true } }, createdByAdminUser: { select: { id: true, email: true } } }
    });
    return { items };
  });

  app.get('/admin/shared/media-assets', { preHandler: requirePermission('content.read') }, async (request) => {
    const query = z.object({
      status: z.string().trim().min(1).optional(),
      byteplusVid: z.string().trim().min(1).max(256).optional(),
      sourceSha256: z.string().trim().min(1).max(128).optional(),
      limit: z.coerce.number().int().min(1).max(100).default(100)
    }).parse(request.query);
    return { items: await listSharedMediaAssets(app.sharedPrisma as any, { ...query, status: query.status as any }) };
  });

  app.get('/admin/shared/albums', { preHandler: requirePermission('content.read') }, async () => {
    const items = await (app.sharedPrisma as any).sharedTikTokAlbum.findMany({
      orderBy: { updatedAt: 'desc' },
      include: {
        _count: { select: { episodes: true, authorizations: true } },
        authorizations: true
      }
    });
    return { items };
  });

  app.get('/admin/shared/albums/:sharedAlbumId', { preHandler: requirePermission('content.read') }, async (request, reply) => {
    const { sharedAlbumId } = z.object({ sharedAlbumId: z.string().min(1).max(128) }).parse(request.params);
    const item = await (app.sharedPrisma as any).sharedTikTokAlbum.findUnique({
      where: { id: sharedAlbumId },
      include: {
        episodes: { include: { media: true }, orderBy: { episodeNo: 'asc' } },
        authorizations: true,
        operations: { orderBy: { createdAt: 'desc' }, take: 20 }
      }
    });
    if (!item) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: '共享主剧目不存在。', requestId: request.id } });
    return item;
  });

  app.post('/admin/albums/:albumId/share', { preHandler: requirePermission('content.publish') }, async (_request, reply) => reply.code(410).send({ error: { code: 'FEATURE_RETIRED', message: '请使用已审核剧目授权播放，不再手动登记共享主剧目。' } }));

  app.get('/admin/shared-playback/:albumId', { preHandler: requirePermission('content.publish') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    const { targetApps } = z.object({ targetApps: z.string().min(1) }).parse(request.query);
    const targets = playbackTargetsInput.parse(targetApps.split(','));
    assertSameMiniAppOrganization(app.config.MINI_APP_KEY as MiniAppKey, targets);
    const operator = await app.prisma.adminUser.findUnique({ where: { id: request.user.sub }, select: { email: true } });
    if (!operator) throw Object.assign(new Error('当前管理员不存在。'), { statusCode: 403 });
    return sharedPlaybackStatus({ sharedDb: app.sharedPrisma as any, sourceDb: app.prisma as any, dbByApp: app.miniAppPrisma as any, sourceApp: app.config.MINI_APP_KEY as MiniAppKey, sourceAlbumId: albumId, targetApps: targets, operatorEmail: operator.email, authorizedAdminIds: await playbackAdminIds(app, request, targets) });
  });

  app.post('/admin/shared-playback/:albumId', { preHandler: requirePermission('content.publish') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    const input = sharedPlaybackInput.parse(request.body);
    assertSameMiniAppOrganization(app.config.MINI_APP_KEY as MiniAppKey, input.targetApps);
    const operator = await app.prisma.adminUser.findUnique({ where: { id: request.user.sub }, select: { email: true } });
    if (!operator) throw Object.assign(new Error('当前管理员不存在。'), { statusCode: 403 });
    const context = { sharedDb: app.sharedPrisma as any, sourceDb: app.prisma as any, dbByApp: app.miniAppPrisma as any, env: app.rootConfig, sourceApp: app.config.MINI_APP_KEY as MiniAppKey, sourceAlbumId: albumId, targetApps: input.targetApps, operatorEmail: operator.email, authorizedAdminIds: await playbackAdminIds(app, request, input.targetApps) };
    let result;
    if (input.action === 'AUTHORIZE') result = await authorizeSharedPlayback(context);
    else {
      const state = await sharedPlaybackStatus(context);
      if (!state.sharedAlbumId) throw Object.assign(new Error('尚未建立主剧目授权记录，请先授权播放。'), { statusCode: 409 });
      const allowed = state.items.filter((item) => item.status !== 'ACCESS_ERROR');
      const operation = allowed.length ? await enqueueSharedAlbumReconcile(app.sharedPrisma as any, state.sharedAlbumId) : null;
      result = { items: state.items.map((item) => ({ miniAppKey: item.miniAppKey, accepted: item.status !== 'ACCESS_ERROR', error: item.status === 'ACCESS_ERROR' ? item.error : undefined, operationId: operation?.id })) };
    }
    await audit(app, request.user.sub, `SHARED_PLAYBACK_${input.action}`, 'Album', albumId, { targets: result.items.map((item) => ({ miniAppKey: item.miniAppKey, accepted: item.accepted })) });
    return result;
  });

  app.route({ method: ['GET', 'POST'], url: '/admin/multi-app-releases/:albumId', preHandler: requirePermission('content.publish'), handler: async (_request, reply) => reply.code(410).send({ error: { code: 'FEATURE_RETIRED', message: '多小程序独立发布已停用，请使用已审核剧目授权播放。' } }) });

  app.post('/admin/shared/albums/:sharedAlbumId/authorizations', { preHandler: requirePermission('content.publish') }, async (_request, reply) => reply.code(410).send({ error: { code: 'FEATURE_RETIRED', message: '请使用已审核剧目授权播放，系统自动建立目标映射。' } }));

  app.post('/admin/shared/albums/:sharedAlbumId/reconcile', { preHandler: requirePermission('content.sync') }, async (request) => {
    ensureTikTokPlatformConfigured(app);
    const { sharedAlbumId } = z.object({ sharedAlbumId: z.string().min(1).max(128) }).parse(request.params);
    const source = await app.sharedPrisma.sharedTikTokAlbum.findUnique({ where: { id: sharedAlbumId }, select: { ownerMiniAppKey: true } });
    if (source?.ownerMiniAppKey !== app.config.MINI_APP_KEY) throw Object.assign(new Error('请在主小程序后台对账授权剧目。'), { statusCode: 403 });
    const operation = await enqueueSharedAlbumReconcile(app.sharedPrisma as any, sharedAlbumId, request.user.sub);
    await audit(app, request.user.sub, 'RECONCILE_SHARED_ALBUM', 'SharedTikTokAlbum', sharedAlbumId, { operationId: operation.id });
    return { operation };
  });

  app.post('/admin/cover-assets/:coverAssetId/sync', { preHandler: requirePermission('content.sync') }, async (request) => {
    ensureTikTokPlatformConfigured(app);
    const { coverAssetId } = z.object({ coverAssetId: z.string().min(1).max(128) }).parse(request.params);
    const job = await enqueueCoverSync(app.prisma as any, coverAssetId, request.user.sub);
    await audit(app, request.user.sub, 'SYNC_TIKTOK', 'CoverAsset', coverAssetId, { jobId: job?.id ?? null });
    return { job, alreadySynced: !job };
  });

  app.post('/admin/episodes/:episodeId/sync-tiktok-video', { preHandler: requirePermission('content.sync') }, async (request) => {
    ensureTikTokPlatformConfigured(app);
    const { episodeId } = episodeParams.parse(request.params);
    const episode = await app.prisma.episode.findUnique({ where: { id: episodeId }, select: { albumId: true } });
    if (episode) await assertPlatformOwner(app, episode.albumId);
    const job = await enqueueVideoSync(app.prisma as any, episodeId, request.user.sub);
    await audit(app, request.user.sub, 'SYNC_TIKTOK_VIDEO', 'Episode', episodeId, { jobId: job?.id ?? null });
    return { job, alreadySynced: !job };
  });

  app.post('/admin/albums/:albumId/sync-version', { preHandler: requirePermission('content.sync') }, async (request) => {
    ensureTikTokPlatformConfigured(app);
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    const job = await enqueueAlbumVersionSync(app.prisma as any, albumId, request.user.sub);
    await audit(app, request.user.sub, 'SYNC_TIKTOK_ALBUM_VERSION', 'Album', albumId, { jobId: job.id, snapshotHash: job.snapshotHash });
    return { job };
  });

  app.post('/admin/albums/:albumId/reconcile', { preHandler: requirePermission('content.sync') }, async (request) => {
    ensureTikTokPlatformConfigured(app);
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    const job = await enqueueAlbumAction(app.prisma as any, 'RECONCILE', albumId, request.user.sub);
    await audit(app, request.user.sub, 'RECONCILE_TIKTOK_ALBUM', 'Album', albumId, { jobId: job.id });
    return { job };
  });

  app.post('/admin/albums/:albumId/review-submit', { preHandler: requirePermission('content.review') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    const { priorityScore } = z.object({ priorityScore: z.union([z.literal(1), z.literal(2)]).default(2) }).strict().parse(request.body ?? {});
    ensureTikTokPlatformConfigured(app);
    const job = await enqueueAlbumAction(app.prisma as any, 'REVIEW', albumId, request.user.sub, priorityScore);
    await audit(app, request.user.sub, 'SUBMIT_TIKTOK_REVIEW', 'Album', albumId, { jobId: job.id, priorityScore });
    return { job };
  });

  app.post('/admin/albums/:albumId/online-version', { preHandler: requirePermission('content.publish') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    ensureTikTokPlatformConfigured(app);
    const job = await enqueueAlbumAction(app.prisma as any, 'SET_ONLINE_VERSION', albumId, request.user.sub);
    await audit(app, request.user.sub, 'SET_TIKTOK_ONLINE_VERSION', 'Album', albumId, { jobId: job.id });
    return { job };
  });

  app.post('/admin/albums/:albumId/online', { preHandler: requirePermission('content.publish') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    ensureTikTokPlatformConfigured(app);
    const job = await enqueueAlbumAction(app.prisma as any, 'PUBLISH', albumId, request.user.sub);
    await audit(app, request.user.sub, 'PUBLISH_TIKTOK_ALBUM', 'Album', albumId, { jobId: job.id });
    return { job };
  });

  app.post('/admin/albums/:albumId/offline', { preHandler: requirePermission('content.publish') }, async (request) => {
    const { albumId } = albumParams.parse(request.params);
    await assertPlatformOwner(app, albumId);
    ensureTikTokPlatformConfigured(app);
    const job = await enqueueAlbumAction(app.prisma as any, 'UNPUBLISH', albumId, request.user.sub);
    await audit(app, request.user.sub, 'UNPUBLISH_TIKTOK_ALBUM', 'Album', albumId, { jobId: job.id });
    return { job };
  });

  app.get('/admin/home-blocks', { preHandler: requireAdmin }, async () => app.prisma.homeBlock.findMany({ orderBy: { sortOrder: 'asc' }, include: { items: true } }));
  app.patch('/admin/home-blocks/:blockId', { preHandler: requireAdmin }, async (request) => {
    const { blockId } = blockParams.parse(request.params);
    const input = z.object({ title: z.string().trim().min(1).max(160).optional(), enabled: z.boolean().optional(), sortOrder: z.number().int().nonnegative().optional(), config: z.unknown().optional(), startsAt: z.string().datetime().nullable().optional(), endsAt: z.string().datetime().nullable().optional() }).parse(request.body);
    const block = await app.prisma.homeBlock.update({ where: { id: blockId }, data: { ...input, config: input.config === undefined ? undefined : input.config === null ? Prisma.JsonNull : input.config as Prisma.InputJsonValue, startsAt: input.startsAt === undefined ? undefined : input.startsAt ? new Date(input.startsAt) : null, endsAt: input.endsAt === undefined ? undefined : input.endsAt ? new Date(input.endsAt) : null } });
    await audit(app, request.user.sub, 'UPDATE', 'HomeBlock', block.id, input);
    return block;
  });
  app.post('/admin/home-blocks/:blockId/items', { preHandler: requireAdmin }, async (request) => {
    const { blockId } = blockParams.parse(request.params);
    const input = z.object({ albumId: z.string().min(1).max(128).optional(), targetEpisodeId: z.string().min(1).max(128).optional(), imageUrl: z.string().url().optional(), previewUrl: z.string().url().optional(), linkPath: z.string().regex(/^\/(album|watch)\//).optional(), sortOrder: z.number().int().nonnegative(), startsAt: z.string().datetime().nullable().optional(), endsAt: z.string().datetime().nullable().optional() }).parse(request.body);
    const item = await app.prisma.homeBlockItem.create({ data: { ...input, blockId, startsAt: input.startsAt ? new Date(input.startsAt) : undefined, endsAt: input.endsAt ? new Date(input.endsAt) : undefined } });
    await audit(app, request.user.sub, 'CREATE', 'HomeBlockItem', item.id, { blockId });
    return item;
  });
  app.patch('/admin/home-blocks/:blockId/items/:itemId', { preHandler: requireAdmin }, async (request) => {
    const { blockId, itemId } = blockItemParams.parse(request.params);
    const input = z.object({ imageUrl: z.string().url().nullable().optional(), previewUrl: z.string().url().nullable().optional(), linkPath: z.string().regex(/^\/(album|watch)\//).nullable().optional(), sortOrder: z.number().int().nonnegative().optional(), startsAt: z.string().datetime().nullable().optional(), endsAt: z.string().datetime().nullable().optional() }).parse(request.body);
    const result = await app.prisma.homeBlockItem.updateMany({ where: { id: itemId, blockId }, data: { ...input, startsAt: input.startsAt === undefined ? undefined : input.startsAt ? new Date(input.startsAt) : null, endsAt: input.endsAt === undefined ? undefined : input.endsAt ? new Date(input.endsAt) : null } });
    if (!result.count) throw Object.assign(new Error('首页区块内容不存在。'), { statusCode: 404 });
    const item = await app.prisma.homeBlockItem.findUniqueOrThrow({ where: { id: itemId } });
    await audit(app, request.user.sub, 'UPDATE', 'HomeBlockItem', item.id, input);
    return item;
  });
  app.get('/admin/genres', { preHandler: requireAdmin }, async () => app.prisma.genre.findMany({ orderBy: { name: 'asc' } }));
  app.post('/admin/genres', { preHandler: requireAdmin }, async (request) => {
    const input = z.object({ slug: z.string().trim().regex(/^[a-z0-9-]+$/), name: z.string().trim().min(1).max(80), translations: z.record(z.string(), z.string()).optional() }).parse(request.body);
    const genre = await app.prisma.genre.create({ data: input });
    await audit(app, request.user.sub, 'CREATE', 'Genre', genre.id);
    return genre;
  });
  app.patch('/admin/genres/:genreId', { preHandler: requireAdmin }, async (request) => {
    const { genreId } = z.object({ genreId: z.string().min(1).max(128) }).parse(request.params);
    const input = z.object({ name: z.string().trim().min(1).max(80).optional(), translations: z.record(z.string(), z.string()).optional() }).parse(request.body);
    const genre = await app.prisma.genre.update({ where: { id: genreId }, data: input });
    await audit(app, request.user.sub, 'UPDATE', 'Genre', genre.id, input);
    return genre;
  });
  app.post('/admin/translations', { preHandler: requireAdmin }, async (request) => {
    const input = z.object({ kind: z.enum(['album', 'episode']), contentId: z.string().min(1).max(128), locale: publicLocaleSchema, title: z.string().trim().min(1).max(160), description: z.string().trim().max(20_000).optional(), coverUrl: z.string().url().nullable().optional(), coverOnly: z.boolean().optional(), subtitleRef: z.string().max(512).nullable().optional() }).parse(request.body);
    if (input.kind === 'album') {
      if (input.coverOnly) {
        const translation = await saveAlbumTranslationCover(app, input.contentId, input.locale, input.coverUrl);
        await audit(app, request.user.sub, 'UPDATE_TRANSLATION_COVER', 'AlbumTranslation', translation.id, { coverUrl: input.coverUrl });
        return translation;
      }
      const shared = await findDisplayMetadataAlbum(app.sharedPrisma as any, app.config.MINI_APP_KEY, input.contentId);
      if (shared) {
        const current = await app.prisma.albumTranslation.findUnique({ where: { albumId_locale: { albumId: input.contentId, locale: input.locale } } });
        if (!current || current.title !== input.title || current.description !== (input.description ?? '')) {
          const operator = await checkDisplayMetadataOwner(app, request, shared);
          const view = await readDisplayMetadata(app.sharedPrisma as any, app.miniAppPrisma as any, app.config.MINI_APP_KEY, input.contentId);
          const text = { locale: input.locale, title: input.title, description: input.description ?? '' };
          await saveSharedDisplayMetadata(app.sharedPrisma as any, shared, displayMetadataInput.parse({ ...view,
            translations: [...view.translations.filter((item) => item.locale !== input.locale), text] }), view.version, operator);
        }
        if (input.coverUrl !== undefined) await saveAlbumTranslationCover(app, input.contentId, input.locale, input.coverUrl);
        await audit(app, request.user.sub, 'UPSERT_SHARED_TRANSLATION', 'Album', input.contentId, input);
        return { ...input, metadataSync: { shared: true } };
      }
      const translation = await app.prisma.albumTranslation.upsert({ where: { albumId_locale: { albumId: input.contentId, locale: input.locale } }, create: { albumId: input.contentId, locale: input.locale, title: input.title, description: input.description ?? '', coverUrl: input.coverUrl }, update: { title: input.title, description: input.description ?? '', coverUrl: input.coverUrl } });
      await audit(app, request.user.sub, 'UPSERT', 'AlbumTranslation', translation.id, input);
      return translation;
    }
    const translation = await app.prisma.episodeTranslation.upsert({ where: { episodeId_locale: { episodeId: input.contentId, locale: input.locale } }, create: { episodeId: input.contentId, locale: input.locale, title: input.title, description: input.description, coverUrl: input.coverUrl, subtitleRef: input.subtitleRef }, update: { title: input.title, description: input.description, coverUrl: input.coverUrl, subtitleRef: input.subtitleRef } });
    await audit(app, request.user.sub, 'UPSERT', 'EpisodeTranslation', translation.id, input);
    return translation;
  });
  app.get('/admin/analytics/revenue', { preHandler: requireAdmin }, async () => app.prisma.adRevenue.findMany({ orderBy: { reportDate: 'desc' }, take: 100 }));
  app.post('/admin/analytics/revenue/import', { preHandler: requireAdmin }, async (request) => {
    const input = z.object({
      source: z.string().trim().min(1).max(64),
      rows: z.array(z.object({
        reportDate: z.string().datetime(),
        adType: z.enum(['REWARDED', 'INTERSTITIAL']),
        placementId: z.string().trim().min(1).max(128),
        albumId: z.string().min(1).max(128).nullable().optional(),
        episodeId: z.string().min(1).max(128).nullable().optional(),
        reportKey: z.string().trim().min(1).max(256),
        impressions: z.number().int().nonnegative().default(0),
        completedViews: z.number().int().nonnegative().default(0),
        revenueMicros: z.string().regex(/^\d+$/).default('0'),
        currency: z.string().trim().length(3).default('USD')
      })).min(1).max(10_000)
    }).parse(request.body);
    let imported = 0;
    for (const row of input.rows) {
      await app.prisma.adRevenue.upsert({
        where: { reportKey: row.reportKey },
        create: { ...row, source: input.source, reportDate: new Date(row.reportDate), revenueMicros: BigInt(row.revenueMicros) },
        update: { ...row, source: input.source, reportDate: new Date(row.reportDate), revenueMicros: BigInt(row.revenueMicros) }
      });
      imported += 1;
    }
    await audit(app, request.user.sub, 'IMPORT', 'AdRevenue', undefined, { source: input.source, rows: imported });
    return { imported };
  });
  app.get('/admin/analytics/health', { preHandler: requireAdmin }, async (request) => {
    const { minutes } = z.object({ minutes: z.coerce.number().int().min(5).max(1440).default(30) }).parse(request.query);
    const windowStart = new Date(Date.now() - minutes * 60_000);
    const runtimeModel = app.prisma.miniAppRuntimeError;
    const runtimeGroups = runtimeModel ? await runtimeModel.groupBy({ by: ['kind'], where: { createdAt: { gte: windowStart } }, _count: { _all: true } }) : [];
    const runtimeErrors = runtimeModel ? await runtimeModel.findMany({ where: { createdAt: { gte: windowStart } }, orderBy: { createdAt: 'desc' }, take: 30 }) : [];
    const runtimeCount = (kind: string) => runtimeGroups.find((row) => row.kind === kind)?._count._all ?? 0;
    const [adFailures, playbackErrors, uploadFailures, platformFailures, recentAds, recentPlayback, recentUploads, recentPlatform] = await Promise.all([
      app.prisma.adEvent.count({ where: { createdAt: { gte: windowStart }, eventType: 'FAILED' } }),
      app.prisma.playbackQualityEvent.count({ where: { createdAt: { gte: windowStart }, eventType: 'ERROR' } }),
      app.prisma.uploadJob.count({ where: { completedAt: { gte: windowStart }, status: 'FAILED' } }),
      app.prisma.platformSyncJob.count({ where: { updatedAt: { gte: windowStart }, status: { in: ['FAILED', 'CONFLICT'] } } }),
      app.prisma.adEvent.findMany({ where: { createdAt: { gte: windowStart }, eventType: 'FAILED' }, select: { createdAt: true, errorCode: true, placementId: true, scope: true }, orderBy: { createdAt: 'desc' }, take: 5 }),
      app.prisma.playbackQualityEvent.findMany({ where: { createdAt: { gte: windowStart }, eventType: 'ERROR' }, select: { createdAt: true, errorCode: true, episode: { select: { title: true } } }, orderBy: { createdAt: 'desc' }, take: 5 }),
      app.prisma.uploadJob.findMany({ where: { completedAt: { gte: windowStart }, status: 'FAILED' }, select: { completedAt: true, errorMessage: true, episode: { select: { title: true } } }, orderBy: { completedAt: 'desc' }, take: 5 }),
      app.prisma.platformSyncJob.findMany({ where: { updatedAt: { gte: windowStart }, status: { in: ['FAILED', 'CONFLICT'] } }, select: { updatedAt: true, kind: true, status: true, errorMessage: true, album: { select: { title: true } } }, orderBy: { updatedAt: 'desc' }, take: 5 })
    ]);
    return {
      generatedAt: new Date().toISOString(), windowStart: windowStart.toISOString(),
      counts: { adFailures, playbackErrors, uploadFailures, platformFailures, startupErrors: runtimeCount('STARTUP'), apiErrors: runtimeCount('API') + runtimeCount('PLAYBACK'), scriptErrors: runtimeCount('SCRIPT'), clientAdErrors: runtimeCount('AD') },
      recent: [
        ...runtimeErrors.map((item) => ({ kind: ({ STARTUP: '启动异常', API: '接口加载失败', PLAYBACK: '剧集加载失败', SCRIPT: '脚本异常', AD: '广告运行异常' } as Record<string, string>)[item.kind] ?? item.kind, createdAt: item.createdAt, message: `${item.phase} · ${item.message}`, releaseId: item.releaseId, path: item.path, requestId: item.requestId, durationMs: item.durationMs, statusCode: item.statusCode, occurredAt: item.occurredAt })),
        ...recentAds.map((item) => ({ kind: '广告失败', createdAt: item.createdAt, message: `${item.scope} · ${item.errorCode ?? '未知错误'} · ${item.placementId}` })),
        ...recentPlayback.map((item) => ({ kind: '播放错误', createdAt: item.createdAt, message: `${item.episode.title} · ${item.errorCode ?? '未知错误'}` })),
        ...recentUploads.map((item) => ({ kind: '上传失败', createdAt: item.completedAt!, message: `${item.episode?.title ?? '分集'} · ${item.errorMessage ?? '未知错误'}` })),
        ...recentPlatform.map((item) => ({ kind: item.status === 'CONFLICT' ? '平台结果待确认' : '平台同步失败', createdAt: item.updatedAt, message: `${item.album?.title ?? item.kind} · ${item.errorMessage ?? '未知错误'}` }))
      ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, 30)
    };
  });
  app.get('/admin/analytics/overview', { preHandler: requireAdmin }, async () => {
    return cachedAnalytics(app, 'overview', async () => {
      const snapshot = await app.prisma.analyticsOverviewSnapshot?.findUnique({ where: { id: 'default' } });
      if (snapshot?.totals) return { ...(snapshot.totals as Prisma.JsonObject), updatedAt: snapshot.updatedAt };

      const [albums, episodes, users, likes, favorites, shares, searches, unlocks] = await Promise.all([
      app.prisma.album.count({ where: { status: 'ONLINE' } }),
      app.prisma.episode.count({ where: { status: 'ONLINE', album: { status: 'ONLINE' } } }),
      app.prisma.user.count(),
      app.prisma.albumLike.count(),
      app.prisma.albumFavorite.count(),
      app.prisma.shareEvent.count(),
      app.prisma.searchEvent.count(),
      app.prisma.episodeUnlock.count()
      ]);
      return { albums, episodes, users, likes, favorites, shares, searches, rewardedUnlocks: unlocks };
    });
  });
  app.get('/admin/analytics/audience', { preHandler: requireAdmin }, async (request) => {
    const range = resolveAnalyticsRange(analyticsQuery.parse(request.query));
    return cachedAnalytics(app, `audience:${range.from}:${range.to}:${range.timezone}`, async () => {
      const where = { gte: range.start, lt: range.end };
      const summary = await readDailySummary(app, range);
      const countActiveUsers = (start: Date) => app.prisma.$queryRaw<Array<{ count: number }>>(Prisma.sql`
      SELECT COUNT(DISTINCT "userId")::int AS count FROM "AppSession"
      WHERE "startedAt" >= ${start} AND "startedAt" < ${range.end}
    `);
      const [activeRows, newUsers, watchSessions, completedEpisodes, favorites, shares, searches, dailyNewRows, dailyActiveRows, dauRows, wauRows, mauRows] = await Promise.all([
      countActiveUsers(range.start),
      summary ? Promise.resolve(summary.totals.newUsers) : app.prisma.user.count({ where: { createdAt: where } }),
      summary ? Promise.resolve(summary.totals.watchSessions) : app.prisma.playbackSession.count({ where: { startedAt: where } }),
      summary ? Promise.resolve(summary.totals.completedEpisodes) : app.prisma.episodeCompletionEvent.count({ where: { completedAt: where } }),
      summary ? Promise.resolve(summary.totals.favorites) : app.prisma.albumFavorite.count({ where: { createdAt: where } }),
      summary ? Promise.resolve(summary.totals.shares) : app.prisma.shareEvent.count({ where: { createdAt: where } }),
      summary ? Promise.resolve(summary.totals.searches) : app.prisma.searchEvent.count({ where: { createdAt: where } }),
      summary ? Promise.resolve(summary.dailyNewUsers) : app.prisma.$queryRaw<Array<{ date: string; count: number }>>(Prisma.sql`
        SELECT to_char(date_trunc('day', "createdAt" AT TIME ZONE 'UTC' AT TIME ZONE ${range.timezone}), 'YYYY-MM-DD') AS date,
               COUNT(*)::int AS count
        FROM "User"
        WHERE "createdAt" >= ${range.start} AND "createdAt" < ${range.end}
        GROUP BY 1
        ORDER BY 1
      `),
      summary ? Promise.resolve(summary.dailyActiveUsers) : app.prisma.$queryRaw<Array<{ date: string; count: number }>>(Prisma.sql`
        SELECT to_char(date_trunc('day', "startedAt" AT TIME ZONE 'UTC' AT TIME ZONE ${range.timezone}), 'YYYY-MM-DD') AS date,
               COUNT(DISTINCT "userId")::int AS count
        FROM "AppSession"
        WHERE "startedAt" >= ${range.start} AND "startedAt" < ${range.end}
        GROUP BY 1
        ORDER BY 1
      `),
      countActiveUsers(zonedMidnight(range.to, range.timezone)),
      countActiveUsers(zonedMidnight(addDateKeyDays(range.to, -6), range.timezone)),
      countActiveUsers(zonedMidnight(addDateKeyDays(range.to, -29), range.timezone))
      ]);
      return {
      from: range.from,
      to: range.to,
      timezone: range.timezone,
      periodDays: range.periodDays,
      activeUsers: activeRows[0]?.count ?? 0,
      dau: dauRows[0]?.count ?? 0,
      wau: wauRows[0]?.count ?? 0,
      mau: mauRows[0]?.count ?? 0,
      newUsers,
      watchSessions,
      completedEpisodes,
      favorites,
      shares,
      searches,
      dailyNewUsers: completeDailySeries(range.from, range.periodDays, dailyNewRows),
      dailyActiveUsers: completeDailySeries(range.from, range.periodDays, dailyActiveRows),
      updatedAt: summary?.updatedAt ?? null
      };
    });
  });
  app.get('/admin/analytics/playback-quality', { preHandler: requireAdmin }, async (request) => {
    const range = resolveAnalyticsRange(analyticsQuery.parse(request.query));
    return cachedAnalytics(app, `playback:${range.from}:${range.to}:${range.timezone}`, async () => {
      const createdAt = { gte: range.start, lt: range.end };
      const summary = await readDailySummary(app, range);
      if (summary?.playback) {
        const recentErrors = await app.prisma.playbackQualityEvent.findMany({
          where: { createdAt, eventType: 'ERROR' }, select: { errorCode: true, createdAt: true, episode: { select: { title: true } } },
          orderBy: { createdAt: 'desc' }, take: 10
        });
        const { totalEvents } = summary.playback;
        const errorCount = summary.totals.playbackErrors;
        return { from: range.from, to: range.to, timezone: range.timezone, periodDays: range.periodDays,
          ...summary.playback, errorCount, firstFrames: summary.playback.eventTypes.find((item) => item.eventType === 'FIRST_FRAME')?.count ?? 0,
          errorRate: totalEvents ? Number((errorCount / totalEvents * 100).toFixed(2)) : 0,
          updatedAt: summary.updatedAt,
          recentErrors: recentErrors.map((event) => ({ episodeTitle: event.episode.title, errorCode: event.errorCode, createdAt: event.createdAt })) };
      }
      const [totals, errorCount, eventTypes, definitions, networks, recentErrors] = await Promise.all([
      app.prisma.playbackQualityEvent.aggregate({ where: { createdAt }, _count: true, _avg: { startupMs: true }, _sum: { bufferMs: true } }),
      app.prisma.playbackQualityEvent.count({ where: { createdAt, eventType: 'ERROR' } }),
      app.prisma.playbackQualityEvent.groupBy({ by: ['eventType'], where: { createdAt }, _count: { _all: true } }),
      app.prisma.playbackQualityEvent.groupBy({ by: ['definition'], where: { createdAt, definition: { not: null } }, _count: { _all: true } }),
      app.prisma.playbackQualityEvent.groupBy({ by: ['networkType'], where: { createdAt, networkType: { not: null } }, _count: { _all: true } }),
      app.prisma.playbackQualityEvent.findMany({
        where: { createdAt, eventType: 'ERROR' },
        select: { errorCode: true, createdAt: true, episode: { select: { title: true } } },
        orderBy: { createdAt: 'desc' },
        take: 10
      })
      ]);
      const totalEvents = totals._count;
      return {
      from: range.from,
      to: range.to,
      timezone: range.timezone,
      periodDays: range.periodDays,
      totalEvents,
      firstFrames: eventTypes.find((item) => item.eventType === 'FIRST_FRAME')?._count._all ?? 0,
      errorCount,
      errorRate: totalEvents ? Number((errorCount / totalEvents * 100).toFixed(2)) : 0,
      averageStartupMs: totals._avg.startupMs === null ? null : Math.round(totals._avg.startupMs),
      totalBufferMs: totals._sum.bufferMs ?? 0,
      updatedAt: null,
      eventTypes: eventTypes.map((item) => ({ eventType: item.eventType, count: item._count._all })),
      definitions: definitions.map((item) => ({ definition: item.definition, count: item._count._all })),
      networks: networks.map((item) => ({ networkType: item.networkType, count: item._count._all })),
      recentErrors: recentErrors.map((event) => ({ episodeTitle: event.episode.title, errorCode: event.errorCode, createdAt: event.createdAt }))
      };
    });
  });
}
