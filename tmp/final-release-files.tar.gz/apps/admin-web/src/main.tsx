import {
  Activity, AlertTriangle, BarChart3, CalendarDays, CheckCircle2, CircleAlert, Database,
  Film, FileVideo, Gauge, Image, LayoutDashboard, ListVideo, LogIn, Megaphone, MoreHorizontal, Plus,
  Pencil, RefreshCw, Save, Settings2, Trash2, Upload, Users, Wifi
} from 'lucide-react';
import { createRoot } from 'react-dom/client';
import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { defaultEpisodeTitle, episodeNoFromName, nextEpisodeNo, renumberEpisodes, resolveAppendEpisodes } from './episode-draft';
import { uploadMultipart, UploadRequestError, type UploadProgress } from './upload-request';
import { DramaMaterials } from './drama-materials';
import { AlbumMetadataDialog, type EditableAlbumMetadata } from './album-metadata-dialog';
import { Metric, Status, Panel } from './dashboard-ui';
import { createAdminApi } from './admin-api';
import { HealthPanel, type Health } from './health-panel';
import { AudiencePage, PlaybackPage, type Audience, type Playback } from './analytics-pages';
import './styles.css';

const miniAppNames = { main: 'QuicK ReeLS', taletv: 'TaleTV', cinereels: 'CineReels', talereels: 'TaleReels', storyland: 'StoryLand', dramacloud: 'DramaCloud', dailyreel: 'DailyReel', dramaone: 'DramaOne', dramaup: 'DramaUp', dramavault: 'DramaVault', talehub: 'TaleHub', talebox: 'TaleBox', storyworld: 'StoryWorld', storyhub: 'StoryHub', dramaroom: 'DramaRoom', dramazone: 'DramaZone', taleflick: 'TaleFlick', dramashort: 'DramaShort', storyshort: 'StoryShort', storyflicks: 'StoryFlicks', dramaflicks: 'DramaFlicks', crownrush: 'CrownRush', sugarreel: 'SugarReel', crimsonshorts: 'CrimsonShorts', sweetreel: 'SweetReel', dramablaze: 'DramaBlaze', heartreel: 'HeartReel', dramahit: 'DramaHit', crownreel: 'CrownReel', luxereel: 'LuxeReel', elitedrama: 'EliteDrama', lucidreel: 'LucidReel', astraclip: 'AstraClip', lumoreel: 'LumoReel', orbitplay: 'OrbitPlay', zenclip: 'ZenClip', auraclip: 'AuraClip', fluxplay: 'FluxPlay', driftreel: 'DriftReel', novaclip: 'NovaClip', lumishort: 'LumiShort' } as const;
type MiniApp = keyof typeof miniAppNames;
const miniAppOrganizations = [
  { id: 'quickreels', label: 'Quick Reels 组织', apps: ['main'] },
  { id: 'taletv', label: 'TaleTV / StoryLand 组织', apps: ['storyland', 'dramacloud', 'dailyreel', 'dramaone', 'dramaup', 'dramavault', 'talehub', 'talebox', 'storyworld', 'storyhub', 'dramaroom', 'dramazone', 'taleflick', 'dramashort', 'storyshort', 'storyflicks', 'dramaflicks', 'cinereels', 'taletv', 'talereels'] },
  { id: 'crownrush', label: 'CrownRush 组织', apps: ['crownrush', 'sugarreel', 'crimsonshorts', 'sweetreel', 'dramablaze', 'heartreel', 'dramahit', 'crownreel', 'luxereel', 'elitedrama'] },
  { id: 'newbeat', label: 'NEWBEAT DIGITAL MARKETING LIMITED', apps: ['lucidreel', 'astraclip', 'lumoreel', 'orbitplay', 'zenclip', 'auraclip', 'fluxplay', 'driftreel', 'novaclip', 'lumishort'] }
] as const satisfies ReadonlyArray<{ id: string; label: string; apps: readonly MiniApp[] }>;
const miniAppOrganization = (app: MiniApp) => miniAppOrganizations.find((group) => (group.apps as readonly string[]).includes(app))!;
const miniAppPaths = Object.fromEntries(Object.keys(miniAppNames).filter((key) => key !== 'main').map((key) => [key, key])) as Record<Exclude<MiniApp, 'main'>, string>;
const miniAppEnvPrefixes = Object.fromEntries(Object.keys(miniAppNames).filter((key) => key !== 'main').map((key) => [key, key.toUpperCase()])) as Record<Exclude<MiniApp, 'main'>, string>;
if (localStorage.getItem('quickreels_active_app') === 'xu03') localStorage.setItem('quickreels_active_app', 'taletv');
for (const suffix of ['content_draft', 'content_templates']) {
  const oldKey = `quickreels_xu03_${suffix}`;
  const nextKey = `quickreels_taletv_${suffix}`;
  const saved = localStorage.getItem(oldKey);
  if (saved !== null) {
    if (localStorage.getItem(nextKey) === null) localStorage.setItem(nextKey, saved);
    localStorage.removeItem(oldKey);
  }
}
sessionStorage.removeItem('quickreels_xu03_admin_token');
const savedApp = localStorage.getItem('quickreels_active_app');
const initialApp: MiniApp = savedApp && savedApp in miniAppNames ? savedApp as MiniApp : 'main';
const primaryApi = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:3000/api/v1';
const env = import.meta.env as Record<string, string | undefined>;
function createAdminWorkspace(activeApp: MiniApp, onSelect: (value: MiniApp) => void) {
const appPrefix = activeApp === 'main' ? '' : miniAppEnvPrefixes[activeApp];
const API = activeApp === 'main'
  ? primaryApi
  : env[`VITE_${appPrefix}_API_BASE_URL`] || new URL(`/api/${miniAppPaths[activeApp]}/v1`, primaryApi).toString().replace(/\/$/, '');
const adminTokenStorageKey = activeApp === 'main' ? 'quickreels_admin_token' : `quickreels_${activeApp}_admin_token`;
function releaseAuthorizationHeaders(targets: MiniApp[]) {
  const tokens = Object.fromEntries(targets.filter((key) => key !== activeApp).flatMap((key) => {
    const token = sessionStorage.getItem(key === 'main' ? 'quickreels_admin_token' : `quickreels_${key}_admin_token`);
    return token ? [[key, token]] : [];
  }));
  const headers: Record<string, string> = {};
  if (Object.keys(tokens).length) headers['X-Multi-App-Tokens'] = JSON.stringify(tokens);
  return headers;
}
const defaultPlacementId = activeApp === 'main' ? env.VITE_REWARDED_PLACEMENT_ID ?? 'ad7686459794040702993' : env[`VITE_${appPrefix}_REWARDED_PLACEMENT_ID`] ?? '';
let workspaceBusy = false;
function selectMiniApp(value: MiniApp) {
  if (value === activeApp || workspaceBusy) return;
  localStorage.setItem('quickreels_active_app', value);
  onSelect(value);
}
function MiniAppSelect() {
	return <label className="mini-app-select">当前小程序<select value={activeApp} onChange={(event) => selectMiniApp(event.target.value as MiniApp)}>{miniAppOrganizations.map((group) => <optgroup key={group.id} label={group.label}>{group.apps.map((key) => <option key={key} value={key}>{miniAppNames[key]}</option>)}</optgroup>)}</select></label>;
}
let adminSessionRecoveryStarted = false;

type Album = {
  id: string;
  title: string;
  description?: string;
  language?: string;
  status: string;
  episodeCount: number;
  coverUrl?: string;
  coverAssetId?: string | null;
  tiktokAlbumId?: string | null;
  tiktokVersion?: number | null;
  onlineVersion?: number | null;
  platformPublishedVersion?: number | null;
  reviewStatus?: string | null;
  publishStatus?: string | null;
  sharedPlayback?: boolean;
  accessConfig?: { freeEpisodeCount?: number; rewardedAdEnabled?: boolean; rewardedPlacementId?: string; rewardedAdCount?: number } | null;
};
function platformNextStep(album: Album) {
  if (!album.tiktokVersion) return '尚无 TikTok 版本，送审暂不可用。请先完成“同步版本”；若上次结果未知，先“对账”再重试同步版本。';
  if (album.onlineVersion && album.tiktokVersion > album.onlineVersion && (album.reviewStatus === 'REVIEWING' || album.reviewStatus === '1')) return '线上旧版本继续服务，新版本审核中；稍后对账。';
  if (album.reviewStatus === 'PASSED' || album.reviewStatus === '2') {
    if (album.onlineVersion !== album.tiktokVersion) return '新版本审核已通过，设置线上版本并对账。';
    if (album.publishStatus !== 'LISTED' && album.publishStatus !== '1') return '线上版本已设置，可以上架。';
    if (album.platformPublishedVersion !== album.onlineVersion) return '线上版本已切换，请对账确认新分集。';
    return '已上架，请在小程序测试播放与广告解锁。';
  }
  if (album.reviewStatus === 'REVIEWING' || album.reviewStatus === '1') return '当前版本审核中，送审优先级不能再修改。点击“对账”查看结果；如需催审，请联系 TikTok 平台支持。';
  return '确认版本同步成功后送审；如已送审，先点“对账”确认审核结果。';
}
type EpisodeOption = { id: string; albumId: string; episodeNo: number; title: string; sortOrder: number; status: string; byteplusVid?: string | null; album: { title: string; status: string } };
type CoverAsset = { id: string; publicUrl: string; status: string; width?: number | null; height?: number | null };
type DraftEpisode = { localId: string; episodeNo: number; title: string; sortOrder: number; isFree: boolean; file?: File | null; byteplusVid?: string; coverFile?: File | null; coverAsset?: CoverAsset | null; coverPreviewUrl?: string; savedEpisodeId?: string; uploadStatus?: string; uploadError?: string };
type BatchDramaDraft = { id: string; title: string; description: string; releaseYear: number; dramaType: number; tagList: string; coverFile: File; freeCount: number; rewardedEnabled: boolean; placementId: string; rewardedCount: number; episodes: DraftEpisode[]; albumId?: string; status: '待创建' | '处理中' | '已完成' | '失败'; error?: string };
type UploadJob = { id: string; episodeId: string; sourceType?: string; sourceName?: string | null; status: string; localFilePath?: string | null; uploadScope?: string | null; providerJobId?: string | null; errorMessage?: string | null; createdAt: string; startedAt?: string | null; completedAt?: string | null; leaseExpiresAt?: string | null; nextAttemptAt?: string | null; episode?: { title: string; episodeNo: number } };
type VodMedia = { vid: string; title: string; coverUrl?: string; durationMs?: number; createTime?: string };
type PlatformEpisodeFailure = { episode_id?: string; seq?: number; title?: string; exception_reason?: string; review_status?: string; review_result?: Record<string, unknown> };
type PlatformProviderResponse = {
  version?: number;
  checked_version?: number;
  current_version?: number;
  online_version?: number;
  review_status?: string | number | null;
  online_review_status?: string | number | null;
  publish_status?: string | number | null;
  review_fail_reasons?: string[];
  online_review_fail_reasons?: string[];
  episode_failures?: PlatformEpisodeFailure[];
  online_episode_failures?: PlatformEpisodeFailure[];
  episode_info_list?: PlatformEpisodeFailure[];
  repaired_episode_ids?: number;
  review_id?: string;
  status?: string | number;
};
type PlatformSyncJob = { id: string; albumId?: string | null; kind: string; status: string; errorMessage?: string | null; providerJobId?: string | null; providerRequestId?: string | null; createdAt: string; completedAt?: string | null; attemptCount?: number; snapshotJson?: { priorityScore?: number; version?: number; uploadMode?: string } | null; providerResponse?: PlatformProviderResponse | null; album?: { title: string } | null; episode?: { title: string; episodeNo?: number } | null };
type PlatformSubmission = { id: string; albumTitle: string; action: string; message: string; failed: boolean; createdAt: string };
type SharedPlaybackOperation = { id: string; kind: string; status: string; createdAt: string; completedAt?: string | null; providerRequestId?: string | null; errorMessage?: string | null; providerResponse?: { platformAuthorized?: boolean; mappedEpisodeCount?: number; onlineVersion?: number; online_review_status?: number; publish_status?: number } | null };
type SharedPlaybackStatus = { miniAppKey: MiniApp; status: string; albumId?: string; tiktokAlbumId?: string; onlineVersion?: number; reviewStatus?: string; publishStatus?: string; localStatus?: string; episodeCount?: number; mappedEpisodeCount?: number; error?: string; requestId?: string; lastReconciledAt?: string; operations?: SharedPlaybackOperation[] };
type SharedPlaybackAction = 'AUTHORIZE' | 'RECONCILE';
type ContentTemplate = { id: string; name: string; dramaType: number; tagList: string; freeCount: number; rewardedEnabled: boolean; placementId: string; rewardedCount: number };
const platformJobLabels: Record<string, string> = { COVER: '同步封面', VIDEO: '同步视频', ALBUM_VERSION: '同步版本', REVIEW: '送审', RECONCILE: '对账', SET_ONLINE_VERSION: '设线上版本', PUBLISH: '上架', UNPUBLISH: '下架' };

function reviewResultLabel(value: string | number | null | undefined) {
  if (value === 1 || value === '1' || value === 'REVIEWING') return '审核中';
  if (value === 2 || value === '2' || value === 'PASSED' || value === 'APPROVED') return '审核通过';
  if (value === 3 || value === '3' || value === 'REJECTED') return '审核失败 / 驳回';
  if (value === 4 || value === '4' || value === 'WITHDRAWN') return '已撤回';
  if (value === 5 || value === '5' || value === 'APPEALING') return '申诉中';
  if (value === 6 || value === '6' || value === 'APPEAL_PASSED') return '申诉通过';
  if (value === 7 || value === '7' || value === 'APPEAL_REJECTED') return '申诉驳回';
  return value === 0 || value === '0' ? '未送审' : value ? String(value) : '未返回审核状态';
}

function publishResultLabel(value: string | number | null | undefined) {
  if (value === 1 || value === '1' || value === 'LISTED' || value === 'PUBLISHED') return '已上架';
  if (value === 2 || value === '2' || value === 'UNLISTED') return '已下架';
  return '未上架';
}

function platformBusinessResult(job: PlatformSyncJob) {
  if (job.status === 'FAILED') return '任务失败，平台结果未确认';
  if (job.status === 'CONFLICT') return '平台结果未知，请先对账';
  if (job.status !== 'SUCCEEDED') return '等待平台处理';
  const result = job.providerResponse;
  if (!result) return '平台未返回业务结果';
  if (job.kind === 'REVIEW') return `送审已受理 · ${reviewResultLabel(result.review_status ?? 1)}`;
  if (job.kind === 'RECONCILE') return `审核：${reviewResultLabel(result.review_status)} · 上架：${publishResultLabel(result.publish_status)}`;
  if (job.kind === 'ALBUM_VERSION') return result.version ? `平台版本 ${result.version} 已生成` : '版本结果未返回';
  if (job.kind === 'VIDEO') return 'TikTok 媒资登记已完成';
  if (job.kind === 'SET_ONLINE_VERSION') return result.online_version ? `线上版本 ${result.online_version} 已设置` : '线上版本设置已完成';
  if (job.kind === 'PUBLISH') return '平台已上架';
  if (job.kind === 'UNPUBLISH') return '平台已下架';
  return '平台操作已完成';
}

function platformBusinessDetails(job: PlatformSyncJob) {
  const result = job.providerResponse;
  const details: string[] = [];
  if (result && job.status === 'SUCCEEDED') {
    const version = result.checked_version ?? result.version ?? job.snapshotJson?.version;
    if (version) details.push(`检查版本：${version}${result.online_version ? ` · 线上版本：${result.online_version}` : ''}`);
    if (result.repaired_episode_ids) details.push(`已恢复 ${result.repaired_episode_ids} 个 TikTok 分集 ID`);
    const reasons = [...(result.review_fail_reasons ?? []), ...(result.online_review_fail_reasons ?? [])].filter((reason, index, items) => reason && items.indexOf(reason) === index);
    if (reasons.length) details.push(`审核原因：${reasons.join('；')}`);
    const episodeFailures = result.episode_failures?.length ? result.episode_failures : (result.episode_info_list ?? []).filter((episode) => episode.exception_reason || [3, '3', 7, '7'].includes(episode.review_result?.overall_review_status as string));
    for (const [source, failure] of [...episodeFailures.map((item) => ['当前版本', item] as const), ...(result.online_episode_failures ?? []).map((item) => ['线上版本', item] as const)]) {
      const episode = failure.seq ? `第 ${failure.seq} 集` : failure.title ?? failure.episode_id ?? '分集';
      const reviewStatus = failure.review_status ?? failure.review_result?.overall_review_status;
      const reason = failure.exception_reason ?? (reviewStatus != null ? `审核状态：${reviewResultLabel(reviewStatus as string | number)}` : '平台返回分集异常');
      details.push(`${source} ${episode}：${reason}`);
    }
  }
  if (job.errorMessage) details.push(`任务错误：${job.errorMessage}`);
  if (job.providerJobId) details.push(`TikTok 上传任务 ID：${job.providerJobId}`);
  if (job.providerRequestId) details.push(`TikTok 请求 ID：${job.providerRequestId}`);
  return details;
}
type Overview = { albums: number; episodes: number; users: number; likes: number; favorites: number; shares: number; searches: number; rewardedUnlocks: number; updatedAt?: string };
type AppEntryAdPolicy = { releaseId: string; enabled: boolean; mode: 'INTERSTITIAL' | 'REWARDED_GATED'; placementId: string; requiredCount: number; countMode: 'COMPLETED' | 'SHOWN'; onUnavailable: 'ALLOW' | 'BLOCK'; version: number };
type PortalStatus = 'UNKNOWN' | 'PREVIEW' | 'IN_REVIEW' | 'READY' | 'RELEASED';
type AppEntryAdRelease = AppEntryAdPolicy & { portalVersion: string | null; portalStatus: PortalStatus; firstSeenAt?: string | null; lastSeenAt?: string | null };
type AppEntryAdPolicyList = { items: AppEntryAdRelease[]; placementDefaults: { INTERSTITIAL: string; REWARDED_GATED: string } };
const portalStatusLabels: Record<PortalStatus, string> = { UNKNOWN: '未核实', PREVIEW: 'Preview', IN_REVIEW: 'In review', READY: 'Ready for release', RELEASED: 'Released' };
type AdminRole = 'OWNER' | 'EDITOR' | 'ANALYST' | 'SUPPORT';
type AdminPermission = 'content.write' | 'content.sync' | 'content.review' | 'content.publish' | 'ads.write';
type AdminProfile = { id: string; email: string; role: AdminRole; status: string; lastLoginAt?: string | null; passwordChangedAt?: string | null };
type Tab = 'overview' | 'create' | 'albums' | 'ads' | 'audience' | 'playback' | 'security';
type ResourceKey = 'admin' | 'overview' | 'health' | 'recentJobs' | 'jobs' | 'albums' | 'episodes' | 'platformJobs' | 'ads' | 'audience' | 'playback';
type ResourceStatus = { loading: boolean; loaded: boolean; error: string | null };
const tabResources: Record<Tab, ResourceKey[]> = {
  overview: ['overview', 'health', 'recentJobs'], create: ['albums', 'episodes', 'jobs'],
  albums: ['albums', 'platformJobs'], ads: ['ads'],
  audience: ['audience'], playback: ['playback'], security: ['admin']
};
const contentDraftStorageKey = activeApp === 'main' ? 'quickreels_content_draft' : `quickreels_${activeApp}_content_draft`;
const contentTemplateStorageKey = activeApp === 'main' ? 'quickreels_content_templates' : `quickreels_${activeApp}_content_templates`;
const platformSubmissionStorageKey = activeApp === 'main' ? 'quickreels_platform_submissions' : `quickreels_${activeApp}_platform_submissions`;
const entryAdReleaseStorageKey = `quickreels_${activeApp}_entry_ad_release`;

const rolePermissions: Record<AdminRole, readonly AdminPermission[]> = {
  OWNER: ['content.write', 'content.sync', 'content.review', 'content.publish', 'ads.write'],
  EDITOR: ['content.write', 'content.sync', 'ads.write'],
  ANALYST: [],
  SUPPORT: []
};

function hasAdminPermission(role: AdminRole | undefined, permission: AdminPermission) {
  return role ? rolePermissions[role].includes(permission) : false;
}

function inputDate(value: Date) {
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, '0');
  const day = String(value.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function rangeStart(days: number) {
  const value = new Date();
  value.setDate(value.getDate() - days + 1);
  return inputDate(value);
}

const api = createAdminApi(API, adminTokenStorageKey, platformSubmissionStorageKey, () => onSelect(activeApp));

function Login({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  async function submit(event: FormEvent) {
    event.preventDefault();
    setError('');
    try {
      const result = await api<{ accessToken: string }>('/admin/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      sessionStorage.setItem(adminTokenStorageKey, result.accessToken);
      onLogin();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '登录失败');
    }
  }
  return <main className="login-shell"><form className="login-panel" onSubmit={submit}><div className="brand"><span><Film size={17} /></span>QuicK <span>ReeLS</span></div><p className="eyebrow">运营管理后台</p><h1>登录内容中心</h1><p className="subhead">管理剧集、广告解锁和首页展示配置。</p><MiniAppSelect /><label>管理员邮箱<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required /></label><label>密码<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required /></label>{error && <p className="form-error">{error}</p>}<button className="primary" type="submit"><LogIn size={17} />登录</button></form></main>;
}




type DraftUploadProgress = UploadProgress | { phase: 'server-stored' };

function UploadMeter({ episodeNo, progress }: { episodeNo: number; progress: DraftUploadProgress }) {
  const percent = progress.phase === 'sending' ? progress.percent : progress.phase === 'server-stored' ? 100 : undefined;
  const label = progress.phase === 'sending' ? `传至服务器 ${percent}%` : progress.phase === 'processing' ? 'BytePlus 处理中' : '服务器已收文件，等待 BytePlus VID';
  return <div className="upload-meter-wrap">
    <div className={`upload-meter ${progress.phase}`} role="progressbar" aria-label={`第 ${episodeNo} 集上传进度`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent} aria-valuetext={label}>
      <span style={percent === undefined ? undefined : { width: `${percent}%` }} />
    </div>
    <small>{label}</small>
  </div>;
}


function AdminApp() {
  const [loggedIn, setLoggedIn] = useState(Boolean(sessionStorage.getItem(adminTokenStorageKey)));
  const [tab, setTab] = useState<Tab>('overview');
  const [albums, setAlbums] = useState<Album[]>([]);
  const [episodes, setEpisodes] = useState<EpisodeOption[]>([]);
  const [currentAdmin, setCurrentAdmin] = useState<AdminProfile | null>(null);
  const [jobs, setJobs] = useState<UploadJob[]>([]);
  const [recentJobs, setRecentJobs] = useState<UploadJob[]>([]);
  const [platformJobs, setPlatformJobs] = useState<PlatformSyncJob[]>([]);
  const [platformSubmissions, setPlatformSubmissions] = useState<PlatformSubmission[]>(() => {
    try { const saved = JSON.parse(sessionStorage.getItem(platformSubmissionStorageKey) ?? '[]'); return Array.isArray(saved) ? saved.slice(0, 10) : []; } catch { return []; }
  });
  const [releaseAlbumId, setReleaseAlbumId] = useState('');
  const [releaseTargets, setReleaseTargets] = useState<MiniApp[]>([]);
  const [releaseStatuses, setReleaseStatuses] = useState<SharedPlaybackStatus[]>([]);
  const playbackStatusRequest = useRef(0);
  const resourceControllers = useRef<Partial<Record<ResourceKey, AbortController>>>({});
  const [resourceStatus, setResourceStatus] = useState<Partial<Record<ResourceKey, ResourceStatus>>>({});
  const materialSelectionRequest = useRef(0);
  const [materialSelection, setMaterialSelection] = useState<{ albumId: string; request: number } | null>(null);
  const [releaseActionErrors, setReleaseActionErrors] = useState<Partial<Record<MiniApp, string>>>({});
  const [releaseWorking, setReleaseWorking] = useState<SharedPlaybackAction | null>(null);
  const [releaseError, setReleaseError] = useState('');
  const [overview, setOverview] = useState<Overview | null>(null);
  const [health, setHealth] = useState<Health | null>(null);
  const [healthMinutes, setHealthMinutes] = useState(30);
  const [audience, setAudience] = useState<Audience | null>(null);
  const [playback, setPlayback] = useState<Playback | null>(null);
  const [entryAdReleaseId, setEntryAdReleaseId] = useState(() => localStorage.getItem(entryAdReleaseStorageKey) ?? 'default');
  const [entryAdVersions, setEntryAdVersions] = useState<AppEntryAdPolicyList['items']>([]);
  const [savingEntryAdRelease, setSavingEntryAdRelease] = useState(false);
  const [entryAdPlacementDefaults, setEntryAdPlacementDefaults] = useState<AppEntryAdPolicyList['placementDefaults']>({ INTERSTITIAL: '', REWARDED_GATED: '' });
  const [entryAdPolicy, setEntryAdPolicy] = useState<AppEntryAdPolicy>({ releaseId: 'default', enabled: false, mode: 'INTERSTITIAL', placementId: '', requiredCount: 1, countMode: 'COMPLETED', onUnavailable: 'ALLOW', version: 1 });
  const [analyticsFrom, setAnalyticsFrom] = useState(() => rangeStart(30));
  const [analyticsTo, setAnalyticsTo] = useState(() => inputDate(new Date()));
  const [analyticsTimezone, setAnalyticsTimezone] = useState('Asia/Shanghai');
  const [createTitle, setCreateTitle] = useState('');
  const [createDescription, setCreateDescription] = useState('');
  const [createReleaseYear, setCreateReleaseYear] = useState(new Date().getFullYear());
  const [createDramaType, setCreateDramaType] = useState(2);
  const [createTagList, setCreateTagList] = useState('1');
  const [createCoverFile, setCreateCoverFile] = useState<File | null>(null);
  const [createCover, setCreateCover] = useState<CoverAsset | null>(null);
  const [createCoverPreviewUrl, setCreateCoverPreviewUrl] = useState('');
  const [createFreeCount, setCreateFreeCount] = useState(3);
  const [createRewardedEnabled, setCreateRewardedEnabled] = useState(Boolean(defaultPlacementId));
  const [createPlacementId, setCreatePlacementId] = useState(defaultPlacementId);
  const [createRewardedCount, setCreateRewardedCount] = useState(1);
  const [createMode, setCreateMode] = useState<'new' | 'append'>('new');
  const [targetAlbumId, setTargetAlbumId] = useState('');
  const [createdAlbumId, setCreatedAlbumId] = useState('');
  const [templates, setTemplates] = useState<ContentTemplate[]>(() => {
    try { const saved = JSON.parse(localStorage.getItem(contentTemplateStorageKey) ?? '[]'); return Array.isArray(saved) ? saved : []; } catch { return []; }
  });
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [draftEpisodes, setDraftEpisodes] = useState<DraftEpisode[]>(() => Array.from({ length: 3 }, (_, index) => ({ localId: `draft-${index + 1}`, episodeNo: index + 1, title: `第 ${index + 1} 集`, sortOrder: index + 1, isFree: false })));
  const [batchDramas, setBatchDramas] = useState<BatchDramaDraft[]>([]);
  const [uploadProgress, setUploadProgress] = useState<Record<string, DraftUploadProgress>>({});
  const [creating, setCreating] = useState(false);
  useEffect(() => { workspaceBusy = creating; return () => { workspaceBusy = false; }; }, [creating]);
  const [batchFeedback, setBatchFeedback] = useState('');
  const [draftReady, setDraftReady] = useState(false);
  const [message, setMessage] = useState('');
  const [createError, setCreateError] = useState('');
  const [savingEntryAdPolicy, setSavingEntryAdPolicy] = useState(false);
  const [savingAlbumId, setSavingAlbumId] = useState<string | null>(null);
  const [savingTitleId, setSavingTitleId] = useState<string | null>(null);
  const [titleDrafts, setTitleDrafts] = useState<Record<string, string>>({});
  const [editingAlbumMetadata, setEditingAlbumMetadata] = useState<EditableAlbumMetadata | null>(null);
  const [deletingAlbumId, setDeletingAlbumId] = useState<string | null>(null);
  const [dirtyAccessAlbumIds, setDirtyAccessAlbumIds] = useState<Set<string>>(() => new Set());
  const [retryingJobId, setRetryingJobId] = useState<string | null>(null);
  const [reconcilingJobId, setReconcilingJobId] = useState<string | null>(null);
  const [platformWorking, setPlatformWorking] = useState<string | null>(null);
  const [reviewPriorities, setReviewPriorities] = useState<Record<string, 1 | 2>>({});
  const [changingPassword, setChangingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [vodMedia, setVodMedia] = useState<VodMedia[]>([]);
  const [loadingVodMedia, setLoadingVodMedia] = useState(false);

  const recordPlatformSubmission = (album: Album, action: string, message: string, failed: boolean) => {
    const next = [{ id: `${Date.now()}-${platformSubmissions.length}`, albumTitle: album.title, action, message, failed, createdAt: new Date().toISOString() }, ...platformSubmissions].slice(0, 10);
    sessionStorage.setItem(platformSubmissionStorageKey, JSON.stringify(next));
    setPlatformSubmissions(next);
  };

  const loadResource = async <T,>(key: ResourceKey, request: (signal: AbortSignal) => Promise<T>, apply: (value: T) => void) => {
    resourceControllers.current[key]?.abort();
    const controller = new AbortController();
    resourceControllers.current[key] = controller;
    setResourceStatus((current) => ({ ...current, [key]: { loading: true, loaded: current[key]?.loaded ?? false, error: null } }));
    try {
      const value = await request(controller.signal);
      if (controller.signal.aborted) return;
      apply(value);
      setResourceStatus((current) => ({ ...current, [key]: { loading: false, loaded: true, error: null } }));
    } catch (error) {
      if (controller.signal.aborted) return;
      setResourceStatus((current) => ({ ...current, [key]: { loading: false, loaded: current[key]?.loaded ?? false, error: error instanceof Error ? error.message : '数据加载失败' } }));
    } finally {
      if (resourceControllers.current[key] === controller) delete resourceControllers.current[key];
    }
  };
  const loadAdmin = () => loadResource('admin', (signal) => api<{ admin: AdminProfile }>('/admin/me', { signal }), (result) => setCurrentAdmin(result.admin));
  const loadAlbums = () => loadResource('albums', (signal) => api<{ items: Album[] }>('/admin/albums', { signal }), (result) => setAlbums(result.items));
  const loadEpisodes = () => loadResource('episodes', (signal) => api<{ items: EpisodeOption[] }>('/admin/episodes', { signal }), (result) => setEpisodes(result.items));
  const loadJobs = () => loadResource('jobs', (signal) => api<{ items: UploadJob[] }>('/admin/upload-jobs', { signal }), (result) => setJobs(result.items));
  const loadPlatformJobs = () => loadResource('platformJobs', (signal) => api<{ items: PlatformSyncJob[] }>('/admin/platform-sync-jobs?limit=50', { signal }), (result) => setPlatformJobs(result.items));
  const loadEntryAdPolicy = (releaseId: string) => loadResource('ads', (signal) => api<AppEntryAdPolicy>(`/admin/app-entry-ad-policy?releaseId=${encodeURIComponent(releaseId)}`, { signal }), (policy) => {
    setEntryAdPolicy(policy);
    setEntryAdReleaseId(policy.releaseId);
    localStorage.setItem(entryAdReleaseStorageKey, policy.releaseId);
  });
  const loadEntryAdSettings = () => loadResource('ads', async (signal) => {
    const options = await api<AppEntryAdPolicyList>('/admin/app-entry-ad-policies', { signal });
    const releaseId = options.items.some((item) => item.releaseId === entryAdReleaseId) ? entryAdReleaseId : options.items[0]?.releaseId ?? 'default';
    return { options, policy: options.items.find((item) => item.releaseId === releaseId) };
  }, ({ options, policy }) => {
    setEntryAdVersions(options.items);
    setEntryAdPlacementDefaults(options.placementDefaults);
    if (policy) {
      setEntryAdPolicy(policy);
      setEntryAdReleaseId(policy.releaseId);
      localStorage.setItem(entryAdReleaseStorageKey, policy.releaseId);
    }
  });
  const loadTab = async (target: Tab): Promise<void> => {
    const range = new URLSearchParams({ from: analyticsFrom, to: analyticsTo, timezone: analyticsTimezone });
    switch (target) {
      case 'overview': await Promise.all([
        loadResource('overview', (signal) => api<Overview>('/admin/analytics/overview', { signal }), setOverview),
        loadResource('health', (signal) => api<Health>(`/admin/analytics/health?minutes=${healthMinutes}`, { signal }), setHealth),
        loadResource('recentJobs', (signal) => api<{ items: UploadJob[] }>('/admin/upload-jobs?limit=5', { signal }), (result) => setRecentJobs(result.items))
      ]); return;
      case 'create': await Promise.all([loadAlbums(), loadEpisodes(), loadJobs()]); return;
      case 'albums': await Promise.all([loadAlbums(), loadEpisodes(), loadPlatformJobs()]); return;
      case 'ads': await loadEntryAdSettings(); return;
      case 'audience': await loadResource('audience', (signal) => api<Audience>(`/admin/analytics/audience?${range}`, { signal }), setAudience); return;
      case 'playback': await loadResource('playback', (signal) => api<Playback>(`/admin/analytics/playback-quality?${range}`, { signal }), setPlayback); return;
      case 'security': await loadAdmin(); return;
    }
  };
  const loading = tabResources[tab].some((key) => resourceStatus[key]?.loading);
  const loadVodMedia = async () => {
    setLoadingVodMedia(true);
    try {
      const result = await api<{ items: VodMedia[] }>('/admin/byteplus/media?offset=0&pageSize=100');
      setVodMedia(result.items);
      setMessage(`已读取当前小程序 ${result.items.length} 条媒资。`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '读取 BytePlus 空间媒资失败');
    } finally {
      setLoadingVodMedia(false);
    }
  };

  const loadReleaseStatuses = async () => {
    const request = ++playbackStatusRequest.current;
    if (!releaseAlbumId || !releaseTargets.length) { setReleaseStatuses([]); return; }
    try {
      const query = new URLSearchParams({ targetApps: releaseTargets.join(',') });
      const result = await api<{ items: SharedPlaybackStatus[] }>(`/admin/shared-playback/${releaseAlbumId}?${query}`, { headers: releaseAuthorizationHeaders(releaseTargets) });
      if (request !== playbackStatusRequest.current) return;
      setReleaseStatuses(result.items);
      setReleaseError('');
    } catch (error) {
      if (request !== playbackStatusRequest.current) return;
      setReleaseError(error instanceof Error ? error.message : '读取授权状态失败');
    }
  };

  const runReleaseAction = async (action: SharedPlaybackAction) => {
    if (!releaseAlbumId || !releaseTargets.length) return;
    if (action === 'AUTHORIZE' && !window.confirm(`将当前已审核并上架的主剧目授权给 ${releaseTargets.map((key) => miniAppNames[key]).join('、')} 播放，共用平台剧目和视频，确定继续？`)) return;
    setReleaseWorking(action);
    try {
      const result = await api<{ items: Array<{ miniAppKey: MiniApp; accepted: boolean; error?: string }> }>(`/admin/shared-playback/${releaseAlbumId}`, {
        method: 'POST', headers: releaseAuthorizationHeaders(releaseTargets), body: JSON.stringify({ targetApps: releaseTargets, action })
      });
      setReleaseActionErrors(Object.fromEntries(result.items.filter((item) => !item.accepted).map((item) => [item.miniAppKey, item.error ?? '未受理'])));
      await loadReleaseStatuses();
      const failed = result.items.filter((item) => !item.accepted);
      setMessage(failed.length
        ? `已接受 ${result.items.length - failed.length} 个目标；${failed.map((item) => `${miniAppNames[item.miniAppKey]}：${item.error}`).join('；')}`
        : '授权播放操作已接受，正在等待平台授权和本地分集映射结果。');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '授权操作失败');
    } finally {
      setReleaseWorking(null);
    }
  };

  useEffect(() => {
    if (!loggedIn) return;
    void loadAdmin();
    return () => { resourceControllers.current.admin?.abort(); };
  }, [loggedIn]);
  useEffect(() => {
    if (!loggedIn) return;
    if (tab === 'audience') setAudience(null);
    if (tab === 'playback') setPlayback(null);
    void loadTab(tab);
    return () => { for (const key of tabResources[tab]) resourceControllers.current[key]?.abort(); };
  }, [loggedIn, tab, analyticsFrom, analyticsTo, analyticsTimezone]);
  useEffect(() => {
    if (!loggedIn || tab !== 'overview') return;
    const refresh = () => { if (document.visibilityState === 'visible' && !resourceControllers.current.health) void loadResource('health', (signal) => api<Health>(`/admin/analytics/health?minutes=${healthMinutes}`, { signal }), setHealth); };
    refresh();
    const timer = window.setInterval(refresh, 30_000);
    return () => { window.clearInterval(timer); resourceControllers.current.health?.abort(); };
  }, [loggedIn, tab, healthMinutes]);
  const activeUploads = jobs.some((job) => ['PENDING', 'PROCESSING'].includes(job.status));
  useEffect(() => {
    if (!loggedIn || tab !== 'create' || !activeUploads) return;
    let polling = false;
    const timer = window.setInterval(() => {
      if (polling || resourceStatus.jobs?.loading || document.visibilityState !== 'visible') return;
      polling = true;
      void Promise.all([loadJobs(), loadEpisodes()]).finally(() => { polling = false; });
    }, 5_000);
    return () => { window.clearInterval(timer); };
  }, [loggedIn, tab, activeUploads, resourceStatus.jobs?.loading]);
  useEffect(() => {
    setDraftEpisodes((items) => items.map((draft) => {
      if (!draft.savedEpisodeId || draft.uploadStatus === '上传中') return draft;
      const job = jobs.find((item) => item.episodeId === draft.savedEpisodeId);
      if (!job) return draft;
      return { ...draft, uploadStatus: job.status === 'SUCCEEDED' ? '已上传' : job.status === 'FAILED' ? '上传失败' : job.status === 'PENDING' ? '待传至 BytePlus' : 'BytePlus 处理中', uploadError: job.errorMessage ?? undefined };
    }));
  }, [jobs]);
  useEffect(() => {
    if (!loggedIn || tab !== 'albums' || !releaseAlbumId || !releaseTargets.length) return;
    let polling = false;
    const poll = () => {
      if (polling || resourceStatus.platformJobs?.loading || document.visibilityState !== 'visible') return;
      polling = true;
      void loadReleaseStatuses().finally(() => { polling = false; });
    };
    poll();
    const timer = window.setInterval(poll, 10_000);
    return () => { window.clearInterval(timer); playbackStatusRequest.current += 1; };
  }, [loggedIn, tab, releaseAlbumId, releaseTargets.join(',')]);
  useEffect(() => {
    if (!draftReady || createdAlbumId || targetAlbumId || !episodes.length) return;
    const saved = draftEpisodes.find((episode) => episode.savedEpisodeId);
    if (!saved) return;
    const albumId = episodes.find((episode) => episode.id === saved.savedEpisodeId)?.albumId;
    if (albumId) {
      setCreateMode('append');
      setTargetAlbumId(albumId);
      setMessage('已识别旧版草稿所属剧集，后续新增分集将追加到该剧集。');
    }
  }, [draftReady, createdAlbumId, targetAlbumId, episodes, draftEpisodes]);
  useEffect(() => {
    if (!draftReady || createMode !== 'append' || !targetAlbumId || !episodes.length) return;
    const existing = episodes.filter((episode) => episode.albumId === targetAlbumId);
    if (!existing.length) return;
    setDraftEpisodes((current) => {
      const resolved = resolveAppendEpisodes(current, existing);
      if (resolved.some((draft, index) => draft !== current[index])) return resolved;
      if (current.length !== 1 || current[0].file || current[0].savedEpisodeId) return current;
      if (!existing.some((episode) => episode.episodeNo === current[0].episodeNo && episode.byteplusVid)) return current;
      const episodeNo = Math.max(...existing.map((episode) => episode.episodeNo)) + 1;
      const sortOrder = Math.max(...existing.map((episode) => episode.sortOrder)) + 1;
      return [{ localId: `draft-${Date.now()}`, episodeNo, title: defaultEpisodeTitle(episodeNo), sortOrder, isFree: false }];
    });
  }, [draftReady, createMode, targetAlbumId, episodes]);
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(contentDraftStorageKey) ?? 'null') as { title?: string; description?: string; releaseYear?: number; dramaType?: number; tagList?: string; cover?: CoverAsset | null; freeCount?: number; rewardedEnabled?: boolean; placementId?: string; rewardedCount?: number; episodes?: DraftEpisode[]; mode?: 'new' | 'append'; targetAlbumId?: string; createdAlbumId?: string } | null;
      if (saved) {
        setCreateMode(saved.mode === 'append' ? 'append' : 'new');
        setTargetAlbumId(saved.targetAlbumId ?? '');
        setCreatedAlbumId(saved.createdAlbumId ?? '');
        setCreateTitle(saved.title ?? '');
        setCreateDescription(saved.description ?? '');
        setCreateReleaseYear(saved.releaseYear ?? new Date().getFullYear());
        setCreateDramaType(saved.dramaType ?? 2);
        setCreateTagList(saved.tagList ?? '1');
        setCreateCover(saved.cover ?? null);
        setCreateFreeCount(saved.freeCount ?? 3);
        setCreateRewardedEnabled(saved.rewardedEnabled ?? true);
        setCreatePlacementId(saved.placementId ?? defaultPlacementId);
        setCreateRewardedCount(saved.rewardedCount ?? 1);
        if (saved.episodes?.length) setDraftEpisodes(saved.episodes.map((episode) => ({
          ...episode, file: null, coverFile: null, coverPreviewUrl: '',
          ...(episode.uploadStatus === '上传中' ? { uploadStatus: '待确认', uploadError: '上传页面曾中断，正在查询服务器任务。' } : {})
        })));
        setMessage('已恢复本地草稿；本地文件需重新选择后再上传。');
      }
    } catch {
      localStorage.removeItem(contentDraftStorageKey);
    } finally {
      setDraftReady(true);
    }
  }, []);
  useEffect(() => {
    if (!draftReady) return;
    localStorage.setItem(contentDraftStorageKey, JSON.stringify({ title: createTitle, description: createDescription, releaseYear: createReleaseYear, dramaType: createDramaType, tagList: createTagList, cover: createCover, freeCount: createFreeCount, rewardedEnabled: createRewardedEnabled, placementId: createPlacementId, rewardedCount: createRewardedCount, mode: createMode, targetAlbumId, createdAlbumId, episodes: draftEpisodes.map(({ file, coverFile, coverPreviewUrl, ...episode }) => episode) }));
  }, [createTitle, createDescription, createReleaseYear, createDramaType, createTagList, createCover, createFreeCount, createRewardedEnabled, createPlacementId, createRewardedCount, createMode, targetAlbumId, createdAlbumId, draftEpisodes, draftReady]);
  useEffect(() => { localStorage.setItem(contentTemplateStorageKey, JSON.stringify(templates)); }, [templates]);
  if (!loggedIn) return <Login onLogin={() => setLoggedIn(true)} />;

  const resetCreateForm = () => {
    setCreateError('');
    setCreateMode('new');
    setTargetAlbumId('');
    setCreatedAlbumId('');
    setCreateTitle('');
    setCreateDescription('');
    setCreateReleaseYear(new Date().getFullYear());
    setCreateDramaType(2);
    setCreateTagList('1');
    setCreateCoverFile(null);
    setCreateCover(null);
    setCreateCoverPreviewUrl('');
    setCreateFreeCount(3);
    setCreateRewardedEnabled(Boolean(defaultPlacementId));
    setCreatePlacementId(defaultPlacementId);
    setCreateRewardedCount(1);
    setBatchFeedback('');
    setUploadProgress({});
    setSelectedTemplateId('');
    localStorage.removeItem(contentDraftStorageKey);
    setDraftEpisodes(Array.from({ length: 3 }, (_, index) => ({ localId: `draft-${Date.now()}-${index + 1}`, episodeNo: index + 1, title: `第 ${index + 1} 集`, sortOrder: index + 1, isFree: false })));
  };

  const hasActiveContent = () => Boolean(createTitle.trim() || createDescription.trim() || createCoverFile || createCover || createdAlbumId || targetAlbumId || draftEpisodes.some((episode) => episode.file || episode.savedEpisodeId));

  const selectCreateMode = (mode: 'new' | 'append') => {
    if (mode === createMode) return;
    if (hasActiveContent() && !window.confirm('切换模式将清空当前表单；已创建的剧集不会删除。确定继续吗？')) return;
    resetCreateForm();
    setCreateMode(mode);
    if (mode === 'append') setDraftEpisodes([]);
  };

  const selectTargetAlbum = (albumId: string) => {
    if (draftEpisodes.some((episode) => episode.file || episode.savedEpisodeId) && !window.confirm('切换目标剧集将清空当前分集编辑，确定继续吗？')) return;
    setTargetAlbumId(albumId);
    setCreateError('');
    const existing = episodes.filter((episode) => episode.albumId === albumId);
    const episodeNo = Math.max(0, ...existing.map((episode) => episode.episodeNo)) + 1;
    const sortOrder = Math.max(0, ...existing.map((episode) => episode.sortOrder ?? episode.episodeNo)) + 1;
    setDraftEpisodes(albumId ? [{ localId: `draft-${Date.now()}`, episodeNo, title: defaultEpisodeTitle(episodeNo), sortOrder, isFree: false }] : []);
    setMessage(albumId ? `已选择目标剧集，新增分集将从第 ${episodeNo} 集开始。` : '');
  };

  const saveTemplate = () => {
    const name = window.prompt('模板名称')?.trim();
    if (!name) return;
    const template: ContentTemplate = { id: crypto.randomUUID(), name, dramaType: createDramaType, tagList: createTagList, freeCount: createFreeCount, rewardedEnabled: createRewardedEnabled, placementId: createPlacementId, rewardedCount: createRewardedCount };
    setTemplates((current) => [...current.filter((item) => item.name !== name), template]);
    setSelectedTemplateId(template.id);
    setMessage(`模板“${name}”已保存在当前浏览器。`);
  };

  const applyTemplate = () => {
    const template = templates.find((item) => item.id === selectedTemplateId);
    if (!template || createMode !== 'new' || createdAlbumId) return;
    setCreateDramaType(template.dramaType);
    setCreateTagList(template.tagList);
    setCreateFreeCount(template.freeCount);
    setCreateRewardedEnabled(template.rewardedEnabled);
    setCreatePlacementId(template.placementId);
    setCreateRewardedCount(template.rewardedCount);
    setMessage(`已应用模板“${template.name}”。`);
  };

  const uploadCover = async () => {
    if (!createCoverFile) throw new Error('请选择专辑封面');
    const form = new FormData();
    form.append('file', createCoverFile);
    const asset = await api<CoverAsset>('/admin/cover-assets', { method: 'POST', body: form });
    setCreateCover(asset);
    return asset;
  };

  const uploadEpisodeCover = async (draft: DraftEpisode) => {
    if (!draft.coverFile) return draft.coverAsset ?? null;
    const form = new FormData();
    form.append('file', draft.coverFile);
    const asset = await api<CoverAsset>('/admin/cover-assets', { method: 'POST', body: form });
    patchDraftEpisode(draft.localId, { coverAsset: asset });
    return asset;
  };

  const selectAlbumCover = (file: File | null) => {
    setCreateCoverFile(file);
    setCreateCover(null);
    setCreateCoverPreviewUrl(file ? URL.createObjectURL(file) : '');
  };

  const selectEpisodeCover = (draft: DraftEpisode, file: File | null) => {
    patchDraftEpisode(draft.localId, { coverFile: file, coverAsset: null, coverPreviewUrl: file ? URL.createObjectURL(file) : '' });
  };

  const applyEpisodeCount = (count: number) => {
    const safeCount = Math.max(1, Math.min(count, 500));
    setDraftEpisodes((current) => {
      const finalCount = Math.max(safeCount, current.filter((episode) => episode.savedEpisodeId).length);
      const existing = createMode === 'append' ? episodes.filter((episode) => episode.albumId === targetAlbumId) : [];
      const firstNewNo = Math.max(nextEpisodeNo(current), Math.max(0, ...existing.map((episode) => episode.episodeNo)) + 1);
      const firstNewOrder = Math.max(current.at(-1)?.sortOrder ?? 0, ...existing.map((episode) => episode.sortOrder)) + 1;
      return Array.from({ length: finalCount }, (_, index) => {
        if (index < current.length) return current[index];
        const episodeNo = firstNewNo + index - current.length;
        return { localId: `draft-${Date.now()}-${index + 1}`, episodeNo, title: defaultEpisodeTitle(episodeNo), sortOrder: firstNewOrder + index - current.length, isFree: false };
      });
    });
  };

  const patchDraftEpisode = (localId: string, patch: Partial<DraftEpisode>) => setDraftEpisodes((items) => items.map((item) => item.localId === localId ? { ...item, ...patch } : item));
  const setDraftEpisodeNo = (localId: string, episodeNo: number) => setDraftEpisodes((items) => renumberEpisodes(items, localId, episodeNo));

  const applyBatchFiles = (files: FileList | null) => {
    const selected = Array.from(files ?? []);
    if (!selected.length) return;
    const existing = createMode === 'append' ? episodes.filter((episode) => episode.albumId === targetAlbumId) : [];
    const existingByNo = new Map(existing.map((episode) => [episode.episodeNo, episode]));
    const selectedNos = selected.map((file) => episodeNoFromName(file.name));
    const replacePlaceholder = draftEpisodes.length === 1 && !draftEpisodes[0].file && !draftEpisodes[0].savedEpisodeId
      && !selectedNos.includes(draftEpisodes[0].episodeNo)
      && selectedNos.some((number) => number && existingByNo.get(number) && !existingByNo.get(number)?.byteplusVid);
    const next = replacePlaceholder ? [] : [...draftEpisodes];
    const matchedByEpisode = new Map<number, File[]>();
    const unmatchedNames: string[] = [];
    const alreadyUploaded: number[] = [];
    for (const file of selected) {
      const episodeNo = episodeNoFromName(file.name);
      const saved = episodeNo ? existingByNo.get(episodeNo) : undefined;
      if (saved?.byteplusVid) {
        alreadyUploaded.push(episodeNo!);
        continue;
      }
      if (!episodeNo || (!next.some((episode) => episode.episodeNo === episodeNo) && !saved)) {
        unmatchedNames.push(file.name);
        continue;
      }
      const matches = matchedByEpisode.get(episodeNo) ?? [];
      matches.push(file);
      matchedByEpisode.set(episodeNo, matches);
    }
    const duplicateEpisodeNos = [...matchedByEpisode.entries()].filter(([, matches]) => matches.length > 1).map(([episodeNo]) => episodeNo);
    for (const [episodeNo, matches] of matchedByEpisode) {
      if (matches.length !== 1) continue;
      const index = next.findIndex((episode) => episode.episodeNo === episodeNo);
      if (index >= 0) {
        next[index] = { ...next[index], file: matches[0], uploadError: undefined };
      } else {
        const saved = existingByNo.get(episodeNo)!;
        next.push({ localId: `draft-${Date.now()}-${episodeNo}`, episodeNo, title: saved.title,
          sortOrder: saved.sortOrder, isFree: false, savedEpisodeId: saved.id, file: matches[0] });
      }
    }
    const missingEpisodeNos = next.filter((episode) => !episode.file && episode.uploadStatus !== '已上传').map((episode) => episode.episodeNo);
    setBatchFeedback([alreadyUploaded.length ? `已有视频的集数已跳过：${alreadyUploaded.join('、')}` : '', unmatchedNames.length ? `未匹配文件：${unmatchedNames.join('、')}` : '', duplicateEpisodeNos.length ? `重复匹配集数：${duplicateEpisodeNos.join('、')}` : '', missingEpisodeNos.length ? `未选择视频的集数：${missingEpisodeNos.join('、')}` : '已按集号匹配视频。'].filter(Boolean).join('；'));
    setDraftEpisodes(next.length ? next : draftEpisodes);
    setCreateError('');
  };

  const uploadDraftVideo = async (draft: DraftEpisode) => {
    if (!draft.savedEpisodeId || !draft.file) return;
    patchDraftEpisode(draft.localId, { uploadStatus: '上传中', uploadError: undefined });
    setUploadProgress((current) => ({ ...current, [draft.localId]: { phase: 'sending', percent: 0 } }));
    try {
      const form = new FormData();
      form.append('episodeId', draft.savedEpisodeId);
      form.append('file', draft.file);
      const result = await uploadMultipart<{ job: UploadJob }>(`${API}/admin/upload-jobs/local`, form, sessionStorage.getItem(adminTokenStorageKey),
        (progress) => setUploadProgress((current) => ({ ...current, [draft.localId]: progress })));
      setUploadProgress((current) => ({ ...current, [draft.localId]: { phase: 'server-stored' } }));
      setJobs((items) => [result.job, ...items.filter((job) => job.id !== result.job.id)]);
      patchDraftEpisode(draft.localId, { uploadStatus: result.job.status === 'SUCCEEDED' ? '已上传' : '待传至 BytePlus', uploadError: undefined });
    } catch (error) {
      setUploadProgress((current) => {
        const next = { ...current };
        delete next[draft.localId];
        return next;
      });
      if (error instanceof UploadRequestError && error.status === 401) {
        sessionStorage.removeItem(adminTokenStorageKey);
        if (!adminSessionRecoveryStarted) {
          adminSessionRecoveryStarted = true;
          onSelect(activeApp);
        }
        throw new Error('管理员登录已失效，正在返回登录页。');
      }
      const uploadError = error instanceof Error ? error.message : '视频上传失败';
      let needsReconciliation = false;
      try {
        const latest = await api<{ items: UploadJob[] }>('/admin/upload-jobs');
        setJobs(latest.items);
        needsReconciliation = latest.items.some((job) => job.episodeId === draft.savedEpisodeId && job.sourceType === 'FILE' && ['PENDING', 'PROCESSING'].includes(job.status));
      } catch { /* The original upload error remains actionable if the status refresh also fails. */ }
      patchDraftEpisode(draft.localId, { uploadStatus: needsReconciliation ? 'BytePlus 处理中' : '上传失败', uploadError: needsReconciliation ? '服务器已接收文件，BytePlus 上传尚未完成。' : uploadError });
      throw error;
    }
  };

  const enqueueCurrentDrama = () => {
    if (createMode !== 'new' || createdAlbumId) return;
    const title = createTitle.trim();
    const tagList = createTagList.split(',').map((value) => Number(value.trim())).filter((value) => Number.isInteger(value) && value > 0);
    if (!title) return setCreateError('请填写剧名。');
    if (!createCoverFile) return setCreateError('请选择专辑封面。');
    if (!draftEpisodes.length || draftEpisodes.some((episode) => !episode.file && !episode.byteplusVid)) return setCreateError('请为每一集选择视频文件或已有 VID。');
    if (new Set(draftEpisodes.map((episode) => episode.episodeNo)).size !== draftEpisodes.length || draftEpisodes.some((episode) => !Number.isSafeInteger(episode.episodeNo) || episode.episodeNo < 1 || !episode.title.trim())) return setCreateError('请检查分集集号和标题。');
    if (tagList.length < 1 || tagList.length > 3 || new Set(tagList).size !== tagList.length) return setCreateError('TikTok 标签需填写 1 至 3 个不重复的正整数，并以逗号分隔。');
    if (createRewardedEnabled && !createPlacementId.trim()) return setCreateError('请填写激励广告位 ID，或关闭广告解锁。');
    setBatchDramas((items) => [...items, { id: crypto.randomUUID(), title, description: createDescription, releaseYear: createReleaseYear, dramaType: createDramaType, tagList: createTagList, coverFile: createCoverFile, freeCount: createFreeCount, rewardedEnabled: createRewardedEnabled, placementId: createPlacementId, rewardedCount: createRewardedCount, episodes: draftEpisodes.map((episode) => ({ ...episode, localId: crypto.randomUUID() })), status: '待创建' }]);
    resetCreateForm();
    setCreateError('');
    setMessage(`《${title}》已加入批量队列。`);
  };

  const submitBatchDramas = async () => {
    setCreating(true);
    setMessage('');
    try {
      for (const queued of batchDramas.filter((item) => item.status !== '已完成')) {
      setBatchDramas((items) => items.map((item) => item.id === queued.id ? { ...item, status: '处理中', error: undefined } : item));
      try {
        let albumId = queued.albumId;
        let episodes = queued.episodes;
        if (!albumId) {
          const coverForm = new FormData();
          coverForm.append('file', queued.coverFile);
          const cover = await api<CoverAsset>('/admin/cover-assets', { method: 'POST', body: coverForm });
          const preparedEpisodes = await Promise.all(episodes.map(async (episode) => {
            let coverAsset = episode.coverAsset;
            if (episode.coverFile) {
              const form = new FormData();
              form.append('file', episode.coverFile);
              coverAsset = await api<CoverAsset>('/admin/cover-assets', { method: 'POST', body: form });
            }
            return { ...episode, coverAsset };
          }));
          const tags = queued.tagList.split(',').map((value) => Number(value.trim()));
          const result = await api<{ album: Album; episodes: { id: string; episodeNo: number }[] }>('/admin/dramas', { method: 'POST', body: JSON.stringify({ title: queued.title, description: queued.description, releaseYear: queued.releaseYear, dramaType: queued.dramaType, tagList: tags, coverAssetId: cover.id, accessConfig: { freeEpisodeCount: queued.freeCount, rewardedAdEnabled: queued.rewardedEnabled, ...(queued.placementId.trim() ? { rewardedPlacementId: queued.placementId.trim() } : {}), rewardedAdCount: queued.rewardedCount }, episodes: preparedEpisodes.map((episode) => ({ episodeNo: episode.episodeNo, title: episode.title, sortOrder: episode.sortOrder, isFree: episode.isFree, coverAssetId: episode.coverAsset?.id ?? null, ...(episode.byteplusVid ? { byteplusVid: episode.byteplusVid.trim() } : {}) })) }) });
          albumId = result.album.id;
          const episodeIds = new Map(result.episodes.map((episode) => [episode.episodeNo, episode.id]));
          episodes = preparedEpisodes.map((episode) => ({ ...episode, savedEpisodeId: episodeIds.get(episode.episodeNo) }));
          setBatchDramas((items) => items.map((item) => item.id === queued.id ? { ...item, albumId, episodes } : item));
        }
        const failures: string[] = [];
        for (const episode of episodes) {
          if (!episode.file || episode.byteplusVid || ['已上传', '待传至 BytePlus', 'BytePlus 处理中'].includes(episode.uploadStatus ?? '')) continue;
          try {
            if (!episode.savedEpisodeId) throw new Error(`第 ${episode.episodeNo} 集未关联到已创建分集。`);
            const form = new FormData();
            form.append('episodeId', episode.savedEpisodeId);
            form.append('file', episode.file);
            const uploaded = await uploadMultipart<{ job: UploadJob }>(`${API}/admin/upload-jobs/local`, form, sessionStorage.getItem(adminTokenStorageKey), (progress) => setUploadProgress((current) => ({ ...current, [`batch-${queued.id}-${episode.localId}`]: progress })));
            setJobs((items) => [uploaded.job, ...items.filter((job) => job.id !== uploaded.job.id)]);
            episodes = episodes.map((item) => item.localId === episode.localId ? { ...item, uploadStatus: uploaded.job.status === 'SUCCEEDED' ? '已上传' : '待传至 BytePlus', uploadError: undefined } : item);
            setBatchDramas((items) => items.map((item) => item.id === queued.id ? { ...item, episodes } : item));
          } catch (error) {
            failures.push(`第 ${episode.episodeNo} 集：${error instanceof Error ? error.message : '上传失败'}`);
          }
        }
        if (failures.length) throw new Error(failures.join('；'));
        setBatchDramas((items) => items.map((item) => item.id === queued.id ? { ...item, status: '已完成', error: undefined } : item));
      } catch (error) {
        const detail = error instanceof Error ? error.message : '创建失败';
        setBatchDramas((items) => items.map((item) => item.id === queued.id ? { ...item, status: '失败', error: detail } : item));
      }
      }
      await loadTab('create');
    } finally {
      setCreating(false);
    }
  };

  const submitDrama = async (event: FormEvent) => {
    event.preventDefault();
    setCreating(true);
    setMessage('');
    setCreateError('');
    try {
      if (createMode === 'new' && !createdAlbumId && draftEpisodes.some((episode) => episode.savedEpisodeId)) throw new Error('当前草稿包含已保存分集，但无法确认所属剧集；请刷新数据或重置后新建。');
      if (createMode === 'append' && !targetAlbumId) throw new Error('请先选择要追加分集的剧集。');
      if (!draftEpisodes.length) throw new Error('请至少添加一集。');
      if (new Set(draftEpisodes.map((episode) => episode.episodeNo)).size !== draftEpisodes.length) throw new Error('当前分集集号不能重复。');
      if (draftEpisodes.some((episode) => !Number.isSafeInteger(episode.episodeNo) || episode.episodeNo < 1 || !episode.title.trim())) throw new Error('请检查集号和标题。');
      if (createMode === 'new' && !createdAlbumId && createRewardedEnabled && !createPlacementId.trim()) {
        throw new Error('请填写当前小程序的激励广告位 ID，或关闭广告解锁。');
      }
      let draftsToUpload = draftEpisodes;
      if (createMode === 'append') {
        const existing = episodes.filter((episode) => episode.albumId === targetAlbumId);
        draftsToUpload = resolveAppendEpisodes(draftEpisodes, existing);
        const duplicate = draftsToUpload.find((episode) => !episode.savedEpisodeId && existing.some((item) => item.episodeNo === episode.episodeNo && Boolean(item.byteplusVid)));
        if (duplicate) throw new Error(`第 ${duplicate.episodeNo} 集已经有 BytePlus 视频，请选择未上传的集数或从第 ${Math.max(...existing.map((item) => item.episodeNo)) + 1} 集开始。`);
        const alreadyBound = draftsToUpload.find((episode) => episode.savedEpisodeId && existing.some((item) => item.id === episode.savedEpisodeId && Boolean(item.byteplusVid)));
        if (alreadyBound) throw new Error(`第 ${alreadyBound.episodeNo} 集已经绑定 BytePlus 视频，无需再次上传。`);
        if (draftsToUpload.some((episode, index) => episode.savedEpisodeId !== draftEpisodes[index]?.savedEpisodeId)) {
          setDraftEpisodes(draftsToUpload);
          setMessage(`已识别未完成的原有分集，将直接补传：${draftsToUpload.filter((episode, index) => episode.savedEpisodeId && !draftEpisodes[index]?.savedEpisodeId).map((episode) => `第${episode.episodeNo}集`).join('、')}。`);
        }
      }
      const missingVideos = draftsToUpload.filter((episode) => !episode.file && !episode.byteplusVid && !['已上传', '待传至 BytePlus', 'BytePlus 处理中'].includes(episode.uploadStatus ?? ''));
      if (missingVideos.length) throw new Error(`请先为第 ${missingVideos.map((episode) => episode.episodeNo).join('、')} 集选择视频。`);
      const pendingConfirmation = draftsToUpload.filter((episode) => episode.uploadStatus === '待确认');
      if (pendingConfirmation.length) throw new Error(`第 ${pendingConfirmation.map((episode) => episode.episodeNo).join('、')} 集正在确认任务状态，请刷新上传任务。`);
      const unsaved = draftsToUpload.filter((episode) => !episode.savedEpisodeId);
      if (unsaved.length) {
        const draftsWithCovers = await Promise.all(unsaved.map(async (episode) => ({ ...episode, coverAsset: await uploadEpisodeCover(episode) })));
        const payloadEpisodes = draftsWithCovers.map((episode) => ({
          episodeNo: episode.episodeNo,
          title: episode.title,
          sortOrder: episode.sortOrder,
          isFree: episode.isFree,
          coverAssetId: episode.coverAsset?.id ?? null,
          ...(episode.byteplusVid ? { byteplusVid: episode.byteplusVid.trim() } : {})
        }));
        let result: { album: Album; episodes: { id: string; episodeNo: number }[] };
        if (createMode === 'append' || createdAlbumId) {
          const albumId = createMode === 'append' ? targetAlbumId : createdAlbumId;
          result = await api<typeof result>(`/admin/albums/${albumId}/episodes/batch`, {
            method: 'POST', body: JSON.stringify({ episodes: payloadEpisodes })
          });
        } else {
          const tagList = createTagList.split(',').map((value) => Number(value.trim())).filter((value) => Number.isInteger(value) && value > 0);
          if (tagList.length < 1 || tagList.length > 3 || new Set(tagList).size !== tagList.length) throw new Error('TikTok 标签需填写 1 至 3 个不重复的正整数，并以逗号分隔。');
          const cover = createCover ?? await uploadCover();
          result = await api<typeof result>('/admin/dramas', {
          method: 'POST',
          body: JSON.stringify({
            title: createTitle,
            description: createDescription,
            releaseYear: createReleaseYear,
            dramaType: createDramaType,
            tagList,
            coverAssetId: cover.id,
            accessConfig: {
              freeEpisodeCount: createFreeCount,
              rewardedAdEnabled: createRewardedEnabled,
              ...(createPlacementId.trim() ? { rewardedPlacementId: createPlacementId.trim() } : {}),
              rewardedAdCount: createRewardedCount
            },
            episodes: payloadEpisodes
          })
        });
          setCreatedAlbumId(result.album.id);
        }
        const episodeByNo = new Map(result.episodes.map((episode) => [episode.episodeNo, episode.id]));
        draftsToUpload = draftEpisodes.map((draft) => {
          const saved = draftsWithCovers.find((episode) => episode.localId === draft.localId);
          return saved ? { ...saved, savedEpisodeId: episodeByNo.get(saved.episodeNo) } : draft;
        });
        setDraftEpisodes(draftsToUpload);
      }
      const failedUploads: DraftEpisode[] = [];
      for (const draft of draftsToUpload) {
        if (!draft.file || draft.byteplusVid || ['已上传', '待传至 BytePlus', 'BytePlus 处理中'].includes(draft.uploadStatus ?? '')) continue;
        try {
          await uploadDraftVideo(draft);
        } catch {
          failedUploads.push(draft);
        }
      }
      const resultMessage = failedUploads.length
        ? `${createMode === 'append' ? (unsaved.length ? '新增分集已保存' : '原有分集已识别') : '短剧草稿已创建'}，但有 ${failedUploads.length} 个视频未完成，请查看对应行及上传任务状态。`
        : createMode === 'append' ? '分集已保存，视频已提交处理。' : '短剧草稿已创建，视频已提交处理。';
      if (!failedUploads.length) {
        if (createMode === 'append') {
          const existing = episodes.filter((episode) => episode.albumId === targetAlbumId);
          const episodeNo = Math.max(0, ...existing.map((episode) => episode.episodeNo), ...draftsToUpload.map((episode) => episode.episodeNo)) + 1;
          const sortOrder = Math.max(0, ...existing.map((episode) => episode.sortOrder), ...draftsToUpload.map((episode) => episode.sortOrder)) + 1;
          setDraftEpisodes([{ localId: `draft-${Date.now()}`, episodeNo, title: defaultEpisodeTitle(episodeNo), sortOrder, isFree: false }]);
          setBatchFeedback('');
        } else resetCreateForm();
      }
      await loadTab('create');
      setMessage(resultMessage);
    } catch (error) {
      const detail = error instanceof Error ? error.message : '内容创建失败';
      setCreateError(detail);
      setMessage(detail);
    } finally {
      setCreating(false);
    }
  };

  const updateAccess = async (album: Album) => {
    setSavingAlbumId(album.id);
    try {
      const accessConfig = { freeEpisodeCount: 0, rewardedAdEnabled: Boolean(defaultPlacementId), rewardedPlacementId: defaultPlacementId, rewardedAdCount: 1, ...album.accessConfig };
      if (accessConfig.rewardedAdEnabled && !accessConfig.rewardedPlacementId.trim()) throw new Error('请先配置当前小程序的激励广告位 ID，或关闭广告解锁。');
      const updatedAlbum = await api<Album>(`/admin/albums/${album.id}`, { method: 'PATCH', body: JSON.stringify({ accessConfig }) });
      setAlbums((items) => items.map((item) => item.id === album.id ? { ...item, ...updatedAlbum, episodeCount: item.episodeCount } : item));
      setDirtyAccessAlbumIds((current) => {
        const next = new Set(current);
        next.delete(album.id);
        return next;
      });
      setMessage('剧集访问配置已保存');
    } catch (error) {
      setMessage(error instanceof Error ? `剧集访问配置保存失败：${error.message}` : '剧集访问配置保存失败');
    } finally {
      setSavingAlbumId(null);
    }
  };
  const updateAccessDraft = (albumId: string, patch: NonNullable<Album['accessConfig']>) => {
    setAlbums((items) => items.map((item) => item.id === albumId ? { ...item, accessConfig: { ...item.accessConfig, ...patch } } : item));
    setDirtyAccessAlbumIds((current) => new Set(current).add(albumId));
  };
  const openDramaMaterials = (albumId: string) => {
    setMaterialSelection({ albumId, request: ++materialSelectionRequest.current });
    window.requestAnimationFrame(() => document.getElementById('drama-materials')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  };
  const deleteDraftAlbum = async (album: Album) => {
    const confirmation = album.sharedPlayback
      ? `确定删除“${album.title}”在当前小程序中的授权播放副本吗？这会清除本地副本、分集和观看进度，并解除内部授权映射；主剧目、TikTok 平台剧目、平台授权和 BytePlus 视频不会删除。`
      : `确定删除草稿剧集“${album.title}”吗？此操作会删除本项目中的全部分集和上传任务，且无法恢复；BytePlus 中已经上传的视频不会被删除。`;
    if (!window.confirm(confirmation)) return;
    setDeletingAlbumId(album.id);
    try {
      await api<void>(`/admin/albums/${album.id}`, { method: 'DELETE' });
      setAlbums((items) => items.filter((item) => item.id !== album.id));
      setEpisodes((items) => items.filter((item) => item.albumId !== album.id));
      setDirtyAccessAlbumIds((current) => {
        const next = new Set(current);
        next.delete(album.id);
        return next;
      });
      await loadTab('albums');
      setMessage(album.sharedPlayback ? `已删除“${album.title}”在当前小程序中的共享副本。` : `草稿剧集“${album.title}”已删除。`);
    } catch (error) {
      setMessage(error instanceof Error ? `删除剧集失败：${error.message}` : '删除剧集失败');
    } finally {
      setDeletingAlbumId(null);
    }
  };
  const selectAnalyticsPreset = (days: number) => {
    setAnalyticsFrom(rangeStart(days));
    setAnalyticsTo(inputDate(new Date()));
  };
  const changePassword = async (event: FormEvent) => {
    event.preventDefault();
    setChangingPassword(true);
    try {
      await api('/admin/me/password', { method: 'PUT', body: JSON.stringify({ currentPassword, newPassword }) });
      sessionStorage.removeItem(adminTokenStorageKey);
      sessionStorage.removeItem(platformSubmissionStorageKey);
      setPlatformSubmissions([]);
      setCurrentPassword('');
      setNewPassword('');
      setLoggedIn(false);
      setMessage('密码已更新，请使用新密码重新登录。');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '密码更新失败');
    } finally {
      setChangingPassword(false);
    }
  };
  const saveEntryAdPolicy = async (event: FormEvent) => {
    event.preventDefault();
    if (entryAdPolicy.releaseId !== entryAdReleaseId) return;
    setSavingEntryAdPolicy(true);
    try {
      const next = await api<AppEntryAdPolicy>('/admin/app-entry-ad-policy', { method: 'PUT', body: JSON.stringify(entryAdPolicy) });
      setEntryAdPolicy(next);
      setMessage(`进入广告策略已保存（版本 ${next.version}），将在新的小程序启动会话生效。`);
      await loadEntryAdSettings();
    } catch (error) {
      setMessage(error instanceof Error ? `进入广告策略保存失败：${error.message}` : '进入广告策略保存失败');
    } finally {
      setSavingEntryAdPolicy(false);
    }
  };
  const saveEntryAdRelease = async () => {
    const release = entryAdVersions.find((item) => item.releaseId === entryAdReleaseId);
    if (!release) return;
    setSavingEntryAdRelease(true);
    try {
      await api(`/admin/app-entry-ad-releases/${encodeURIComponent(release.releaseId)}`, { method: 'PATCH', body: JSON.stringify({ portalVersion: release.portalVersion?.trim() || null, portalStatus: release.portalStatus }) });
      await loadEntryAdSettings();
      setMessage('代码版本的 Portal 状态已保存。');
    } catch (error) {
      setMessage(error instanceof Error ? `Portal 状态保存失败：${error.message}` : 'Portal 状态保存失败');
    } finally {
      setSavingEntryAdRelease(false);
    }
  };
  const retryUploadJob = async (job: UploadJob) => {
    setRetryingJobId(job.id);
    try {
      await api(`/admin/upload-jobs/${job.id}/retry`, { method: 'POST' });
      setMessage(`已将“${job.episode?.title ?? job.episodeId}”重新加入上传队列。`);
      await loadJobs();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '重新排队失败');
    } finally {
      setRetryingJobId(null);
    }
  };
  const reconcileUploadJob = async (job: UploadJob) => {
    setReconcilingJobId(job.id);
    try {
      const result = await api<{ message?: string }>(`/admin/upload-jobs/${job.id}/reconcile`, { method: 'POST', body: JSON.stringify({}) });
      await loadJobs();
      setMessage(result.message ?? `已请求继续处理“${job.episode?.title ?? job.episodeId}”的上传任务。`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '上传任务对账失败');
    } finally {
      setReconcilingJobId(null);
    }
  };
  const releaseUploadJob = async (job: UploadJob) => {
    if (!window.confirm(`仅当你已在 BytePlus 当前空间确认没有对应媒资时，才能释放“${job.episode?.title ?? job.episodeId}”并重新上传。继续吗？`)) return;
    setReconcilingJobId(job.id);
    try {
      await api(`/admin/upload-jobs/${job.id}/release`, { method: 'POST', body: JSON.stringify({ confirmation: 'NO_BYTEPLUS_MEDIA' }) });
      setDraftEpisodes((items) => items.map((episode) => episode.savedEpisodeId === job.episodeId ? { ...episode, uploadStatus: '上传失败', uploadError: '已确认无 BytePlus 媒资，请重新选择视频补传。' } : episode));
      await loadJobs();
      setMessage(`已释放“${job.episode?.title ?? job.episodeId}”，现在可以重新选择视频上传。`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '释放上传任务失败');
    } finally {
      setReconcilingJobId(null);
    }
  };
  const waitForPlatformJob = async (jobId: string, albumId: string) => {
    for (let attempt = 0; attempt < 10; attempt += 1) {
      await new Promise((resolve) => window.setTimeout(resolve, 1_500));
      try {
        const result = await api<{ items: PlatformSyncJob[] }>(`/admin/platform-sync-jobs?albumId=${encodeURIComponent(albumId)}&limit=100`);
        const job = result.items.find((item) => item.id === jobId);
        if (job && ['SUCCEEDED', 'FAILED', 'CONFLICT'].includes(job.status)) return job;
      } catch {
        return undefined;
      }
    }
    return undefined;
  };
  const runPlatformAction = async (album: Album, action: 'sync-version' | 'review-submit' | 'online-version' | 'online' | 'offline' | 'reconcile') => {
    const priorityScore = reviewPriorities[album.id] ?? 2;
    if (action === 'review-submit' && priorityScore === 1 && !window.confirm(`确定将“${album.title}”以加急方式送审吗？仅适用于符合平台加急条件的剧目，每机构每天最多 35 部；已在审核中的版本无法靠重复送审加急。`)) return;
    setPlatformWorking(`${album.id}:${action}`);
    try {
      const queued = await api<{ job?: PlatformSyncJob }>(`/admin/albums/${album.id}/${action}`, { method: 'POST', ...(action === 'review-submit' ? { body: JSON.stringify({ priorityScore }) } : {}) });
      setMessage(`“${album.title}”的平台任务已入队，正在等待处理结果。`);
      const completed = queued.job?.id ? await waitForPlatformJob(queued.job.id, album.id) : undefined;
      await Promise.all([loadAlbums(), loadEpisodes(), loadPlatformJobs()]);
      const actionName = action === 'review-submit' ? (priorityScore === 1 ? '加急送审' : '普通送审') : '平台操作';
      setMessage(completed
        ? `“${album.title}”${actionName}处理完成：${platformBusinessResult(completed)}。${platformBusinessDetails(completed).filter((detail) => detail.startsWith('审核原因') || detail.includes('异常')).join(' ')}`
        : `“${album.title}”的${actionName}已入队，暂未返回最终结果；请稍后刷新查看平台业务结果。`);
    } catch (error) {
      const detail = error instanceof Error ? error.message : '平台操作提交失败';
      recordPlatformSubmission(album, platformJobLabels[action === 'sync-version' ? 'ALBUM_VERSION' : action === 'review-submit' ? 'REVIEW' : action === 'reconcile' ? 'RECONCILE' : action === 'online-version' ? 'SET_ONLINE_VERSION' : action === 'online' ? 'PUBLISH' : 'UNPUBLISH'], detail, true);
      setMessage(detail);
    } finally {
      setPlatformWorking(null);
    }
  };
  const saveAlbumTitle = async (album: Album) => {
    const title = (titleDrafts[album.id] ?? album.title).trim();
    if (!title) { setMessage('剧集名称不能为空。'); return; }
    if (title === album.title) return;
    setSavingTitleId(album.id);
    try {
      const scope = await api<EditableAlbumMetadata>(`/admin/albums/${album.id}/display-metadata`);
      if (scope.shared) {
        setEditingAlbumMetadata({ ...album, initialTitle: title });
        return;
      }
      const updated = await api<EditableAlbumMetadata>(`/admin/albums/${album.id}/display-metadata`, { method: 'PATCH', body: JSON.stringify({
        title, description: scope.description ?? '', translations: scope.translations ?? [], expectedVersion: scope.version ?? 0
      }) });
      setAlbums((items) => items.map((item) => item.id === album.id ? { ...item, ...updated, episodeCount: item.episodeCount } : item));
      setTitleDrafts((drafts) => { const next = { ...drafts }; delete next[album.id]; return next; });
      setMessage(`“${title}”已保存到当前小程序。`);
    } catch (error) {
      setMessage(error instanceof Error ? `剧集名称同步失败：${error.message}` : '剧集名称同步失败');
    } finally {
      setSavingTitleId(null);
    }
  };
  const albumMetadataSaved = (updated: EditableAlbumMetadata) => {
    setAlbums((items) => items.map((item) => item.id === updated.id ? { ...item, ...updated, episodeCount: item.episodeCount } : item));
    setTitleDrafts((drafts) => { const next = { ...drafts }; delete next[updated.id]; return next; });
    setMessage(updated.shared ? `“${updated.title}”的统一资料已保存，正在同步到 ${updated.targets?.length ?? 0} 个关联小程序。` : `“${updated.title}”的剧名和简介已保存到当前小程序。`);
  };
  const syncTikTokMedia = async (album: Album) => {
    setPlatformWorking(`${album.id}:media`);
    try {
      // The albums tab no longer preloads every episode. Read only the selected
      // album when an operator explicitly starts a media sync.
      const albumDetail = await api<{ episodes: EpisodeOption[] }>(`/admin/albums/${encodeURIComponent(album.id)}`);
      const albumEpisodes = albumDetail.episodes;
      const videoEpisodes = albumEpisodes.filter((episode) => episode.byteplusVid);
      const requests = [
        ...(album.coverAssetId ? [{ label: '封面', request: api<{ alreadySynced: boolean }>(`/admin/cover-assets/${album.coverAssetId}/sync`, { method: 'POST' }) }] : []),
        ...videoEpisodes.map((episode) => ({ label: `第 ${episode.episodeNo} 集`, request: api<{ alreadySynced: boolean }>(`/admin/episodes/${episode.id}/sync-tiktok-video`, { method: 'POST' }) }))
      ];
      const results = await Promise.allSettled(requests.map((item) => item.request));
      const queuedVideos = results.filter((result, index) => index >= (album.coverAssetId ? 1 : 0) && result.status === 'fulfilled' && !result.value.alreadySynced).length;
      const failures = results.flatMap((result, index) => result.status === 'rejected' ? [`${requests[index].label}：${result.reason instanceof Error ? result.reason.message : '提交失败'}`] : []);
      const missing = albumEpisodes.filter((episode) => !episode.byteplusVid).map((episode) => `第 ${episode.episodeNo} 集`).join('、');
      if (missing) failures.push(`${missing}缺少 BytePlus VID，尚不能登记`);
      if (!album.coverAssetId) failures.push('专辑缺少封面，尚不能同步版本');
      await loadPlatformJobs();
       const detailMessage = `新增 ${queuedVideos} 集视频同步任务${failures.length ? `；未完成：${failures.join('；')}` : '；已就绪的旧分集已跳过'}。`;
       recordPlatformSubmission(album, '同步媒资', detailMessage, failures.length > 0);
       setMessage(`“${album.title}”${detailMessage}`);
    } catch (error) {
      const detail = error instanceof Error ? error.message : 'TikTok 媒资同步提交失败';
      recordPlatformSubmission(album, '同步媒资', detail, true);
      setMessage(detail);
    } finally {
      setPlatformWorking(null);
    }
  };
  const releaseJobRows = releaseStatuses.flatMap((item) => (item.operations ?? []).map((job) => ({ ...job, miniAppKey: item.miniAppKey })))
    .sort((left, right) => new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime()).slice(0, 50);
  const canWriteContent = hasAdminPermission(currentAdmin?.role, 'content.write');
  const canSyncContent = hasAdminPermission(currentAdmin?.role, 'content.sync');
  const canReviewContent = hasAdminPermission(currentAdmin?.role, 'content.review');
  const canPublishContent = hasAdminPermission(currentAdmin?.role, 'content.publish');
  const canWriteAds = hasAdminPermission(currentAdmin?.role, 'ads.write');
  const navItems: Array<[Tab, typeof Activity, string]> = [['overview', LayoutDashboard, '概览'], ['audience', Users, '观众数据'], ['playback', Activity, '播放质量']];
  if (canWriteContent) navItems.splice(1, 0, ['create', Plus, '内容创建'], ['albums', ListVideo, '剧集与解锁']);
  if (canWriteAds) navItems.splice(canWriteContent ? 3 : 1, 0, ['ads', Megaphone, '进入广告']);
  const tabLabels: Record<Tab, string> = { overview: '概览', create: '内容创建', albums: '剧集与解锁', ads: '进入广告', audience: '观众数据', playback: '播放质量', security: '账号安全' };
  const title = tab === 'overview' ? '内容运营概览' : tab === 'create' ? '内容创建' : tab === 'ads' ? '进入广告策略' : tab === 'audience' ? '观众数据' : tab === 'playback' ? '播放质量' : tab === 'security' ? '账号安全' : '剧集与解锁配置';

  const selectedEntryAdRelease = entryAdVersions.find((item) => item.releaseId === entryAdReleaseId);
  return <div className="admin-layout"><aside className="sidebar"><div className="brand"><span><Film size={17} /></span>QuicK <span>ReeLS</span></div><MiniAppSelect />{creating && <p className="form-help">上传进行中，完成后可切换小程序。</p>}<p className="workspace-label">运营工作区</p><nav>
    {navItems.map(([key, Icon, label]) => <button key={key} className={tab === key ? 'active' : ''} onClick={() => setTab(key)}><Icon size={17} />{label}</button>)}
  </nav><div className="sidebar-bottom"><button className={tab === 'security' ? 'active' : ''} onClick={() => setTab('security')}><Settings2 size={17} />账号安全</button><div className="account"><span className="account-avatar">{currentAdmin?.email.slice(0, 2).toUpperCase() ?? 'OP'}</span><span><strong>{currentAdmin?.email ?? '运营管理员'}</strong><small>{currentAdmin?.role ?? 'TK小程序管理后台'}</small></span><MoreHorizontal size={16} /></div></div></aside>
    <main className="main"><header className="page-header"><div><p className="eyebrow">{miniAppNames[activeApp]} / {tabLabels[tab]}</p><h1>{title}</h1><p className="subhead">当前展示 {miniAppNames[activeApp]} 的内容和数据。</p></div><div className="header-actions"><button className="secondary" onClick={() => void loadTab(tab)} title="刷新当前页面"><RefreshCw size={15} className={loading ? 'spin' : ''} />刷新</button><button className="secondary" onClick={() => { sessionStorage.removeItem(adminTokenStorageKey); sessionStorage.removeItem(platformSubmissionStorageKey); setPlatformSubmissions([]); setLoggedIn(false); }}>退出登录</button></div></header>{message && <div className="notice"><CheckCircle2 size={16} />{message}</div>}{tabResources[tab].map((key) => resourceStatus[key]?.error && <div key={key} className="load-error" role="alert">{resourceStatus[key]?.error}<button className="secondary" type="button" onClick={() => void loadTab(tab)}>重试</button></div>)}
      {(tab === 'audience' || tab === 'playback') && <div className="toolbar"><span><CalendarDays size={15} />统计周期</span><button className="secondary" type="button" onClick={() => selectAnalyticsPreset(7)}>近 7 天</button><button className="secondary" type="button" onClick={() => selectAnalyticsPreset(30)}>近 30 天</button><button className="secondary" type="button" onClick={() => selectAnalyticsPreset(90)}>近 90 天</button><label>开始<input type="date" value={analyticsFrom} max={analyticsTo} onChange={(event) => setAnalyticsFrom(event.target.value)} /></label><label>结束<input type="date" value={analyticsTo} min={analyticsFrom} max={inputDate(new Date())} onChange={(event) => setAnalyticsTo(event.target.value)} /></label><label>时区<select value={analyticsTimezone} onChange={(event) => setAnalyticsTimezone(event.target.value)}><option value="Asia/Shanghai">Asia/Shanghai</option><option value="UTC">UTC</option></select></label></div>}
      {(tab === 'audience' || tab === 'playback') && (audience || playback) && <p className="data-updated">统计数据{(tab === 'audience' ? audience?.updatedAt : playback?.updatedAt) ? `更新于 ${new Date((tab === 'audience' ? audience?.updatedAt : playback?.updatedAt) as string).toLocaleString('zh-CN')}` : '来自实时查询'}</p>}
      {tab === 'overview' && <>{overview?.updatedAt && <p className="data-updated">统计更新于 {new Date(overview.updatedAt).toLocaleString('zh-CN')} · 汇总每 5 分钟刷新</p>}
        <section className="metrics"><Metric label="在线剧集" value={overview ? String(overview.albums) : '—'} change="实时数据" icon={Film} tone="pink" /><Metric label="在线集数" value={overview ? String(overview.episodes) : '—'} change="已通过发布条件" icon={ListVideo} tone="cyan" /><Metric label="用户数" value={overview ? String(overview.users) : '—'} change="累计注册" icon={Users} tone="green" /><Metric label="广告解锁" value={overview ? String(overview.rewardedUnlocks) : '—'} change="累计完成" icon={CheckCircle2} tone="yellow" /></section>
        <div className="content-grid"><Panel title="运营健康度" description="关键业务数据当前状态"><div className="readiness-list">{overview ? <><div><span className="ready-dot done"><CheckCircle2 size={15} /></span><span><strong>剧集元数据与访问策略</strong><small>{overview.albums} 部在线剧集 · {overview.episodes} 集可见</small></span><em>正常</em></div><div><span className="ready-dot done"><Database size={15} /></span><span><strong>观众行为采集</strong><small>{overview.likes} 次点赞 · {overview.favorites} 次收藏 · {overview.searches} 次搜索</small></span><em>正常</em></div></> : <p className="empty-copy">{resourceStatus.overview?.error ? '概览数据暂不可用' : '正在加载概览数据...'}</p>}</div></Panel>
          <Panel title="最近上传" description="BytePlus 媒体处理任务"><div className="compact-list">{recentJobs.map((job) => <div className="compact-row" key={job.id}><FileVideo size={17} /><span><strong>{job.episode?.title ?? job.episodeId}</strong><small>{job.sourceName ?? job.sourceType ?? '链接'}</small></span><Status value={job.status} /></div>)}{!recentJobs.length && <p className="empty-copy">{resourceStatus.recentJobs?.loaded ? '还没有上传任务' : resourceStatus.recentJobs?.error ? '上传任务暂不可用' : '正在加载上传任务...'}</p>}</div></Panel></div>
        <HealthPanel health={health} minutes={healthMinutes} onMinutes={setHealthMinutes} error={resourceStatus.health?.error} onRefresh={() => void loadResource('health', (signal) => api<Health>(`/admin/analytics/health?minutes=${healthMinutes}`, { signal }), setHealth)} />
      </>}
      {tab === 'create' && <>
        {!resourceStatus.albums?.loaded && !resourceStatus.albums?.error && <p className="load-placeholder">正在加载已有剧集...</p>}
        <Panel title={createMode === 'append' ? '追加分集' : '创建短剧草稿'} description={createMode === 'append' ? '新分集保存到选中的剧集，沿用其访问策略。' : '一次录入专辑、封面、剧集和本地视频；失败视频可在该行单独重试。'}>
          <form className="create-form" onSubmit={submitDrama}>
            <div className="create-mode-bar"><div className="mode-segment" role="group" aria-label="内容创建模式"><button type="button" className={createMode === 'new' ? 'active' : ''} onClick={() => selectCreateMode('new')}>新建剧集</button><button type="button" className={createMode === 'append' ? 'active' : ''} onClick={() => selectCreateMode('append')}>追加到已有剧集</button></div><button className="secondary" type="button" disabled={creating} onClick={() => { if (!hasActiveContent() || window.confirm('清空当前表单并开始新剧集？已保存的模板和剧集不会删除。')) resetCreateForm(); }}>重置 / 新建</button></div>
            {createMode === 'append' && <><label className="target-album-select">目标剧集<select value={targetAlbumId} onChange={(event) => selectTargetAlbum(event.target.value)} required><option value="">请选择已有剧集</option>{albums.map((album) => <option key={album.id} value={album.id}>{album.title} ({album.id})</option>)}</select></label>{targetAlbumId && (() => { const target = albums.find((album) => album.id === targetAlbumId); const existing = episodes.filter((episode) => episode.albumId === targetAlbumId); return target && <p className="target-album-summary">现有 {existing.length} 集 · 最大集号 {Math.max(0, ...existing.map((episode) => episode.episodeNo))} · 免费集数 {target.accessConfig?.freeEpisodeCount ?? 0} · 线上版本 {target.onlineVersion ?? '-'} · 当前版本 {target.tiktokVersion ?? '-'} · 审核 {target.reviewStatus ?? '未送审'}</p>; })()}</>}
            {createMode === 'new' && <>
              <div className="template-toolbar"><label>复用模板<select value={selectedTemplateId} onChange={(event) => setSelectedTemplateId(event.target.value)}><option value="">选择模板</option>{templates.map((template) => <option key={template.id} value={template.id}>{template.name}</option>)}</select></label><button className="secondary" type="button" disabled={!selectedTemplateId || Boolean(createdAlbumId)} onClick={applyTemplate}>应用</button><button className="secondary" type="button" disabled={!selectedTemplateId} onClick={() => { const template = templates.find((item) => item.id === selectedTemplateId); if (template && window.confirm(`删除模板“${template.name}”？`)) { setTemplates((items) => items.filter((item) => item.id !== template.id)); setSelectedTemplateId(''); } }}>删除模板</button><button className="secondary" type="button" onClick={saveTemplate}>保存为模板</button></div>
              {selectedTemplateId && (() => { const template = templates.find((item) => item.id === selectedTemplateId); return template && <p className="target-album-summary">类型 {['', 'AIGC', '漫剧', '真人配音', '真人本地化'][template.dramaType] ?? template.dramaType} · 标签 {template.tagList} · 免费集号上限 {template.freeCount} · 广告解锁 {template.rewardedEnabled ? '启用' : '关闭'} · 每集观看 {template.rewardedCount} 次</p>; })()}
              {createdAlbumId && <p className="target-album-summary">剧集已保存。此处信息已锁定；可继续上传视频或添加分集。</p>}
              <fieldset className="album-fields" disabled={Boolean(createdAlbumId)}><div className="form-grid">
              <label>剧名<input value={createTitle} onChange={(event) => setCreateTitle(event.target.value)} required /></label>
              <label>上线年份<input type="number" min="1900" max="2100" value={createReleaseYear} onChange={(event) => setCreateReleaseYear(Number(event.target.value))} required /></label>
              <label>剧目类型<select value={createDramaType} onChange={(event) => setCreateDramaType(Number(event.target.value))}><option value={1}>AIGC</option><option value={2}>漫剧</option><option value={3}>真人配音</option><option value={4}>真人本地化</option></select></label>
              <label>TikTok 标签（1–3 个）<input value={createTagList} onChange={(event) => setCreateTagList(event.target.value)} placeholder="例如：1,23" required /></label>
              <label>免费集号上限<input type="number" min="0" max="10000" value={createFreeCount} onChange={(event) => setCreateFreeCount(Number(event.target.value))} /></label>
              <label>激励广告位 ID<input value={createPlacementId} onChange={(event) => setCreatePlacementId(event.target.value)} /></label>
              <label>每集解锁所需广告观看次数<input type="number" min="1" value={createRewardedCount} onChange={(event) => setCreateRewardedCount(Number(event.target.value))} /></label>
            </div>
            <label>简介<textarea value={createDescription} onChange={(event) => setCreateDescription(event.target.value)} rows={4} /></label>
            <div className="cover-row">
              <label>专辑封面<input type="file" accept="image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp" onChange={(event) => selectAlbumCover(event.target.files?.[0] ?? null)} required={!createCover} /></label>
              {createCoverFile && <span className="file-hint"><Image size={15} />{createCoverFile.name}</span>}
              {(createCover?.publicUrl ?? createCoverPreviewUrl) && <img className="cover-preview" src={createCover?.publicUrl ?? createCoverPreviewUrl} alt="专辑封面预览" />}
              {(createCoverFile || createCover) && <button className="text-button" type="button" onClick={() => selectAlbumCover(null)}>移除封面</button>}
            </div>
            <label className="check-row"><input type="checkbox" checked={createRewardedEnabled} onChange={(event) => setCreateRewardedEnabled(event.target.checked)} />启用广告解锁</label></fieldset></>}
            <div className="episode-toolbar">
              <label>{createMode === 'append' ? '本次处理集数' : '总集数'}<input className="inline-number" type="number" min="1" max="500" value={draftEpisodes.length} onChange={(event) => applyEpisodeCount(Number(event.target.value))} /></label>
              <label>批量选择视频<input type="file" accept="video/mp4,video/quicktime,.mp4,.mov,.m4v" multiple onChange={(event) => applyBatchFiles(event.target.files)} /></label><button className="secondary" type="button" disabled={loadingVodMedia} onClick={() => void loadVodMedia()}><RefreshCw size={15} className={loadingVodMedia ? 'spin' : ''} />读取 VOD 媒资</button>
            </div>
            {batchFeedback && <p className="batch-feedback"><AlertTriangle size={15} />{batchFeedback}</p>}
            {createMode === 'new' && !createdAlbumId && <button className="secondary" type="button" disabled={creating} onClick={enqueueCurrentDrama}><Plus size={15} />加入批量创建队列</button>}
            {batchDramas.length > 0 && <section className="batch-drama-queue" aria-label="批量创建队列"><div className="batch-drama-queue-heading"><strong>批量创建队列（{batchDramas.length}）</strong><button className="primary" type="button" disabled={creating || batchDramas.every((item) => item.status === '已完成')} onClick={() => void submitBatchDramas()}><Upload size={15} />{creating ? '正在逐部处理...' : '开始批量创建 / 重试失败项'}</button></div><div className="table-wrap"><table><thead><tr><th>剧名</th><th>分集</th><th>封面 / 视频</th><th>状态</th><th>操作</th></tr></thead><tbody>{batchDramas.map((item) => <tr key={item.id}><td>{item.title}</td><td>{item.episodes.length} 集</td><td>{item.coverFile.name} · {item.episodes.filter((episode) => episode.file).length} 个本地视频</td><td><span>{item.status}</span>{item.error && <small className="table-error">{item.error}</small>}</td><td><button className="more" type="button" disabled={creating || item.status === '处理中' || Boolean(item.albumId)} title={item.albumId ? '该剧已创建，保留在队列中以便补传失败视频' : '从队列移除'} onClick={() => setBatchDramas((items) => items.filter((queued) => queued.id !== item.id))}><Trash2 size={15} /></button></td></tr>)}</tbody></table></div></section>}
            <div className="table-wrap"><table><thead><tr><th>集号</th><th>标题</th><th>排序</th><th>单集免费</th><th>独立封面</th><th>视频文件或已有 VID</th><th>状态</th><th></th></tr></thead><tbody>{draftEpisodes.map((episode) => <tr key={episode.localId} className={!episode.file && !episode.byteplusVid ? 'needs-file' : ''}>
              <td><input className="inline-number" type="number" min="1" step="1" aria-label="集号" value={episode.episodeNo} disabled={Boolean(episode.savedEpisodeId)} onChange={(event) => setDraftEpisodeNo(episode.localId, Number(event.target.value))} /></td>
              <td><input className="table-input" aria-label="分集标题" value={episode.title} disabled={Boolean(episode.savedEpisodeId)} onChange={(event) => patchDraftEpisode(episode.localId, { title: event.target.value })} /></td>
              <td><input className="inline-number" type="number" min="1" aria-label="排序" value={episode.sortOrder} disabled={Boolean(episode.savedEpisodeId)} onChange={(event) => patchDraftEpisode(episode.localId, { sortOrder: Number(event.target.value) })} /></td>
              <td><input type="checkbox" aria-label="单集免费" checked={episode.isFree} disabled={Boolean(episode.savedEpisodeId)} onChange={(event) => patchDraftEpisode(episode.localId, { isFree: event.target.checked })} /></td>
              <td><div className="episode-cover-cell"><label className="file-cell">{episode.coverFile?.name ?? (episode.coverAsset ? '已保存封面' : '使用专辑封面')}<input type="file" accept="image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp" disabled={Boolean(episode.savedEpisodeId)} onChange={(event) => selectEpisodeCover(episode, event.target.files?.[0] ?? null)} /></label>{(episode.coverAsset?.publicUrl ?? episode.coverPreviewUrl) && <img className="episode-cover-preview" src={episode.coverAsset?.publicUrl ?? episode.coverPreviewUrl} alt={`${episode.title} 封面预览`} />}</div></td>
              <td><label className="file-cell">{episode.file?.name ?? (episode.byteplusVid ? '已有 BytePlus VID' : '选择视频')}<input type="file" accept="video/mp4,video/quicktime,.mp4,.mov,.m4v" onChange={(event) => patchDraftEpisode(episode.localId, { file: event.target.files?.[0] ?? null, byteplusVid: '', uploadError: undefined })} /></label><select value={episode.byteplusVid ?? ''} onChange={(event) => patchDraftEpisode(episode.localId, { byteplusVid: event.target.value, file: null, uploadError: undefined })}><option value="">选择已有 VOD 媒资</option>{vodMedia.map((media) => <option key={media.vid} value={media.vid}>{media.title} · {media.vid}</option>)}</select><input className="table-input" placeholder="或粘贴已有 BytePlus VID" value={episode.byteplusVid ?? ''} onChange={(event) => patchDraftEpisode(episode.localId, { byteplusVid: event.target.value, file: null, uploadError: undefined })} /></td>
              <td><div className="draft-upload-state"><span>{episode.byteplusVid ? '待从 VOD 导入' : episode.uploadStatus ?? (episode.file ? '待保存' : '缺少视频')}</span>{uploadProgress[episode.localId] && (episode.uploadStatus === '上传中' || episode.uploadStatus === '待传至 BytePlus') && <UploadMeter episodeNo={episode.episodeNo} progress={uploadProgress[episode.localId]} />}{episode.uploadError && <small className="table-error" title={episode.uploadError}>{episode.uploadError}</small>}{episode.uploadStatus === '上传失败' && episode.file && episode.savedEpisodeId && <button className="text-button retry-button" type="button" onClick={() => void uploadDraftVideo(episode).catch((error) => setMessage(error instanceof Error ? error.message : '上传失败'))}>重试上传</button>}</div></td>
              <td><button className="more" type="button" disabled={Boolean(episode.savedEpisodeId)} onClick={() => setDraftEpisodes((items) => items.filter((item) => item.localId !== episode.localId))} title={episode.savedEpisodeId ? '已保存分集不能从当前表单删除' : '删除'}><Trash2 size={15} /></button></td>
            </tr>)}</tbody></table></div>
            <button className="secondary" type="button" onClick={() => setDraftEpisodes((items) => {
              const existing = createMode === 'append' ? episodes.filter((episode) => episode.albumId === targetAlbumId) : [];
              const episodeNo = Math.max(nextEpisodeNo(items), Math.max(0, ...existing.map((episode) => episode.episodeNo)) + 1);
              const sortOrder = Math.max(items.at(-1)?.sortOrder ?? 0, ...existing.map((episode) => episode.sortOrder)) + 1;
              return [...items, { localId: `draft-${Date.now()}`, episodeNo, title: defaultEpisodeTitle(episodeNo), sortOrder, isFree: false }];
            })}><Plus size={15} />添加分集</button>
            {createError && <p className="form-error create-error"><CircleAlert size={15} />{createError}</p>}
            <button className="primary" type="submit" disabled={creating || (createMode === 'append' && !targetAlbumId) || !draftEpisodes.length}><Save size={17} />{creating ? '处理中...' : createMode === 'append' ? '保存并上传视频' : draftEpisodes.some((episode) => episode.savedEpisodeId) ? '保存新增分集并上传视频' : '保存草稿并上传视频'}</button>
          </form>
        </Panel>
        <Panel title="上传处理状态"><div className="table-wrap"><table className="upload-jobs-table"><thead><tr><th>剧集</th><th>来源</th><th>状态</th><th>处理信息</th><th>创建时间</th><th>操作</th></tr></thead><tbody>{jobs.map((job) => {
          const legacyStale = job.status === 'PROCESSING' && job.sourceType === 'FILE' && !job.uploadScope && !job.providerJobId && job.startedAt && Date.now() - new Date(job.startedAt).getTime() >= 2 * 60 * 60_000;
          const activeSibling = jobs.some((other) => other.id !== job.id && other.episodeId === job.episodeId && ['PENDING', 'PROCESSING'].includes(other.status));
          const activeUpload = job.status === 'PROCESSING' && Boolean(job.leaseExpiresAt && new Date(job.leaseExpiresAt).getTime() > Date.now());
          const waitingRetry = job.status === 'PROCESSING' && Boolean(job.nextAttemptAt) && !activeUpload;
          return <tr key={job.id}><td><strong>{job.episode?.title ?? job.episodeId}</strong></td><td>{job.sourceName ?? job.sourceType ?? '链接'}</td><td><Status value={job.status} /></td><td>{activeUpload ? (job.providerJobId ? 'BytePlus 已返回 VID，正在确认结果' : '正在上传至 BytePlus') : job.errorMessage ? <small className="table-error" title={job.errorMessage}>{waitingRetry && '等待后台重试；上次错误：'}{job.errorMessage}</small> : job.providerJobId ?? (job.status === 'PENDING' ? '服务器已收文件，等待传至 BytePlus' : waitingRetry ? '等待后台继续处理' : job.status === 'PROCESSING' ? '正在传至 BytePlus 或确认 VID' : job.status === 'FAILED' ? '上传失败，可重新选择文件' : '任务已完成')}</td><td>{new Date(job.createdAt).toLocaleString('zh-CN')}</td><td>{job.status === 'PROCESSING' && job.sourceType === 'FILE' ? <span className="access-actions"><button className="secondary retry-button" type="button" disabled={reconcilingJobId === job.id || activeUpload} onClick={() => void reconcileUploadJob(job)}><RefreshCw size={14} />{activeUpload ? '处理中' : reconcilingJobId === job.id ? '正在请求...' : '继续处理'}</button>{legacyStale && <button className="text-button retry-button" type="button" disabled={reconcilingJobId === job.id || activeUpload} onClick={() => void releaseUploadJob(job)}>释放旧任务</button>}</span> : job.status === 'FAILED' && activeSibling ? '已有进行中任务' : job.status === 'FAILED' && (job.sourceType !== 'FILE' || job.localFilePath) ? <button className="secondary retry-button" type="button" disabled={retryingJobId === job.id} onClick={() => void retryUploadJob(job)}><RefreshCw size={14} />重新排队</button> : '—'}</td></tr>;
        })}</tbody></table>{!jobs.length && <p className="empty-copy table-empty">{resourceStatus.jobs?.loaded ? '暂无上传记录' : resourceStatus.jobs?.error ? '上传记录暂不可用' : '正在加载上传记录...'}</p>}</div></Panel>
      </>}
      {tab === 'albums' && !resourceStatus.albums?.loaded && !resourceStatus.albums?.error && <p className="load-placeholder">正在加载剧集...</p>}
      {tab === 'albums' && resourceStatus.albums?.loaded && <Panel title="剧集访问策略" description="免费集号上限和广告解锁配置会立即影响小程序访问"><div className="table-wrap"><table><thead><tr><th>剧集</th><th>发布状态</th><th>解锁配置</th><th>集数</th><th>免费集号上限</th><th>广告解锁</th><th>每集解锁所需广告观看次数</th><th>操作</th></tr></thead><tbody>{albums.map((album) => {
        const canDelete = album.sharedPlayback || (album.status === 'DRAFT' && !album.tiktokAlbumId);
        const accessDirty = dirtyAccessAlbumIds.has(album.id);
        const title = titleDrafts[album.id] ?? album.title;
        const titleDirty = title.trim() !== album.title;
        const renaming = savingTitleId === album.id;
        return <tr key={album.id}>
          <td><div className="album-title-editor"><span className="drama-thumb" /><input className="table-input" aria-label={`剧集名称：${album.title}`} value={title} maxLength={160} disabled={!canWriteContent} onChange={(event) => setTitleDrafts((drafts) => ({ ...drafts, [album.id]: event.target.value }))} /></div></td>
          <td><Status value={album.status} /></td>
          <td><span className={`access-config-state ${accessDirty ? 'pending' : 'saved'}`}>{accessDirty ? '待保存' : '已保存'}</span></td>
          <td>{album.episodeCount}</td>
          <td><input className="inline-number" type="number" min="0" value={album.accessConfig?.freeEpisodeCount ?? 0} onChange={(event) => updateAccessDraft(album.id, { freeEpisodeCount: Number(event.target.value) })} /></td>
          <td><input type="checkbox" checked={album.accessConfig?.rewardedAdEnabled ?? Boolean(defaultPlacementId)} onChange={(event) => updateAccessDraft(album.id, { rewardedAdEnabled: event.target.checked })} /></td>
          <td><input className="inline-number" type="number" min="1" value={album.accessConfig?.rewardedAdCount ?? 1} onChange={(event) => updateAccessDraft(album.id, { rewardedAdCount: Number(event.target.value) })} /></td>
          <td><div className="access-actions title-actions">
            {titleDirty && <button className="save-button" type="button" disabled={renaming || savingAlbumId === album.id} onClick={() => void saveAlbumTitle(album)}><Save size={14} />{renaming ? '同步中...' : '保存并同步到小程序'}</button>}
            {canWriteContent && <button className="secondary metadata-edit-button" type="button" disabled={renaming || savingAlbumId === album.id} onClick={() => setEditingAlbumMetadata({ ...album, title })}><Pencil size={14} />编辑简介</button>}
            {canWriteContent && !album.sharedPlayback && <button className="secondary metadata-edit-button" type="button" onClick={() => openDramaMaterials(album.id)}><FileVideo size={14} />管理素材</button>}
            <button className="save-button" disabled={savingAlbumId === album.id || deletingAlbumId === album.id || !accessDirty} onClick={() => void updateAccess(album)}><Save size={15} />{savingAlbumId === album.id ? '保存中...' : '保存配置'}</button>
            {canDelete && <button className="delete-button" type="button" disabled={deletingAlbumId === album.id || savingAlbumId === album.id} onClick={() => void deleteDraftAlbum(album)} title={`删除${album.sharedPlayback ? '共享副本' : '草稿剧集'} ${album.title}`}><Trash2 size={15} />{deletingAlbumId === album.id ? '删除中...' : album.sharedPlayback ? '删除共享副本' : '删除'}</button>}
          </div></td>
        </tr>;
      })}</tbody></table></div></Panel>}
      {tab === 'albums' && resourceStatus.albums?.loaded && canWriteContent && <DramaMaterials albums={albums} api={api} onSaved={() => loadTab('albums')} selection={materialSelection}
        uploadVideo={async (episodeId, file, onProgress) => {
          const form = new FormData();
          form.append('episodeId', episodeId);
          form.append('file', file);
          try {
            return await uploadMultipart<{ job: UploadJob }>(`${API}/admin/upload-jobs/local`, form,
              sessionStorage.getItem(adminTokenStorageKey), onProgress);
          } catch (error) {
            if (error instanceof UploadRequestError && error.status === 401) {
              sessionStorage.removeItem(adminTokenStorageKey);
              if (!adminSessionRecoveryStarted) { adminSessionRecoveryStarted = true; onSelect(activeApp); }
              throw new Error('管理员登录已失效，正在返回登录页。');
            }
            throw error;
          }
        }} />}
      {tab === 'albums' && resourceStatus.albums?.loaded && <Panel title="TikTok 媒资库发布链路" description="按顺序完成每部剧的媒资、版本、审核和上架；点击按钮仅表示加入异步队列。">
        <div className="platform-guide">
          <h3>每部剧的操作顺序</h3>
          <ol>
            <li><strong>准备内容</strong><span>保存封面、集数和解锁配置，确认每集 BytePlus 上传成功并有 VID。</span></li>
            <li><strong>同步媒资</strong><span>点击“同步媒资”，等待封面与每集视频在 TikTok 登记成功；入队不等于完成。</span></li>
            <li><strong>同步版本</strong><span>媒资完成后点击“同步版本”，等待平台返回版本号；送审前不要继续改动该版本内容。</span></li>
            <li><strong>送审与对账</strong><span>点击“送审”；审核期间稍后点击“对账”获取平台结果。审核未通过时先处理原因，再重新同步版本、送审。</span></li>
            <li><strong>设线上版本 → 上架</strong><span>仅审核通过后依次操作，确认线上版本和上架状态后再到小程序测试播放；需要撤下时点击“下架”。</span></li>
          </ol>
          <p>送审前可按剧目选择普通或加急。加急适用于近期上线、投放或已有消费的剧目；官方参考时效为 1–3 个工作日，每机构每天最多 35 部，并非保证通过或准时完成。已送审的版本不能靠重复点击改为加急；需要调整请带平台剧目 ID、版本号和业务理由联系 TikTok 平台支持。</p>
        </div>
        <div className="table-wrap"><table className="platform-release-table"><colgroup><col className="platform-release-album-column" /><col className="platform-release-version-column" /><col className="platform-release-status-column" /><col className="platform-release-actions-column" /></colgroup><thead><tr><th>剧集</th><th>平台版本</th><th>审核 / 上架</th><th>同步操作</th></tr></thead><tbody>{albums.map((album) => {
          const reviewing = album.reviewStatus === 'REVIEWING' || album.reviewStatus === '1';
          return <tr key={`platform-${album.id}`}>
            <td><strong>{album.title}</strong><small>{album.tiktokAlbumId ?? '尚未创建平台剧目'}</small></td>
            <td>当前版本 {album.tiktokVersion ?? '-'} · 线上 {album.onlineVersion ?? '-'} · 已发布 {album.platformPublishedVersion ?? '-'}</td>
            <td><Status value={album.status} /><small>当前版本审核：{album.reviewStatus ?? '未送审'} · 上架：{album.publishStatus ?? '未上架'}</small></td>
            <td>
              <div className="button-row">
                {canSyncContent && !album.sharedPlayback && <>
                  <button className="secondary" disabled={platformWorking !== null} onClick={() => void syncTikTokMedia(album)}>{platformWorking === `${album.id}:media` ? '媒资同步中...' : '同步媒资'}</button>
                  <button className="secondary" disabled={platformWorking !== null || reviewing} onClick={() => void runPlatformAction(album, 'sync-version')}>{platformWorking === `${album.id}:sync-version` ? '同步中...' : '同步版本'}</button>
                  <button className="secondary" disabled={platformWorking !== null} onClick={() => void runPlatformAction(album, 'reconcile')}>对账</button>
                </>}
                {canReviewContent && !album.sharedPlayback && (reviewing
                  ? <span className="review-priority">审核优先级：已送审，不可修改</span>
                  : <label className="review-priority">审核优先级<select aria-label={`${album.title}的审核优先级`} value={reviewPriorities[album.id] ?? 2} disabled={platformWorking !== null} onChange={(event) => setReviewPriorities((current) => ({ ...current, [album.id]: Number(event.target.value) as 1 | 2 }))}><option value={2}>普通（约两周）</option><option value={1}>加急（1–3 工作日）</option></select></label>)}
                {canReviewContent && !album.sharedPlayback && <button className="secondary" title={!album.tiktokVersion ? '请先完成同步版本，取得 TikTok 版本号' : undefined} disabled={platformWorking !== null || reviewing || !album.tiktokVersion || album.reviewStatus === 'PASSED'} onClick={() => void runPlatformAction(album, 'review-submit')}>送审</button>}
                {canPublishContent && !album.sharedPlayback && <>
                  <button className="secondary" disabled={platformWorking !== null || album.reviewStatus !== 'PASSED' || album.onlineVersion === album.tiktokVersion} onClick={() => void runPlatformAction(album, 'online-version')}>设线上版本</button>
                  <button className="save-button" disabled={platformWorking !== null || album.publishStatus === 'LISTED' || album.publishStatus === '1'} onClick={() => void runPlatformAction(album, 'online')}>上架</button>
                  <button className="secondary" disabled={platformWorking !== null} onClick={() => void runPlatformAction(album, 'offline')}>下架</button>
                </>}
              </div>
              <small className="platform-next-step">{album.sharedPlayback ? '授权播放副本，平台版本由主小程序管理。' : `建议下一步：${platformNextStep(album)}`}</small>
            </td>
          </tr>;
        })}</tbody></table></div>
        {platformSubmissions.length > 0 && <div className="platform-submissions" aria-live="polite"><h3>最近提交结果</h3>{platformSubmissions.map((item) => <div className={`platform-submission ${item.failed ? 'failed' : ''}`} key={item.id}><span>{item.failed ? <CircleAlert size={15} /> : <CheckCircle2 size={15} />}</span><div><strong>{item.albumTitle} · {item.action}</strong><p>{item.message}</p><small>{new Date(item.createdAt).toLocaleString('zh-CN')}{item.failed ? ' · 请处理后重试；未入队的操作不会出现在下方任务中' : ''}</small></div></div>)}</div>}
        <div className="platform-jobs-heading"><h3>最近 50 条平台任务</h3><button className="secondary" type="button" disabled={resourceStatus.platformJobs?.loading} onClick={() => void loadPlatformJobs()}>刷新状态</button></div>
        <div className="table-wrap"><table className="platform-jobs-table"><colgroup><col className="platform-job-target-column" /><col className="platform-job-action-column" /><col className="platform-job-status-column" /><col className="platform-job-business-column" /><col className="platform-job-detail-column" /></colgroup><thead><tr><th>剧目 / 分集</th><th>操作</th><th>任务状态</th><th>平台业务结果</th><th>时间 / 详情</th></tr></thead><tbody>{platformJobs.map((job) => { const details = platformBusinessDetails(job); return <tr key={job.id}><td><span className="platform-job-target" title={job.album?.title ?? job.episode?.title ?? job.albumId ?? '-'}>{job.album?.title ?? job.episode?.title ?? job.albumId ?? '-'}</span>{job.episode?.episodeNo && <small>第 {job.episode.episodeNo} 集 · {job.episode.title}</small>}</td><td>{platformJobLabels[job.kind] ?? job.kind}{job.kind === 'REVIEW' ? `（${job.snapshotJson?.priorityScore === 1 ? '加急' : job.snapshotJson?.priorityScore === 2 ? '普通' : '优先级未记录'}）` : ''}{(job.snapshotJson?.version ?? job.providerResponse?.version) ? ` · 版本 ${job.snapshotJson?.version ?? job.providerResponse?.version}` : ''}</td><td><Status value={job.status} /></td><td><strong className="platform-business-result">{platformBusinessResult(job)}</strong></td><td><small>{new Date(job.completedAt ?? job.createdAt).toLocaleString('zh-CN')}</small>{details.map((detail, index) => <small key={`${job.id}-detail-${index}`} className={detail.startsWith('审核原因') || detail.includes('异常') || detail.startsWith('任务错误') ? 'table-error' : 'platform-job-detail'}>{detail}</small>)}</td></tr>; })}</tbody></table>{!platformJobs.length && <p className="empty-copy table-empty">{resourceStatus.platformJobs?.loaded ? '暂无平台同步任务' : resourceStatus.platformJobs?.error ? '平台任务暂不可用' : '正在加载平台任务...'}</p>}</div>
      </Panel>}
      {tab === 'albums' && resourceStatus.albums?.loaded && canPublishContent && <Panel title="已审核剧目授权播放">
        <div className="multi-release-controls">
          <label>主剧目 · {miniAppNames[activeApp]}<select value={releaseAlbumId} disabled={releaseWorking !== null} onChange={(event) => { playbackStatusRequest.current += 1; setReleaseAlbumId(event.target.value); setReleaseStatuses([]); setReleaseActionErrors({}); }}><option value="">选择已上架主剧目</option>{albums.filter((album) => !album.sharedPlayback && album.onlineVersion && ['LISTED', '1'].includes(album.publishStatus ?? '')).map((album) => <option key={album.id} value={album.id}>{album.title}</option>)}</select></label>
          <fieldset><legend>目标小程序 · {miniAppOrganization(activeApp).label}</legend><div className="multi-release-targets">{miniAppOrganization(activeApp).apps.filter((key) => key !== activeApp).map((key) => <label key={key}><input type="checkbox" disabled={releaseWorking !== null} checked={releaseTargets.includes(key)} onChange={(event) => setReleaseTargets((current) => event.target.checked ? [...current, key] : current.filter((item) => item !== key))} />{miniAppNames[key]}</label>)}</div>{miniAppOrganization(activeApp).apps.length === 1 && <p className="empty-copy">此组织目前只有一个小程序，无可授权的目标。</p>}</fieldset>
          <div className="multi-release-actions">
            <button className="save-button" type="button" disabled={!releaseAlbumId || !releaseTargets.length || releaseWorking !== null} onClick={() => void runReleaseAction('AUTHORIZE')}>{releaseWorking === 'AUTHORIZE' ? '核实并授权中...' : '授权播放'}</button>
            <button className="secondary" type="button" disabled={!releaseAlbumId || !releaseTargets.length || releaseWorking !== null} onClick={() => void runReleaseAction('RECONCILE')}>对账</button>
            <button className="secondary" type="button" title="刷新授权状态" aria-label="刷新授权状态" disabled={!releaseAlbumId || !releaseTargets.length} onClick={() => void loadReleaseStatuses()}><RefreshCw size={15} /></button>
          </div>
          {releaseError && <p className="table-error">{releaseError}</p>}
        </div>
        <div className="table-wrap"><table className="multi-release-table"><thead><tr><th>小程序</th><th>授权状态</th><th>共享 TikTok 剧目 / 版本</th><th>本地映射 / 播放状态</th><th>结果 / 错误</th></tr></thead><tbody>{releaseStatuses.map((item) => <tr key={item.miniAppKey}>
          <td><strong>{miniAppNames[item.miniAppKey]}</strong></td>
          <td><Status value={item.status} /></td>
          <td>{item.tiktokAlbumId ?? '-'}<small>线上版本 {item.onlineVersion ?? '-'}</small></td>
          <td>{item.mappedEpisodeCount ?? 0} / {item.episodeCount ?? 0} 集<small>{item.localStatus === 'ONLINE' && item.status === 'AUTHORIZED' && item.mappedEpisodeCount === item.episodeCount ? '授权与本地映射完成' : '尚未开放播放'}</small><small>{item.albumId}</small></td>
          <td>{(releaseActionErrors[item.miniAppKey] ?? item.error) && <small className="table-error">{releaseActionErrors[item.miniAppKey] ?? item.error}</small>}{item.requestId && <small className="platform-job-detail">TikTok 请求 ID：{item.requestId}</small>}{item.lastReconciledAt && <small>最后对账：{new Date(item.lastReconciledAt).toLocaleString('zh-CN')}</small>}</td>
        </tr>)}</tbody></table>{!releaseStatuses.length && <p className="empty-copy table-empty">{releaseAlbumId ? '请选择目标小程序' : '请选择已上架主剧目'}</p>}</div>
        <div className="platform-jobs-heading"><h3>授权播放任务日志</h3></div>
        <div className="table-wrap"><table className="multi-release-log-table"><thead><tr><th>小程序</th><th>操作</th><th>任务状态</th><th>平台 / 本地结果</th><th>时间 / 详情</th></tr></thead><tbody>{releaseJobRows.map((job) => <tr key={`${job.miniAppKey}:${job.id}`}>
          <td>{miniAppNames[job.miniAppKey]}</td>
          <td>{job.kind === 'AUTHORIZE_ALBUM' ? '授权播放' : '授权对账'}</td>
          <td><Status value={job.status} /></td>
          <td>{job.status === 'SUCCEEDED' ? (job.kind === 'AUTHORIZE_ALBUM' ? `平台已授权 · ${job.providerResponse?.mappedEpisodeCount ?? '-'} 集映射完成` : '主剧目状态与目标映射已对账') : job.status === 'CONFLICT' ? '授权结果未知，勿重复提交' : job.status === 'FAILED' ? '失败，请查看详情' : '等待平台结果'}</td>
          <td><small>{new Date(job.completedAt ?? job.createdAt).toLocaleString('zh-CN')}</small>{job.errorMessage && <small className="table-error">{job.errorMessage}</small>}{job.providerRequestId && <small className="platform-job-detail">TikTok 请求 ID：{job.providerRequestId}</small>}</td>
        </tr>)}</tbody></table>{!releaseJobRows.length && <p className="empty-copy table-empty">暂无授权播放任务</p>}</div>
      </Panel>}
      {tab === 'ads' && !resourceStatus.ads?.loaded && !resourceStatus.ads?.error && <p className="load-placeholder">正在加载广告版本与策略...</p>}
      {tab === 'ads' && resourceStatus.ads?.loaded && <Panel title="进入广告策略" description={`当前小程序：${miniAppNames[activeApp]}`}><form className="policy-form" onSubmit={saveEntryAdPolicy}>
         <label>构建包标识<select value={entryAdReleaseId} onChange={(event) => { const releaseId = event.target.value; const release = entryAdVersions.find((item) => item.releaseId === releaseId); setEntryAdReleaseId(releaseId); if (release) setEntryAdPolicy(release); localStorage.setItem(entryAdReleaseStorageKey, releaseId); }}>{entryAdVersions.map((item) => <option key={item.releaseId} value={item.releaseId}>{item.releaseId === 'default' ? 'default（旧版包）' : item.releaseId} · {item.enabled ? '广告已启用' : '广告未启用'}</option>)}</select></label>
        <p className="form-help">首次上报：{selectedEntryAdRelease?.firstSeenAt ? new Date(selectedEntryAdRelease.firstSeenAt).toLocaleString('zh-CN') : '尚未收到该包上报'}。同一构建包审核通过后继续使用同一标识和策略。</p><details><summary>Portal 人工备注（非平台自动识别）</summary><div className="form-grid"><label>Portal 版本号<input value={selectedEntryAdRelease?.portalVersion ?? ''} maxLength={32} placeholder="例如 Version 2" onChange={(event) => setEntryAdVersions((items) => items.map((item) => item.releaseId === entryAdReleaseId ? { ...item, portalVersion: event.target.value } : item))} /></label><label>Portal 状态（手动核对）<select value={selectedEntryAdRelease?.portalStatus ?? 'UNKNOWN'} onChange={(event) => setEntryAdVersions((items) => items.map((item) => item.releaseId === entryAdReleaseId ? { ...item, portalStatus: event.target.value as PortalStatus } : item))}>{Object.entries(portalStatusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label></div>
        <button className="secondary" type="button" disabled={!selectedEntryAdRelease || savingEntryAdRelease} onClick={() => void saveEntryAdRelease()}><Save size={17} />{savingEntryAdRelease ? '保存中...' : '保存 Portal 版本状态'}</button></details>
        <label className="check-row"><input type="checkbox" checked={entryAdPolicy.enabled} onChange={(event) => setEntryAdPolicy((policy) => ({ ...policy, enabled: event.target.checked }))} />启用进入广告</label>
        <div className="form-grid"><label>广告模式<select value={entryAdPolicy.mode} onChange={(event) => setEntryAdPolicy((policy) => { const mode = event.target.value as AppEntryAdPolicy['mode']; return { ...policy, mode, placementId: entryAdPlacementDefaults[mode] }; })}><option value="INTERSTITIAL">插屏广告</option><option value="REWARDED_GATED">激励门槛广告</option></select></label><label>广告位 ID<input value={entryAdPolicy.placementId} onChange={(event) => setEntryAdPolicy((policy) => ({ ...policy, placementId: event.target.value }))} required={entryAdPolicy.enabled} /></label><label>所需广告次数<input type="number" min="1" value={entryAdPolicy.requiredCount} onChange={(event) => setEntryAdPolicy((policy) => ({ ...policy, requiredCount: Number(event.target.value) }))} required /></label><label>计数规则<select value={entryAdPolicy.countMode} onChange={(event) => setEntryAdPolicy((policy) => ({ ...policy, countMode: event.target.value as AppEntryAdPolicy['countMode'] }))}><option value="COMPLETED">完成激励后计数</option><option value="SHOWN">成功弹出即计数</option></select></label><label>广告不可用时<select value={entryAdPolicy.onUnavailable} onChange={(event) => setEntryAdPolicy((policy) => ({ ...policy, onUnavailable: event.target.value as AppEntryAdPolicy['onUnavailable'] }))}><option value="ALLOW">允许进入</option><option value="BLOCK">阻止进入</option></select></label></div>
        <p className="form-help">正在编辑：{entryAdPolicy.releaseId} · 策略版本 {entryAdPolicy.version}。</p><button className="primary" type="submit" disabled={savingEntryAdPolicy || entryAdPolicy.releaseId !== entryAdReleaseId}>{savingEntryAdPolicy ? '保存中...' : <><Save size={17} />保存进入广告策略</>}</button></form></Panel>}
      {tab === 'audience' && !audience && !resourceStatus.audience?.error && <p className="load-placeholder">正在加载观众数据...</p>}
      {tab === 'audience' && audience && <AudiencePage audience={audience} />}
      {tab === 'playback' && !playback && !resourceStatus.playback?.error && <p className="load-placeholder">正在加载播放质量...</p>}
      {tab === 'playback' && playback && <PlaybackPage playback={playback} />}
      {tab === 'security' && <div className="content-grid"><Panel title="当前管理员" description="角色和账号状态由服务端实时校验"><div className="readiness-list"><div><span className="ready-dot done"><CheckCircle2 size={15} /></span><span><strong>{currentAdmin?.email ?? '-'}</strong><small>角色：{currentAdmin?.role ?? '-'} · 状态：{currentAdmin?.status ?? '-'}</small></span></div><div><span className="ready-dot done"><CalendarDays size={15} /></span><span><strong>最近登录</strong><small>{currentAdmin?.lastLoginAt ? new Date(currentAdmin.lastLoginAt).toLocaleString('zh-CN') : '暂无记录'}</small></span></div></div></Panel><Panel title="修改密码" description="更新后当前登录令牌会立即失效"><form className="policy-form" onSubmit={changePassword}><label>当前密码<input type="password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} required /></label><label>新密码<input type="password" minLength={12} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} required /></label><button className="primary" type="submit" disabled={changingPassword}><Save size={17} />{changingPassword ? '更新中...' : '更新密码'}</button></form></Panel></div>}
      <AlbumMetadataDialog album={editingAlbumMetadata} api={api} onClose={() => setEditingAlbumMetadata(null)} onSaved={albumMetadataSaved} />
    </main></div>;
}

return AdminApp;
}

function AdminWorkspace() {
  const [selection, setSelection] = useState({ app: initialApp, generation: 0 });
  const Workspace = useMemo(() => createAdminWorkspace(selection.app, (app) => {
    localStorage.setItem('quickreels_active_app', app);
    setSelection((current) => ({ app, generation: current.generation + 1 }));
  }), [selection]);
  return <Workspace />;
}
createRoot(document.getElementById('root')!).render(<AdminWorkspace />);
